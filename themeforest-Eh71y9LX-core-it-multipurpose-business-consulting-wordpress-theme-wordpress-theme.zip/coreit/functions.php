<?php
/*
**==============================   
** coreit Functions
**==============================
*/  
// ============================== Mobile Detect ============================
// Include the Mobile_Detect library
require get_template_directory() . '/includes/main/libs/Coreit_Mobile_Detect.php';
/**
 * Check if the current device is mobile or tablet
 * @return bool True if mobile or tablet, false otherwise
 */
function Coreit_isMobile() {
    if ( ! class_exists( 'Coreit_Mobile_Detect' ) ) {
        return false;
    }
    $detect = new Coreit_Mobile_Detect;
    $mobile = false;
    if( $detect->isMobile() || $detect->isTablet() ){
        $mobile = true;
    }
    return $mobile;
} 
// ============================== Theme Options ============================
/**
 * Retrieve theme options
 * @param string $option_name The name of the option to retrieve
 * @param mixed $default_value The default value if the option is not set
 * @return mixed The value of the option
 */
function coreit_get_option($option_name, $default_value = '') {
    $option_value = get_theme_mod($option_name, $default_value);
    return $option_value;
}
// ============================== Theme Helper ============================
// Include the ThemeHelper file
require_once get_template_directory() . '/includes/ThemeHelper.php'; 
// ============================== Theme Update ============================
 // ============================== Theme Helper ============================
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;
// ============================== Theme update ============================
if(class_exists('Coreit_update')): 
    $myUpdateChecker = PucFactory::buildUpdateChecker(
        'https://coreit.themepanthers.com/update/theme.json',
        __FILE__,
        'coreit-theme-update',
        1,
        true,
        ['sslVerify' => true]
    );
endif;
// ============================== Theme update ============================   
 
 
add_action('after_setup_theme', function () {
    remove_theme_support('core-block-patterns');
});

 
if ( ! function_exists( 'debug_icon_type_path' ) ) {
    function debug_icon_type_path() {
        $backtrace = debug_backtrace();
        error_log( "===== icon-type.php Called From =====" );
        foreach ( $backtrace as $trace ) {
            if ( isset( $trace['file'] ) ) {
                error_log( 'File: ' . $trace['file'] . ' Line: ' . $trace['line'] );
            }
        }
        error_log( "===== End Trace =====" );
    }
}

debug_icon_type_path();


// Add custom admin notice for Ecom Theme Launch
add_action('admin_notices', 'ecom_theme_launch_notice');
function ecom_theme_launch_notice() {
    ?>
    <style>
        .ecom-admin-notice {
            border: 4px solid var(--color-set-one-2, #FD9636);
            background: var(--background-bg-1, #F0F3F8);
            padding: 15px 20px;
            margin: 20px 0;
            border-radius: 8px;
            font-family: var(--font-family-main, "DM Sans", sans-serif);
            color: var(--content-color-one, #425A8B);
            display: flex;
            align-items: center;
            gap: 15px;
            justify-content:space-between;
        }
        .ecom-admin-notice img {
            width: 40%;
            height: auto;
            border-radius: 4px;
        }
        .ecom-admin-notice > div{
            width: 50%;
        }
        .ecom-admin-notice h2 {
            margin: 0 0 5px;
            font-size: 18px;
            color: var(--heading-color-one, #425A8B);
        }
        .ecom-admin-notice p {
            margin: 0;
            color: var(--content-color-two, #8C9EC5);
            font-size: 14px;
        }
    </style>
    <div class="notice notice-info ecom-admin-notice">
        <img src="https://elango.steelthemes.com/ecom/ecom-promo.jpg" alt="Ecom Theme" />
        <div>
            <h2><strong>Ecom Multipurpose WooCommerce Theme</strong></h2>
            <p>Check the demos: 
                <a href="https://elango.steelthemes.com/ecom/wp1" target="_blank">Wpbakery  Page Builder Version</a> | 
                <a href="https://elango.steelthemes.com/ecom/el1/" target="_blank">Elementor Page Builder Version</a><br>
                🎉 Launching soon at just <strong style="color: var(--color-set-one-2, #FD9636);">$19</strong> first release offer. Stay tuned!
            </p>
            <a href="mailto:steelthemeshelp@gmail.com">For More information mail to steelthemeshelp@gmail.com</a>
        </div>
    </div>
    <?php
}
