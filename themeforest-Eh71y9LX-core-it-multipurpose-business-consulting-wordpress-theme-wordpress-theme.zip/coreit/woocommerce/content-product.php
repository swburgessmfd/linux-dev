<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.4.0
 */
defined( 'ABSPATH' ) || exit;
global $product;
// Check if the product is a valid WooCommerce product and ensure its visibility before proceeding.
if ( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ) {
	return;
}
$listview = '';
if(coreit_get_view_via_url() == 'list-view'): 
	 $listview = 'display-list';
else:
	$listview = 'display-list-two';
endif;
if(coreit_get_view_via_url() == 'list-view'): ?>
	 <li <?php wc_product_class( $listview, $product ); ?>>
		 <?php do_action('coreit_get_product_card_default_list'); ?>
	 </li> 
 <?php else: ?> 
	 <li <?php wc_product_class( '', $product ); ?>>
		 <?php  do_action('coreit_get_product_card_default'); ?> 
	 </li> 
 <?php endif; ?>