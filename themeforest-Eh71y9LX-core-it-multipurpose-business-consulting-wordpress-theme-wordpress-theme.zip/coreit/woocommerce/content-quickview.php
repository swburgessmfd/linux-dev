<?php
 // quick view
defined( 'ABSPATH' ) || exit;

global $product;

/**
 * Hook: woocommerce_before_single_product.
 *
 * @hooked woocommerce_output_all_notices - 10
 */
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: XSS ok.
	return;
}
?>
<div class="coreit_product_single">
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'shop_single', $product ); ?>>
	<div class="row gallery_and_content">
		<div class="col-lg-6 col-md-12">
			<?php
				/**
				 * Hook: woocommerce_before_single_product_summary.
				 *
				 * @hooked woocommerce_show_product_sale_flash - 10
				 * @hooked woocommerce_show_product_images - 20
				 */
				do_action( 'woocommerce_before_single_product_summary' );
				do_action( 'coreit_badge_sale_text' ); 
			?>
		</div>
		<div class="col-lg-6 col-md-12">
				<div class="summary entry-summary"> 
					<div class="top_content_single">
					<?php do_action('coreit_get_shipping_name'); ?>  
						<div class="title"><?php do_action('coreit_single_title'); ?></div>
						<?php do_action('coreit_get_product_deals'); ?>
						<div class="divborder"></div>
						<?php do_action('coreit_single_rating'); ?>
						<?php do_action('coreit_single_meta'); ?> 
					
					</div>
					<div class="top_min_single">  
					<?php
					/**
					 * Hook: woocommerce_single_product_summary.
					 *
					 * @hooked woocommerce_template_single_title - 5
					 * @hooked woocommerce_template_single_rating - 10
					 * @hooked woocommerce_template_single_price - 10
					 * @hooked woocommerce_template_single_excerpt - 20
					 * @hooked woocommerce_template_single_add_to_cart - 30
					 * @hooked woocommerce_template_single_meta - 40
					 * @hooked woocommerce_template_single_sharing - 50
					 * @hooked WC_Structured_Data::generate_product_data() - 60
					 */
					do_action( 'woocommerce_single_product_summary' );
					?>
					</div>
					<div class="top_bottom_single">
					<?php do_action('coreit_single_excerpt'); ?> 
					<?php do_action('coreit_theme_share'); ?>
					</div>
				</div>
		</div>
</div>
 
<div class="woocommerce-tabs wc-tabs-wrapper">
		<ul class="tabs wc-tabs" role="tablist">
			<li class="description_tab active" id="tab-title-description" role="tab" aria-controls="tab-description">
				<a href="#tab-description">
					Description	
                </a>
			</li>
			<li class="additional_information_tab" id="tab-title-additional_information" role="tab" aria-controls="tab-additional_information">
				<a href="#tab-additional_information">
					Additional information
                </a>
			</li>
							 
			</ul>
			<div class="woocommerce-Tabs-panel woocommerce-Tabs-panel--description panel entry-content wc-tab" id="tab-description" role="tabpanel" aria-labelledby="tab-title-description" style="display:block;">
	       
                <?php woocommerce_product_description_tab();  ?>
			</div>
			<div class="woocommerce-Tabs-panel woocommerce-Tabs-panel--additional_information panel entry-content wc-tab" id="tab-additional_information" role="tabpanel" aria-labelledby="tab-title-additional_information">
	             
                <?php woocommerce_product_additional_information_tab();  ?>
			</div> 
	</div>
	</div>
</div>

 
