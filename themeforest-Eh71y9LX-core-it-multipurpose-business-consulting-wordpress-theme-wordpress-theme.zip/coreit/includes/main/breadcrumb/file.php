<?php
/*
 ** ==============================
 ** coreit Breadcrumb File
 ** ==============================
 */
add_action("coreit_custom_breadcrumb", "coreit_breadcrumb");
function coreit_breadcrumb()
{
    global $post;
    $showOnHome = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show
    $delimiter = ""; // delimiter between crumbs
    $showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
    $before = '<li class="active">'; // tag before the current crumb
    $after = "</li>"; // tag after the current crumb
    $wp_the_query = $GLOBALS["wp_the_query"];
    $queried_object = $wp_the_query->get_queried_object();
    $allowed_tags = wp_kses_allowed_html("post");
    $homeLink = esc_url(home_url());
    $bdhome = "";
    // Service Option
    $service_page_id = coreit_get_option('service_archive_id');
    $service_crumb_name_link = get_permalink($service_page_id);  
    // portfolio Option
    $portfolio_page_id = coreit_get_option('portfolio_archive_id');
    $portfolio_crumb_name_link = get_permalink($portfolio_page_id); 
    // Team Option
    $team_page_id = coreit_get_option('team_archive_id');
    $team_crumb_name_link = get_permalink($team_page_id);  
    $job_breadcrumb_name_single = coreit_get_option('job_breadcrumb_name' , 'Jobs');
    $product_breadcrumn_name = coreit_get_option('product_breadcrumn_name' , 'Shop'); 
    $job_crumb_name_link_single = coreit_get_option('job_breadcrumb_link'); 
    $meta_breadcrumb_title = isset($post) && is_object($post) ? get_post_meta($post->ID, 'meta_breadcrumb_title', true) : '';
    $display_title = !empty($meta_breadcrumb_title) ? $meta_breadcrumb_title : get_the_title();
    if (is_home() || is_front_page()) {
        if ($showOnHome == 1) {
            echo '<ul class="breadcrumb"><li><a href="' .
                $homeLink .
                '">' .
                esc_html__("Home", "coreit") .
                "</a></li></ul>";
        }
    } 
    if (!is_front_page()) {
        echo '<ul class="breadcrumb d_flex m-auto"><li><a href="' .
            $homeLink .
            '">' .
            esc_html__("Home", "coreit") .
            "</a></li>";
        if (is_category()) {
            global $wp_query;
            $cat_obj = $wp_query->get_queried_object();
            $thisCat = $cat_obj->term_id;
            $thisCat = get_category($thisCat);
            $parentCat = get_category($thisCat->parent);
            if ($thisCat->parent != 0) {
                echo wp_kses(
                        $before .
                        get_category_parents(
                            $parentCat,
                            true,
                            " " . $delimiter . " "
                        ) .
                        $after
                    , $allowed_tags
                );
            }
            echo wp_kses(
                    $before . " " . single_cat_title("", false) . "" . $after
                , $allowed_tags
            );
        } elseif (is_search()) {
            echo wp_kses(
                $before .
                esc_html__('Search results for "', "coreit") .
                get_search_query() .
                '"' .
                $after , $allowed_tags
            );
        } elseif (is_day()) {
            echo '<li><a href="' .
                get_year_link(get_the_time("Y")) .
                '">' .
                get_the_time("Y") .
                "</a></li> " .
                $delimiter .
                " ";
            echo '<li><a href="' .
                get_month_link(get_the_time("Y"), get_the_time("m")) .
                '">' .
                get_the_time("F") .
                "</a></li> " .
                $delimiter .
                " ";
            echo wp_kses(
               $before . get_the_time("d") . $after , $allowed_tags
            );
        } elseif (is_month()) {
            echo '<li><a href="' .
                get_year_link(get_the_time("Y")) .
                '">' .
                get_the_time("Y") .
                "</a></li> " .
                $delimiter .
                " ";
            echo wp_kses(
                 $before . get_the_time("F") . $after ,$allowed_tags
            );
        } elseif (is_year()) {
            echo wp_kses(
               $before . get_the_time("Y") . $after , $allowed_tags
            );
        } elseif (is_tag()) {
            echo wp_kses(
                    $before . '"' . single_tag_title("", false) . '"' . $after
                , $allowed_tags
            );
        } elseif (is_author()) {
            global $author;
            $userdata = get_userdata($author);
            echo wp_kses(
                $before . '"' . $userdata->display_name . '"' . $after , $allowed_tags
            );
        } elseif (is_404()) {
            echo wp_kses(
                $before . esc_html__("Error 404", "coreit") . $after , $allowed_tags
            );
        } elseif (is_page() && !$post->post_parent) {
            if ($showCurrent == 1) {
                echo wp_kses(
                     $before . $display_title . $after , $allowed_tags
                );
            }
        } elseif (is_page() && $post->post_parent) {
            $parent_id = $post->post_parent;
            $breadcrumbs = [];
            while ($parent_id) {
                $page = get_page($parent_id);
                $breadcrumbs[] =
                    '<li><a href="' .
                    get_permalink($page->ID) .
                    '">' .
                    get_the_title($page->ID) .
                    "</a></li>";
                $parent_id = $page->post_parent;
            }
            $breadcrumbs = array_reverse($breadcrumbs);
            foreach ($breadcrumbs as $crumb) {
                echo wp_kses(
                   $crumb . " " . $delimiter . " " , $allowed_tags
                );
            }
            if ($showCurrent == 1) {
                echo wp_kses(
                    $before . $display_title . $after , $allowed_tags
                );
            }
        } elseif (is_singular("post")) {
            $cat = get_the_category();
            $cat = $cat[0];
            $cats = get_category_parents($cat, true, " " . $delimiter . " ");
            if ($showCurrent == 0) {
                $cats = preg_replace("/^(.+)\s$delimiter\s$/", "$1", $cats);
            }
            echo "<li>" . $cats . "</li> ";
            if ($showCurrent == 1) {
                echo wp_kses(
                     $before . $display_title . $after , $allowed_tags
                );
            }
        } 
        elseif (is_singular("service")) {
            echo '<li><a href="' .$service_crumb_name_link .'">' . esc_html__("Service", "coreit") ."</a></li> ";
            if ($showCurrent == 1) {
                echo wp_kses( $before . $display_title . $after , $allowed_tags);
            }
        } 
        elseif (is_post_type_archive("service") || is_tax("service_category")) {
            echo '<li><a href="' . $service_crumb_name_link . '">' . esc_html__("Service", "coreit") ."</a></li> ";
            if (is_category() || is_tag() || is_tax()) {
                $term_object = get_queried_object();
                $term_name = $term_object->name;
                $current_term_link = $before . $term_name . $after;
                echo wp_kses($current_term_link, $allowed_tags);
            }
        } 
        elseif (is_singular("team")) {
            echo '<li><a href="' .$team_crumb_name_link .'">' . esc_html__("Team", "coreit") ."</a></li> ";
            if ($showCurrent == 1) {
                echo wp_kses($before . $display_title . $after , $allowed_tags);
            }
        } 
        elseif (is_post_type_archive("team") || is_tax("team_category")) {
            echo '<li><a href="' . $team_crumb_name_link . '">' . esc_html__("Team", "coreit") ."</a></li> ";
            if (is_category() || is_tag() || is_tax()) {
                $term_object = get_queried_object();
                $term_name = $term_object->name;
                $current_term_link = $before . $term_name . $after;
                echo wp_kses($current_term_link, $allowed_tags);
            }
        } 
        elseif (is_singular("portfolio")) {
            echo '<li><a href="' .$portfolio_crumb_name_link .'">' . esc_html__("Portfolio", "coreit") ."</a></li> ";
            if ($showCurrent == 1) {
                echo wp_kses($before . $display_title . $after , $allowed_tags);
            }
        } 
        elseif (is_post_type_archive("portfolio") || is_tax("portfolio_category") || is_tax("portfolio_brand")) {
            echo '<li><a href="' . $portfolio_crumb_name_link . '">' . esc_html__("Portfolio", "coreit") ."</a></li> ";
            $term_object = get_queried_object();
            $term_name = $term_object->name;
            $current_term_link = $before . $term_name . $after;
            echo wp_kses($current_term_link, $allowed_tags);
        } 
        elseif (is_post_type_archive("product")) {
            $shop_page_id = wc_get_page_id("shop");
            $shop_page_name = get_the_title($shop_page_id);
            echo "<li>" . $shop_page_name . "</li>";
        } 
        elseif (is_tax("product_cat") || is_tax("product_tag") || is_tax("brand")) {
            $queried_object = get_queried_object();
            $term_id = $queried_object->term_id;
            $taxonomy = $queried_object->taxonomy;
            $term_parents = get_ancestors($term_id, $taxonomy);
            $term_parents = array_reverse($term_parents); 
            foreach ($term_parents as $parent_id) {
                $parent_term = get_term($parent_id, $taxonomy);
                echo '<li class="active"><a href="' .
                    get_term_link($parent_term) .
                    '">' .
                    $parent_term->name .
                    "</a></li>";
            } 
            echo '<li class="active">' . single_term_title("", false) . "</li>";
        } 
        elseif (is_singular("product")) {
            $categories = get_the_terms($post->ID, "product_cat"); 
            if (!is_wp_error($categories) && $categories) {
                $category = $categories[0];
                $category_parents = get_ancestors(
                    $category->term_id,
                    "product_cat"
                );
                if (!is_wp_error($category_parents) && $category_parents) {
                    $category_parents = array_reverse($category_parents);
                    foreach ($category_parents as $parent_id) {
                        $parent = get_term($parent_id, "product_cat");
                        if (!is_wp_error($parent)) {
                            echo '<li class="active"><a href="' .
                                get_term_link($parent) .
                                '">' .
                                $parent->name .
                                "</a></li>";
                        }
                    }
                } 
                echo '<li class="active"><a href="' .
                    get_term_link($category) .
                    '">' .
                    $category->name .
                    "</a></li>";
            } 
            
            echo '<li class="active">' . esc_html($display_title) . "</li>";
        }  
        elseif(is_singular('job_listing')) { 
            echo '<li><a href="'.$job_crumb_name_link_single.'">'.$job_breadcrumb_name_single.'</a></li> ';
            if($showCurrent == 1) echo html_entity_decode( esc_html( $before . $display_title . $after));
        } 
        elseif(is_post_type_archive('job_listing')) {
             echo '<li><a href="'.$job_breadcrumb_link.'">'.$job_breadcrumb_name.'</a></li> ';
          
        }
        elseif (is_attachment()) {
            $parent = get_post($post->post_parent);
            $cat = get_the_category($parent->ID);
            $cat = $cat;
            echo '<li><a href="' .
                get_permalink($parent) .
                '">' .
                $parent->post_title .
                "</a></li> " .
                $delimiter .
                " ";
            if ($showCurrent == 1) {
                echo wp_kses(
                    $before . get_the_title() . $after , $allowed_tags
                );
            }
        } 
        if (is_home()) {
            global $post;
            $page_for_posts_id = get_option("page_for_posts");
            echo "<li>"; 
            if ($page_for_posts_id) {
                $post = get_page($page_for_posts_id); 
                setup_postdata($post);
                the_title();
                rewind_posts();
            } 
            echo "</li>";
        } 
        if (get_query_var("paged")) {
            if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author()) {
                echo "<li>" .
                    esc_html__("Page", "coreit") .
                    "" .
                    get_query_var("paged") .
                    "</li> ";
            }
        }
        echo "</ul>";
    }
}
