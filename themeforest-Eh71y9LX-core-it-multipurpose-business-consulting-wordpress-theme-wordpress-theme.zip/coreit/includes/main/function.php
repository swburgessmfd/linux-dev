<?php
use Coreitaddons\Woocommerce\Wishlist\Wishlist;
use Coreitaddons\Woocommerce\Compare\Compare;
// Body classes
add_filter('body_class', 'coreit_body_classes'); 
// Page and other post titles
add_filter("get_the_archive_title", "coreit_the_archive_title");
// Page header mage 
add_action('coreit_get_page_header_image' , 'coreit_page_header_image'); 
// page header after pluign load
add_action("coreit_default_page_header", "coreit_page_header");
// header
add_action("coreit_get_header" , "coreit_default_header"); 
// Mobile Menu
add_action("coreit_get_mobile_menu", "coreit_mobile_menu");
// Footer 
add_action("coreit_get_footer", "coreit_default_footer");
// Nav Links 
add_action('coreit_custom_pagination_width_img',   'coreit_no_image_nav_links');
// Post Navigation 
add_action('coreit_custom_pagination',   'coreit_numeric_posts_nav');
// Back to top 
add_action('coreit_get_back_to_top' , 'coreit_back_to_top');
// Main Theme fucntion
//=================================================================
function coreit_back_to_top(){  
    $backtoenable = coreit_get_option('backtoenable' , false);
    if($backtoenable == false){
        return; 
    }
?> 
    <div class="prgoress_indicator">
      <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
        <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
      </svg>
    </div>
<?php
}
/*
========================
Get Class for body Class
========================
*/
function coreit_body_classes($classes)
{
    global $post;  
    $header_sticky_enables = coreit_get_option('header_sticky_enables');
    $coreitrtlenableclsss = coreit_get_option('rtl_enable_all');
    $recently_viewd_poducts = coreit_get_option('recently_viewd_poducts' , true);
    // Add a class of layout
    $classes[] = coreit_get_layout();
    $classes[] = 'scrollbarcolor';
    // Adds a class of group-blog to blogs with more than 1 published author.
    if (is_multi_author())
    {
        $classes[] = 'group-blog';
    }
    if (is_singular('page'))
    {
        $classes[] = 'page-' . $post->post_name;
    }
    // Adds a class of hfeed to non-singular pages.
    if (!is_singular())
    {
        $classes[] = 'hfeed';
    } 
    if($header_sticky_enables == true){
        $classes[] = 'enabled_sticky_header ';
    }  
    if ((get_post_meta(get_the_ID() , 'rtl_enable_disable', true)) || ($coreitrtlenableclsss == true)){
        $classes[] = 'rtl_enable';
    }
    if ($recently_viewd_poducts == true){
        if (is_tax('product_cat')  || is_post_type_archive('product') || is_singular('product')){
        $classes[] = 'review_enable';
        }
    }
    $smooth_scroll =   coreit_get_option('smooth_scroll');
    if($smooth_scroll ==  true){  
        $classes[] = 'luxescroll';
    }
   if (is_tax('product_cat')  || is_post_type_archive('product')) {
    $shop_layouts = coreit_get_option("shop_layouts", "right-sidebar");
        if($shop_layouts != "no-sidebar" && !empty(is_active_sidebar("shop-sidebar"))){
            $classes[] = 'showing-sidebar';
        }
    }
    $classes[] = 'luxescroll';
    return $classes;
}

// Post Navigation
function coreit_numeric_posts_nav() {
    if (is_singular()) :
        return;
    endif;
    global $wp_query;
    /** Stop execution if there's only 1 page */
    if ($wp_query->max_num_pages <= 1) :
        return;
    endif;
    $paged = get_query_var('paged') ? absint(get_query_var('paged')) : 1;
    $max = intval($wp_query->max_num_pages);
    /** Add current page to the array */
    if ($paged >= 1) :
        $links[] = $paged;
    endif;
    /** Add the pages around the current page to the array */
    if ($paged >= 3) {
        $links[] = $paged - 1;
        $links[] = $paged - 2;
    }
    if (($paged + 2) <= $max) {
        $links[] = $paged + 2;
        $links[] = $paged + 1;
    }
    echo '<div class="pagination-area text-center"><ul class="pagination pd_0">' . "\n";
    /** Previous Post Link */
    if (get_previous_posts_link()) :
        printf('<li class="prev_link page-item">%s</li>' . "\n", get_previous_posts_link('<i class="coreits-left-chevron"></i>'));
    endif;
    /** Link to first page, plus ellipses if necessary */
    if (!in_array(1, $links)) :
        $class = 1 == $paged ? ' active ' : '';
        printf('<li class="%s page-item"><a href="%s" class="page-link">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link(1)), '1');
        if (!in_array(2, $links)) :
            echo '<li class="page-item"><a class="page-link dot">…</a></li>';
        endif;
    endif;
    /** Link to current page, plus 2 pages in either direction if necessary */
    sort($links);
    foreach ((array) $links as $link) :
        $class = $paged == $link ? 'active ' : '';
        printf('<li class="%spage-item"><a href="%s" class="page-link">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link($link)), $link);
    endforeach;
    /** Link to last page, plus ellipses if necessary */
    if (!in_array($max, $links)) :
        if (!in_array($max - 1, $links))
            echo '<li class="page-item"><a class="page-link dot">…</a></li>' . "\n";
        $class = $paged == $max ? ' active ' : '';
        printf('<li class="%s page-item"><a href="%s" class="page-link">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link($max)), $max);
    endif;
    /** Next Post Link */
    if (get_next_posts_link()) :
        printf('<li class="next_link page-item">%s</li>' . "\n", get_next_posts_link('<i class="coreits-chevron"></i>'));
    endif;
    echo '</ul></div>' . "\n";
}
// Next and Prev Navigation
function coreit_no_image_nav_links() {
    $previous = get_previous_post();
    $next = get_next_post();
    $blog_page_id = get_option( 'page_for_posts' ); // Get the ID of the blog page 
    $blog_page_url = get_permalink( $blog_page_id ); // Get the permalink of the blog page 
    if(is_singular('team')){
        $team_archive_id = coreit_addons_get_option( 'team_archive_id' );
        $blog_page_url = get_permalink( $team_archive_id ); // Get the permalink of the blog page 
    }elseif(is_singular('portfolio')){
        $portfolio_archive_id = coreit_addons_get_option( 'portfolio_archive_id' );
        $blog_page_url = get_permalink( $portfolio_archive_id ); // Get the permalink of the blog page 
    }elseif(is_singular('service')){
        $service_archive_id = coreit_addons_get_option( 'service_archive_id' );
        $blog_page_url = get_permalink( $service_archive_id ); // Get the permalink of the blog page 
    }else{
        $blog_page_url = get_permalink( $blog_page_id ); // Get the permalink of the blog page 
    }
    if(is_singular('post') || is_singular('team') || is_singular('portfolio') || is_singular('service')): ?> 
    <div class="previouse_next_post <?php if($prev_post = get_previous_post()): ?> only_prev<?php endif; ?><?php if($next_post = get_next_post()): ?> only_next<?php endif; ?>">
        <div class="row align-items-center">
        <?php if($prev_post = get_previous_post()): ?>
        <div class="prev_post  nav_post col-lg-5 col-md-5 col-sm-12">
            <a href="<?php echo get_permalink( $prev_post->ID ); ?>" class="linked_prev_next">
                <?php if(!empty(get_the_post_thumbnail($prev_post->ID))): ?>
                <div class="image">
                    <?php echo get_the_post_thumbnail( $prev_post->ID,  array(80,80));  ?>
                </div>
                <?php endif; ?>
                <div class="text">
                    <div class="font-20 mb_10 trim-2"><?php echo get_the_title($previous) ?></div> 
                    <small class="text-18 d_flex align-items-center"><i class="coreits-left-chevron"></i> <?php esc_html_e('Previous Post', 'coreit') ?> </small>
                </div>
            </a>
        </div>
        <?php endif;  ?>
        <div class="all_post col-lg-2 col-md-2 text-center col-sm-12">
            <a href="<?php echo esc_attr($blog_page_url); ?>" target="_blank" class=" d_flex align-items-center justify-content-center ">
            <svg id="fi_8379638" height="512" viewBox="0 0 24 24" width="512" xmlns="http://www.w3.org/2000/svg"><path id="grid-1" d="m5 7a2 2 0 1 1 2-2 2 2 0 0 1 -2 2zm9-2a2 2 0 1 0 -2 2 2 2 0 0 0 2-2zm7 0a2 2 0 1 0 -2 2 2 2 0 0 0 2-2zm-14 7a2 2 0 1 0 -2 2 2 2 0 0 0 2-2zm7 0a2 2 0 1 0 -2 2 2 2 0 0 0 2-2zm7 0a2 2 0 1 0 -2 2 2 2 0 0 0 2-2zm-14 7a2 2 0 1 0 -2 2 2 2 0 0 0 2-2zm7 0a2 2 0 1 0 -2 2 2 2 0 0 0 2-2zm7 0a2 2 0 1 0 -2 2 2 2 0 0 0 2-2z" fill="rgb(0,0,0)"></path></svg>
        </a>
        </div>
        <?php if($next_post = get_next_post()): ?>
        <div class="next_post  nav_post col-lg-5 col-md-5 col-sm-12">
            <a href="<?php echo get_permalink( $next_post->ID ); ?>" class="linked_prev_next">
                <div class="text">
                    <div class="font-20 mb_10 trim-2"><?php echo get_the_title($next) ?></div>
                    <small  class="text-18 d_flex justify-content-end align-items-center"><?php esc_html_e('Next Post', 'coreit'); ?> <i class="coreits-chevron"></i></small>
                </div>
                <?php if(!empty(get_the_post_thumbnail($next_post->ID))): ?>
                <div class="image">
                    <?php echo get_the_post_thumbnail( $next_post->ID,  array(80,80));  ?>
                </div>
                <?php endif; ?>
            </a>
        </div>
        <?php endif; ?>
    </div>
    </div>
    <?php endif; 
} 

// coreit Page , post and other post titles
function coreit_the_archive_title($title){
     // Get the current post ID
     $post_id = get_the_ID();

     // Check if mobile
     $is_mobile = Coreit_isMobile();
 
     // Fetch appropriate title based on mobile detection
     $meta_page_title = $post_id ? get_post_meta($post_id, 'meta_page_title', true) : '';
     $mobile_meta_page_title = $post_id ? get_post_meta($post_id, 'mobile_meta_page_title', true) : '';
     $page_title = $is_mobile && !empty($mobile_meta_page_title) 
         ? $mobile_meta_page_title 
         : (!empty($meta_page_title) ? $meta_page_title : get_the_title($post_id));
 
     // Allowable HTML tags
     $allowed_tags = wp_kses_allowed_html("post");
    if (is_search()):
        $title = sprintf(esc_html__("Search Results", "coreit"));
    elseif (is_404()):
        $title = sprintf(esc_html__("Page Not Found", "coreit"));
    elseif (is_page() || is_single() || is_singular("post") || is_singular("product")):
            $title = wp_kses($page_title, $allowed_tags);
    elseif (is_author()):
        $title = '';
    elseif (is_home() && is_front_page()):
        $title = esc_html__("The Latest Posts", "coreit");
    elseif (is_home() && !is_front_page()):
        $title = get_the_title(get_option("page_for_posts")); 
    elseif (is_tax() || is_category() || is_tag()):
        $title = single_term_title("", false); 
    // job manager
    elseif(is_singular('job_listing')):
        $title = get_the_title(get_the_ID()); 
    elseif(is_post_type_archive('job_listing')):
        $st_job_page_id = get_option('st_job_page_id');
        if($st_job_page_id && get_post($st_job_page_id)):
            $title = get_the_title($st_job_page_id);
        else:
            $title = esc_html__('Job Listing',  'coreit');
        endif; 
    // job manager 
    elseif(is_post_type_archive('product')):
        $shop_page_id = wc_get_page_id("shop");
        $product_page_id = get_the_title($shop_page_id);
        $title = $product_page_id;   
    endif;
    
    return $title;
}
// Page header Enable / Disable
function coreit_has_page_header()
{
    $page_header_options = coreit_get_option("page_header_enables" , true);
    $is_page_header_disabled = get_post_meta(get_the_ID(), "page_header_enable", true);
    if ((is_page() || is_singular(["team", "service", "post", "portfolio"])) && $is_page_header_disabled === 'on'):
            return false;
        elseif (is_singular("mega-menu")):
            return false;
        elseif (is_singular("header")):
            return false;
        elseif (is_singular("sticky_header")):
            return false;
        elseif (is_singular("footer")):
            return false;
        elseif (is_page_template("template-homepage.php")):
            return false;
        elseif (is_page_template("template-blog.php")):
            return false;
        elseif (is_attachment()):
            return false; 
        endif;
    return $page_header_options;
}
// coreit page header image
function coreit_page_header_image()
{
    if (!coreit_has_page_header()) {
        return;
    }
    
    $mobile_device = Coreit_isMobile();
    
    if (
        is_page() || 
        is_singular(["service", "team", "portfolio", "product", "job_listing"]) || 
        is_post_type_archive("product") || 
        is_tax(["product_cat", "portfolio_category" , "product_brand" , 'product_tag' , 'job_listing_type' , "service_category", "team_category"])
    ){   
        $page_header_bgimages = coreit_get_option("page_header_bg_image");
        $mobile_page_header_bgimages = coreit_get_option("mobile_page_header_bg_image");
      
            $mobile_page_pg_image = get_post_meta(get_the_ID(), "mobile_page_header_image", true);
            
            if (!empty($mobile_page_pg_image)) {
                $mobile_page_header_bgimages = $mobile_page_pg_image;
            } else {
                $page_pg_image = get_post_meta(get_the_ID(), "page_header_image", true);
                if (!empty($page_pg_image)) {
                    $page_header_bgimages = $page_pg_image;
                }
            }
      
    
 
            if ($mobile_device && !empty($mobile_page_header_bgimages)) : ?>
            <div class="bakground_cover yesmobile" style="background-image: url(<?php echo esc_url($mobile_page_header_bgimages); ?>);">
            </div>
        <?php else : ?>
            <div class="bakground_cover nomobile" style="background-image: url(<?php echo esc_url($page_header_bgimages); ?>);">
            </div>
        <?php endif;
    } 
    if (is_singular('post')) {
        // Get default header images for blog
        $page_header_blog = coreit_get_option('blog_page_header_bg_image');
        $mobile_page_header_blog = coreit_get_option('mobile_blog_page_header_bg_image');
        
        // Get post-specific header images
        $single_post_page_header_image = get_post_meta(get_the_ID(), 'page_header_image', true);
        $mobile_post_page_header_image = get_post_meta(get_the_ID(), 'mobile_page_header_image', true);
        
        // Determine which images to use (post-specific takes precedence over default)
        $page_header_image = !empty($single_post_page_header_image) ? $single_post_page_header_image : $page_header_blog;
        $mobile_page_header_image = !empty($mobile_post_page_header_image) ? $mobile_post_page_header_image : $mobile_page_header_blog;
        
        // Display appropriate background based on device
        if ($mobile_device && !empty($mobile_page_header_image)) : ?>
            <div class="bakground_cover yes-mobile" style="background-image: url(<?php echo esc_url($mobile_page_header_image); ?>)">
            </div>
        <?php else : ?>
            <div class="bakground_cover no-mobile" style="background-image: url(<?php echo esc_url($page_header_image); ?>)">
            </div>
        <?php endif;
    }
    if ((is_home() && !is_front_page()) || is_category() || is_tag() || is_tax()  || is_day() || is_year() || is_month()) {
        // Get header images for blog pages
        $page_header_blog = coreit_get_option('blog_page_header_bg_image');
        $mobile_page_header_blog = coreit_get_option('mobile_blog_page_header_bg_image');
        
        // Display appropriate background based on device and image availability
        if ($mobile_device && !empty($mobile_page_header_blog)) : ?>
            <div class="bakground_cover yes-mobile" style="background-image: url(<?php echo esc_url($mobile_page_header_blog); ?>)">
            </div>
        <?php elseif (!empty($page_header_blog)) : ?>
            <div class="bakground_cover no-mobile" style="background-image: url(<?php echo esc_url($page_header_blog); ?>)">
            </div>
        <?php endif;
    }
}
// coreit layout
function coreit_get_layout()
{
    global $post;
    $coreit_layout = coreit_get_option("default_layout", "right-sidebar");
    $page_layouts = coreit_get_option("page_layouts", "right-sidebar");
    $portfolio_layouts = coreit_get_option("portfolio_layouts", "right-sidebar");
    $portfolio_single_layouts = coreit_get_option("portfolio_single_layouts", "right-sidebar"); 
    $shop_layouts = coreit_get_option("shop_layouts", "right-sidebar");
    $shop_single_layouts = coreit_get_option("shop_single_layouts", "no-sidebar");
    $portfolio_page_id = coreit_get_option('portfolio_page_id');
    $service_layouts = coreit_get_option("service_layouts", "right-sidebar"); 
    $service_single_layouts = coreit_get_option("service_single_layouts", "right-sidebar"); 
    $service_page_id = coreit_get_option('service_archive_id');
    $team_layouts = coreit_get_option("team_layouts", "right-sidebar");
    $team_page_id = coreit_get_option('team_page_id');
    $job_single_layouts =  coreit_get_option('job_single_layouts'); 
    $custom_layout = get_post_meta(get_the_ID(), "custom_layout", true);
    if (is_singular() && $custom_layout == "on"):
        $coreit_layout = get_post_meta(get_the_ID(), "select_layout", true);
    elseif (is_singular("service")):
        $coreit_layout = $service_single_layouts;
        elseif (is_singular("portfolio")):
            $coreit_layout = $portfolio_single_layouts;  
    elseif(!empty($service_page_id) && is_page($service_page_id)):
        $coreit_layout = $service_layouts;
    elseif(!empty($portfolio_page_id) && is_page($portfolio_page_id)):
        $coreit_layout = $portfolio_layouts;   
    elseif(!empty($team_page_id) && is_page($team_page_id)):
        $coreit_layout = $team_layouts;
    elseif (is_singular("team")):
        $coreit_layout = $team_layouts;
        elseif (class_exists('coreitaddons\Woocommerce\Wishlist\Wishlist') && Wishlist::is_wishlist_page()):
            $coreit_layout = "no-sidebar";
            elseif (class_exists('coreitaddons\Woocommerce\Compare\Compare') && Compare::is_compare_page()):
                $coreit_layout = "no-sidebar";
    elseif (is_page()):
        $coreit_layout = $page_layouts;
    elseif (is_tax('product_cat') || is_post_type_archive('product')):
        $coreit_layout = $shop_layouts; 
    elseif (is_singular("product")):
        $coreit_layout = $shop_single_layouts; 
    elseif (is_404()):
        $coreit_layout = "no-sidebar"; 
    elseif (is_singular("mega_menu")):
        $coreit_layout = "no-sidebar";
    elseif (is_singular("header")):
        $coreit_layout = "no-sidebar";
    elseif (is_singular("footer")):
        $coreit_layout = "no-sidebar"; 
    elseif(is_singular("job_listing")):
        $coreit_layout = $job_single_layouts;    
    endif;
    return $coreit_layout;
}
// Display Columns
function coreit_get_content_columns($coreit_layout = null)
{
    $coreit_layout = $coreit_layout ? $coreit_layout : coreit_get_layout();
    if ("no-sidebar" == $coreit_layout) {
        echo esc_attr("no_column");
    } else {
        echo esc_attr("col-lg-8 col-md-12 col-sm-12 col-xs-12");
    }
}
// Column for page
function coreit_column_for_page()
{
    if (is_active_sidebar("page-sidebar")) {
        coreit_get_content_columns();
    } elseif (!is_active_sidebar("page-sidebar")) {
        echo esc_attr("no_column no_sidebar"); 
    }
}
// Column for blog
function coreit_column_for_blog(){
    if (is_active_sidebar("sidebar-blog")) {
        coreit_get_content_columns();
    } elseif (!is_active_sidebar("sidebar-blog")) {
        echo esc_attr("no_column");
    }
}
// Column for Team
function coreit_column_for_team()
{ 
    if (is_active_sidebar("team-sidebar")) {
        coreit_get_content_columns();
    } elseif (!is_active_sidebar("team-sidebar")) {
        echo esc_attr("no_column no_sidebar");
    }
}
// Column for Team
function coreit_column_for_portfolio() {
    if (is_page_template('default') || is_active_sidebar("portfolio-sidebar")) {
        coreit_get_content_columns();
    } else {
        echo esc_attr("no_column no_sidebar");
    }
}
 
// Column for service
function coreit_column_for_service()
{
    if (is_active_sidebar("service-sidebar")) {
        coreit_get_content_columns();
    } elseif (!is_active_sidebar("service-sidebar")) {
        echo esc_attr("col-lg-12 no_sidebar");
    }
} 
// Column for shop
function coreit_column_for_shop()
{
    if (is_active_sidebar("shop-sidebar")) {
        coreit_get_content_columns();
    } elseif (!is_active_sidebar("shop-sidebar")) {
        echo esc_html("no_column no_sidebar", "coreit");
    }
}
// Column for single shop
function coreit_column_for_shop_single(){
    if (is_active_sidebar("shop-single-sidebar")) {
        coreit_get_content_columns();
    } elseif (!is_active_sidebar("shop-single-sidebar")) {
        echo esc_html("no_column no_sidebar", "coreit");
    }
}
// Column for single job
function coreit_column_for_job(){
    if (is_active_sidebar("job-sidebar")) {
        coreit_get_content_columns();
    } elseif (!is_active_sidebar("job-sidebar")) {
        echo esc_html("no_column no_sidebar", "coreit");
    }
}
//  coreit pageheader after
function coreit_page_header(){
    if (!coreit_has_page_header()) {
        return;
    }
    if (
        is_page_template("template-empty.php") ||
        is_page_template("template-homepage.php") ||
        is_404()  || is_singular('coreitblocks') || is_singular('coreitsliders') || is_singular('mega_menu') 
    ):
        return false;
    endif; 
    $page_header_alignment = coreit_get_option("page_header_alignment");
    $breadcrumb_enable = coreit_get_option("breadcrumb_enable" ,  true); 
    $page_header_style  = coreit_get_option("page_header_style");  
    if(is_author()){
        ?>
        <?php if($breadcrumb_enable == true): ?>
        <div class="breadcrumbs-only"> 
        <div class="auto-container">
            <div class="row">
            <div class="col-lg-12">
    
                <?php  do_action('coreit_custom_breadcrumb');  ?>
             
            </div>
            </div>
        </div>
        </div> 
        <?php endif; ?>
        <?php
    }else{
    if ($page_header_style == "style1"): ?> 
         <?php if($breadcrumb_enable == true): ?>
            <div class="breadcrumbs-only"> 
                <div class="auto-container">
                    <div class="row">
                    <div class="col-lg-12">
              
                <?php  do_action('coreit_custom_breadcrumb');  ?>
   
                        </div>
                    </div>
                </div>
            </div> 
            <?php endif; ?>
        <?php else: ?>
            <?php if($breadcrumb_enable == true): ?>
            <div class="breadcrumbs-div">
            <?php do_action('coreit_get_page_header_image'); ?>
            <div class="inner_bx <?php echo esc_attr($page_header_alignment); ?>">
                <div class="auto-container">
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="page_title">
                            <?php the_archive_title(); ?>
                        </div>
                      
                <?php  do_action('coreit_custom_breadcrumb');  ?>
             
                        </div>
                    </div>
                </div>
        </div>
            </div> 
            <?php endif; ?>
    <?php endif;
    }
}
// coreit Header
function coreit_default_header() {
    // Check conditions to determine if default header should be shown
    if (
        is_page_template("template-empty.php") ||
        is_404() ||
        is_singular("header") ||
        is_singular("footer") ||
        is_singular("mega_menu") ||
        is_singular('coreitblocks') || is_singular('coreitsliders')
    ) {
        return false; // Return false to exit function and not show default header
    }
    // Get theme options and post meta data
    $header_sticky = coreit_get_option("header_sticky");
    $header_custom_enables = coreit_get_option("header_custom_enables");
    $header_id = coreit_get_option("header_custom_style");
    $custom_header_enable = get_post_meta(get_the_ID(), "custom_header_enable", true);
    $header_get_id = get_post_meta(get_the_ID(), "select_header_style", true);
    if ($custom_header_enable == "on" && !empty($header_get_id) && !is_post_type_archive("product") && !is_tax("product_cat") && !is_tax() && !is_tag() && !is_category()) {
        $header_id = $header_get_id;
    } elseif (is_post_type_archive("product") || is_home() || is_tax("product_cat") || is_tax() || is_tag() || is_category()) {
        $header_id = coreit_get_option("header_archive_style");
    }
    // Sticky header settings
    $sticky_heder_id = coreit_get_option("header_sticky_custom_style");
    $custom_sticky_header_enable = get_post_meta(get_the_ID(), "custom_sticky_header_enable", true);
    $sticky_get_heder_id = get_post_meta(get_the_ID(), "select_sticky_header_style", true);
    if ($custom_sticky_header_enable == "on" && !empty($sticky_get_heder_id) && !is_post_type_archive("product") && !is_tax("product_cat") && !is_tax() && !is_tag() && !is_category()) {
        $sticky_heder_id = $sticky_get_heder_id;
    } elseif (is_post_type_archive("product") || is_home() || is_tax("product_cat") || is_tax() || is_tag() || is_category()) {
        $sticky_heder_id = coreit_get_option("stickyheader_archive_style");
    }
    // Output custom header if custom enables are true and header ID is not empty
    if ($header_custom_enables == true && !empty($header_id)) {
        ?>
        <div class="header_area" id="header_contents">
            <?php echo do_shortcode('[coreit-header id="' . $header_id . '"]'); ?>
        </div>
        <?php
        // Output sticky header if sticky is enabled and sticky header ID is not empty
        if ($header_sticky == true || get_post_meta(get_the_ID(), "sticky_custom_header", true) && !empty($sticky_heder_id)) {
            ?>
            <div class="sticky_header_area sticky_header_content" id="<?php echo esc_attr($sticky_heder_id); ?>">
                <?php echo do_shortcode('[coreit-sticky-header id="' . $sticky_heder_id . '"]'); ?>
            </div>
            <?php
        }
    } else {
        // Default header output
        $blog_title = get_bloginfo("name");
        ?>
        <header class="default_header" id="header_contents">
            <div class="auto-container">
                <div class="row align-items-center">
                    <div class="col-xl-3 col-lg-3 col-md-8 col-sm-8 col-xs-8 logo_col">
                        <div class="logo_box">
                            <a href="<?php echo esc_url(home_url()); ?>" class="logo text white">
                                <?php echo esc_attr($blog_title); ?>
                                <div class="site-description"><?php bloginfo("description"); ?></div>
                            </a>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-4 col-sm-4 col-xs-4 men_col">
                        <div class="navbar_togglers hamburger_menu">
                            <i class="coreits-menu-7"></i>
                        </div>
                        <div class="navbar_content">
                            <?php
                            wp_nav_menu([
                                "theme_location" => "primary",
                                "container" => false,
                                "menu_class" => "navbar_nav white d_flex align-items-center",
                                "fallback_cb" => "coreit_navwalker::fallback",
                                "walker" => new \coreit_navwalker(),
                            ]);
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <?php
    }
}
// coreit Sidebar Menu
//  coreit Mobile Menu
function coreit_mobile_menu(){
    $allowed_tags = wp_kses_allowed_html("post"); ?>
    <div class="mobile_menu_box">
        <div class="menu-backdrop"></div>
            <nav class="menu-box scrollbarcolor">
                <div class="close-btn"><i class="close coreits-cancel"></i></div>
                <div class="menu-outer">
                    <div class="navigation_menu">
                        <ul class="navbar_nav d_flex flex-column">
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    <?php
}
//  coreit Footer 
function coreit_default_footer()
{
    if (
        is_page_template("template-empty.php") ||
        is_404() ||
        is_singular("header") ||
        is_singular("footer") || 
        is_singular("mega_menu") || is_singular('coreitblocks') || is_singular('coreitsliders')
    ) {
        return false;
    }
    $footer_id = coreit_get_option("footer_custom_style");
    $custom_footer_enable = get_post_meta(get_the_ID(), "custom_footer_enable", true);
    $footer_get_id = get_post_meta(get_the_ID(), "select_footer_style", true);
    if ($custom_footer_enable == "on" && !empty( $footer_get_id)) { 
        $footer_id  = $footer_get_id;
    }
    $footer_custom_enables = coreit_get_option("footer_custom_enable_disable");
    if ($footer_custom_enables == true) { ?>
        <div class="footer_area" id="footer_contents">
        <?php echo do_shortcode('[coreit-footer id="' . $footer_id . '"]'); ?>
        </div>
        <?php } else { ?> 
        <footer class="footer before_plugin_installation_footer footer_default  footer-bottom text-center">
            <div class="auto-container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright">
                            <?php
                            $current_year = date('Y');
                            echo esc_html("© " . $current_year . " Steelthemes. All Right Reserved", "coreit");
                            ?> 
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    <?php }
}
// portfolio style
function coreit_portfolio_style() {
    $portfolio_style = isset($_GET['pstyle']) ? $_GET['pstyle'] : '';
    return esc_html($portfolio_style);
}
 // service style
function coreit_service_style() {
    $service_style = isset($_GET['sstyle']) ? $_GET['sstyle'] : '';
    return esc_html($service_style);
}
// Team style
function coreit_team_style() {
    $tstyle = isset($_GET['tstyle']) ? $_GET['tstyle'] : '';
    return esc_html($tstyle);
} 
/**
 * Filter to handle empty excerpts
 * @param string $excerpt The post excerpt
 * @return string Modified excerpt or HTML comment if empty
 */
function coreit_empty_excerpt( $excerpt ) {
    if ( empty( $excerpt ) ) {
        return '<!-- No excerpt -->';
    }
    return $excerpt;
}
add_filter( 'get_the_excerpt', 'coreit_empty_excerpt', 20 );
  
add_action('init', function() {
    flush_rewrite_rules();
});
 
