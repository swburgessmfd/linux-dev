<?php
/***=========================Remove / Add Actions *** START=========================***/ 
// =================================Remove actions=======================================
remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10,0);
remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20,0);
remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10,0);
remove_action('woocommerce_after_shop_loop', 'woocommerce_pagination', 10);
remove_action('woocommerce_shop_loop_header', 'woocommerce_product_taxonomy_archive_header', 10);
// single removing summary 
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title',5);
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt',20);
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating',10); 
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50 ); 
// Slae Flash
remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 ); 
 // Replace SIilge Content Order
add_action( 'coreit_single_title', 'woocommerce_template_single_title',5);
add_action( 'coreit_single_excerpt', 'woocommerce_template_single_excerpt',20);
add_action( 'coreit_single_rating', 'woocommerce_template_single_rating',10);
add_action( 'coreit_single_meta', 'woocommerce_template_single_meta', 40 );  
// Remove sorting dropdown from WooCommerce
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
// =================================Add Filters=======================================
// Breadcrumb delimiter
add_filter( 'woocommerce_breadcrumb_defaults', 'coreit_change_breadcrumb_delimiter' );
// Quantity Increase and Decreaser 
// =================================Add actions=======================================
// Quantity Increase and Decreaser
add_action( 'wp_footer', 'coreit_add_cart_loop_js' ); 
add_action( 'wp_footer' , 'coreit_quantity_fields_script' ); 
// Product Per Page 
add_action('coreit_get_orderby', 'coreit_orderby', 20); 
add_action('coreit_get_per_page_product', 'coreit_custom_products_per_page_dropdown', 20);
add_action('pre_get_posts', 'coreit_custom_products_per_page');
// Product Order By
add_action('pre_get_posts', 'coreit_custom_orderby');
/***=========================Remove / Add Actions *** END=========================***/ 
/***=========================Shop Loop Header Function *** START=========================***/   
// Breadcrumb delimiter
function coreit_change_breadcrumb_delimiter( $defaults ) {
    // Change the breadcrumb delimeter from '/' to '>'
    $defaults['delimiter'] = '';
    return $defaults;
}   
// Grid View Url Option
function coreit_get_view_via_url() { 
    $coreit_views  = isset( $_GET['view'] ) ? $_GET['view'] : '';
	if($coreit_views){
		return $coreit_views;
	}
} 
// Product Per page Function
function coreit_get_per_page_option() {
	$getopt = isset($_GET['per_page']) ? $_GET['per_page'] : '';
	return esc_html($getopt);
}
function coreit_custom_products_per_page_dropdown() {
	$per_page = coreit_get_per_page_option();
	$getper_page = wc_get_default_products_per_row() * wc_get_default_product_rows_per_page();
	$options = array($getper_page, $getper_page * 2, $getper_page * 3, $getper_page * 4 , $getper_page * 5 , $getper_page * 6  , $getper_page * 7 , $getper_page * 8 , $getper_page * 9 , $getper_page * 10);
	?>
	<div class="products-per-page-box">
		<span><?php esc_html_e('Show:', 'coreit'); ?></span>
		<form class="products-per-page" method="get">
			<select name="per_page" class="per_page orderby" data-class="select-filter-per_page" onchange="this.form.submit()">
				<?php foreach ($options as $option) : ?>
					<option value="<?php echo esc_attr($option); ?>" <?php selected($per_page, $option); ?>><?php echo esc_html($option); ?></option>
				<?php endforeach; ?>
			</select>
			<?php wc_query_string_form_fields(null, array('per_page', 'submit', 'paged', 'product-page')); ?>
		</form>
	</div>
	<?php
}
function coreit_custom_products_per_page($query) {
	if (!is_admin() && $query->is_main_query()) {
		$per_page = coreit_get_per_page_option();
		if ($per_page) {
			$query->set('posts_per_page', $per_page);
		}
	}
}
// Product Orderby Function
function coreit_get_orderby_option() {
    $orderby = isset($_GET['orderby']) ? $_GET['orderby'] : 'menu_order';
    return esc_html($orderby);
}
function coreit_orderby() {
    $orderby = coreit_get_orderby_option();
    $options = array(
        'menu_order' => __('Default sorting', 'coreit'),
        'popularity' => __('Sort by popularity', 'coreit'),
        'rating' => __('Sort by average rating', 'coreit'),
        'date' => __('Sort by latest', 'coreit'),
        'price' => __('Sort by price: low to high', 'coreit'),
        'price-desc' => __('Sort by price: high to low', 'coreit')
    );
    ?>
    <form class="woocommerce-ordering" method="get">
        <span><?php echo esc_html__('Sort by: ' , 'coreit') ?></span>
        <select name="orderby" class="orderby" aria-label="<?php esc_attr_e('Shop order', 'coreit'); ?>" onchange="this.form.submit()">
            <?php foreach ($options as $value => $label) : ?>
                <option value="<?php echo esc_attr($value); ?>" <?php selected($orderby, $value); ?>><?php echo esc_html($label); ?></option>
            <?php endforeach; ?>
        </select>
        <?php wc_query_string_form_fields(null, array('orderby', 'submit', 'paged', 'product-page')); ?>
    </form>
    <?php
} 
function coreit_custom_orderby($query) {
    if (!is_admin() && $query->is_main_query()) {
        $orderby = coreit_get_orderby_option();
        if ($orderby) {
            $query->set('orderby', $orderby);
        }
    }
} 
// Quantity increaser and decrease
function coreit_quantity_fields_script(){?>
    <script type='text/javascript'>
        jQuery(function ($) {
            if (!String.prototype.getDecimals) {
                String.prototype.getDecimals = function () {
                    var num = this,
                        match = ('' + num).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
                    if (!match) {
                        return 0;
                    }
                    return Math.max(0, (match[1] ? match[1].length : 0) - (match[2] ? +match[2] : 0));
                }
            }
            // Quantity "plus" and "minus" buttons
            $(document.body).on('click', '.plus, .minus', function () {
                var $qty = $(this).closest('.quantity').find('.qty'),
                    currentVal = parseFloat($qty.val()),
                    max = parseFloat($qty.attr('max')),
                    min = parseFloat($qty.attr('min')),
                    step = $qty.attr('step');
                // Format values
                if (!currentVal || currentVal === '' || currentVal === 'NaN') currentVal = 0;
                if (max === '' || max === 'NaN') max = '';
                if (min === '' || min === 'NaN') min = 0;
                if (step === 'any' || step === '' || step === undefined || parseFloat(step) === 'NaN')
                    step = 1;
                // Change the value
                if ($(this).is('.plus')) {
                    if (max && (currentVal >= max)) {
                        $qty.val(max);
                    } else {
                        $qty.val((currentVal + parseFloat(step)).toFixed(step.getDecimals()));
                    }
                } else {
                    if (min && (currentVal <= min)) {
                        $qty.val(min);
                    } else if (currentVal > 0) {
                        $qty.val((currentVal - parseFloat(step)).toFixed(step.getDecimals()));
                    }
                }
                // Trigger change event
                $qty.trigger('change');
            });
        });
    </script>
    <?php
}   
function coreit_add_cart_loop_js() {
   wc_enqueue_js( "
       $(document).on('change','.quantity .qty',function(){
          $(this).closest('li.product , .compare-table tr , .wishlist-table tr').find('a.ajax_add_to_cart').attr('data-quantity',$(this).val());
       });
   ");
} 
/***=========================Shop Loop Header Function *** END=========================***/ 
/***=========================Get option through url *** START=========================***/ 
function coreit_get_product_card_option_via_url() {
    $productstyle  = isset( $_GET['product-style'] ) ? $_GET['product-style'] : '';
	if($productstyle){
		return $productstyle;
	}
}  
/***=========================Get option through url *** END=========================***/

/**
 * Change several of the breadcrumb defaults
 */
add_filter( 'woocommerce_breadcrumb_defaults', 'jk_woocommerce_breadcrumbs' );
function jk_woocommerce_breadcrumbs() {
    return array(
            'delimiter'   => '',
            'wrap_before' => '<ul class="breadcrumb d_flex m-auto">',
            'wrap_after'  => '</ul>',
            'before'      => '<li>',
            'after'       => '</li>',
            'home'        => _x( 'Home', 'breadcrumb', 'coreit' ),
        );
}
 
add_action('wp_enqueue_scripts', 'coreit_enqueue_variable_product_scripts');
function coreit_enqueue_variable_product_scripts() { 
    wp_enqueue_script('variable-product-badges', get_template_directory_uri() . '/assets/js/badge.js', array('jquery'), null, true);
}  
add_action('woocommerce_single_product_summary', 'coreit_display_variable_product_badges', 25); 
function coreit_display_variable_product_badges() {
    global $product;
    if ($product->is_type('variable')) {
        $variations = $product->get_available_variations();
        ?>
        <div id="variable-product-badges">
            <?php foreach ($variations as $variation) : 
                $variation_id = $variation['variation_id'];
                $regular_price = $variation['display_regular_price'];
                $sale_price = isset($variation['display_price']) ? $variation['display_price'] : $regular_price;
                $percentage_off = $regular_price > 0 ? round((($regular_price - $sale_price) / $regular_price) * 100) : 0;
                $stock_status = $variation['is_in_stock'] ? 'In Stock' : 'Out of Stock';
            ?>
                <div class="variation-badge" data-variation-id="<?php echo esc_attr($variation_id); ?>" style="display: none;">
                    <span class="stock-status"><?php echo esc_html($stock_status); ?></span>
                    <?php if ($sale_price < $regular_price && $percentage_off > 0) : ?>
                        <span class="sale-percentage"><?php echo esc_html__('Offer -' , 'coreit'); ?><?php echo esc_html($percentage_off); ?>%</span>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }
} 
add_action('coreit_badge_sale_text', 'coreit_display_product_badge_text_and_status', 20);
function coreit_display_product_badge_text_and_status() {
    global $product;
    // Get badge text and settings
    $enable_badge = coreit_addons_get_option('badge_enable', true); 
    $badge_text = get_post_meta(get_the_ID(), 'badge_text', true);
    $badge_bg_color = get_post_meta(get_the_ID(), 'product_badge_bg_color', true);
    $badge_color = get_post_meta(get_the_ID(), 'product_badge_color', true);
    $style_css = (!empty($badge_bg_color) ? "background: $badge_bg_color;" : '') . (!empty($badge_color) ? "color: $badge_color;" : '');
    // Display general badge text
    ?>
    <div class="badge_onsale d_flex align-items-center">
    <?php
    if ($enable_badge  || get_post_meta(get_the_ID(), 'enable_badge_text', true)) {
        if(!empty($badge_text)){
        echo '<div class="product-badge-text" style="' . esc_attr($style_css) . '">';
        echo esc_html($badge_text);
        echo '</div>';
        }
    } 
    do_action('coreit_item_sale_flash'); ?>
     </div>
     <?php
} 