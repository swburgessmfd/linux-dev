<?php
class Card {
    public function __construct() {
        // Remove default WooCommerce actions for product card
        $this->remove_default_actions();
        // Add custom actions
        $this->add_custom_actions();
        // Action for product card
        add_action('coreit_get_product_card_default', array($this, 'coreit_product_card_default')); 
        add_action('coreit_get_product_card_recent_views', array($this, 'coreit_product_card_recent_views')); 
        add_action('coreit_get_product_card_default_list', array($this, 'coreit_product_card_default_list')); 
    }
    // Remove default WooCommerce actions for product card
    private function remove_default_actions() {
        remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10);
        remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
        remove_action('woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10);
        remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5);
        remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
        remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
    } 
    // Add custom actions
    private function add_custom_actions() {
        // Product set look 
        add_action('woocommerce_product_set_stock', array($this,'update_original_stock_on_stock_change'));
        // Sold count progress bar
        add_action('coreit_get_shop_product_sold_count', array($this, 'coreit_shop_product_sold_count_two'));
        add_action('woocommerce_single_product_summary', array($this, 'coreit_shop_product_sold_count'));
        // Sale flash
        add_action('coreit_item_sale_flash', 'woocommerce_show_product_loop_sale_flash', 10);
        // Product Image
        add_action('coreit_get_gallery_image_on_hover', array($this, 'coreit_gallery_hover_image'), 5); 
        // category   
        add_action('coreit_get_category_name', array($this, 'coreit_category_name')); 
        // category
        add_action('coreit_get_item_title', array($this, 'coreit_product_title'), 10); 
        add_action('coreit_get_product_rating', array($this, 'coreit_product_rating'), 15); 
        add_action('coreit_get_product_price', array($this, 'coreit_product_price'), 20); 
        add_action('coreit_get_product_add_to_cart', array($this, 'coreit_product_add_to_cart'), 25);  
        add_action('coreit_get_product_add_to_cart_buynoe', array($this, 'coreit_product_add_to_cart_buynoe'), 25);  
        
        add_action('coreit_get_product_description', array($this, 'coreit_product_description'), 30);  
        add_action('coreit_get_wishlist_compare_quickview', array($this , 'coreit_wishlist_compare_quickview') , 4 );
        // Add this outside the class
add_action('woocommerce_product_set_stock', array($this, 'update_original_stock_on_stock_change'));
add_action('woocommerce_variation_set_stock', array($this, 'update_original_stock_on_stock_change'));
    } 
    public function update_original_stock_on_stock_change($product) {
        if (!$product instanceof WC_Product) {
            return;
        }
        $product_id = $product->get_id();
        $new_stock = $product->get_stock_quantity();
        
        // Always update the original stock to the new stock value
        update_post_meta($product_id, '_original_stock', $new_stock);
        
        // If it's a variation, update the parent product's stock as well
        if ($product->is_type('variation')) {
            $parent_id = $product->get_parent_id();
            $parent_product = wc_get_product($parent_id);
            if ($parent_product) {
                $parent_stock = $parent_product->get_stock_quantity();
                update_post_meta($parent_id, '_original_stock', $parent_stock);
            }
        }
    }

    public function coreit_shop_product_sold_count() {
        global $product;
        if ($product->is_type('variable')) {
            $variations = $product->get_available_variations();
            $variation_data = array();
            ?>
            <div id="variable-product-progress-bars">
            <?php foreach ($variations as $variation) :
                $variation_id = $variation['variation_id'];
                $variation_obj = wc_get_product($variation_id);
                
                // Get current stock quantity
                $current_stock = $variation_obj->get_stock_quantity();
                
                // Get the original stock quantity
                $original_stock = get_post_meta($variation_id, '_original_stock', true);
                if (empty($original_stock)) {
                    $original_stock = $current_stock;
                    update_post_meta($variation_id, '_original_stock', $original_stock);
                }
                
                // Get total sales from WooCommerce
                $sold_quantity = $variation_obj->get_total_sales();
                
                // If total sales is 0, calculate based on original and current stock
                if ($sold_quantity == 0) {
                    $sold_quantity = max(0, $original_stock - $current_stock);
                }
                
                // Calculate total (original stock)
                $total = $original_stock;
                
                // Calculate the percentage of sold items
                $percentage = $total > 0 ? round(($sold_quantity / $total) * 100, 2) : 0;
                
                // Store data for each variation in the JSON object
                $variation_data[$variation_id] = array(
                    'current_stock' => $current_stock,
                    'original_stock' => $original_stock,
                    'sold' => $sold_quantity,
                    'percentage' => $percentage
                );
                
                if($total > 0){
                ?>
                <div class="sold_progress_bar" data-variation-id="<?php echo esc_attr($variation_id); ?>" style="display: none;">
                    <div class="sold-done" style="width: <?php echo esc_attr($percentage); ?>%; opacity: 1;"></div>
                    <div class="d-flex mt_5 align-items-center justify-content-between"> 
                        <span class="font-12"><em><?php echo esc_html__('Available', 'coreit'); ?> : </em><span class="available-quantity"><?php echo esc_html($original_stock); ?></span></span>  
                        <span class="font-12"><em><?php echo esc_html__('Sold', 'coreit'); ?> : </em><span class="sold-quantity"><?php echo esc_html($sold_quantity); ?></span></span>  
                    </div> 
                </div>
            <?php } endforeach; ?>
            </div>
            <input type="hidden" id="variation_data" value='<?php echo esc_attr(json_encode($variation_data)); ?>'>
            <?php
        } elseif($product->is_type('simple')) {
            $product_id = $product->get_id();
            
            // Get current stock quantity
            $current_stock = $product->get_stock_quantity();
            
            // Get the original stock quantity
            $original_stock = get_post_meta($product_id, '_original_stock', true);
            if (empty($original_stock)) {
                $original_stock = $current_stock;
                update_post_meta($product_id, '_original_stock', $original_stock);
            }
            
            // Get total sales from WooCommerce
            $sold_quantity = $product->get_total_sales();
            
            // If total sales is 0, calculate based on original and current stock
            if ($sold_quantity == 0) {
                $sold_quantity = max(0, $original_stock - $current_stock);
            }
            
            // Calculate total (original stock)
            $total = $original_stock;
            
            // Calculate the percentage of sold items
            $percentage = $total > 0 ? round(($sold_quantity / $total) * 100, 2) : 0;
            
            if($total > 0){
            ?>
            <div class="sold_progress_bar" data-product-id="<?php echo esc_attr($product_id); ?>">
                <div class="sold-done" style="width: <?php echo esc_attr($percentage); ?>%; opacity: 1;"></div>
                <div class="d-flex mt_5 align-items-center justify-content-between"> 
                    <span class="font-12"><em><?php echo esc_html__('Available', 'coreit'); ?> : </em><span class="available-quantity"><?php echo esc_html($original_stock); ?></span></span>  
                    <span class="font-12"><em><?php echo esc_html__('Sold', 'coreit'); ?> : </em><span class="sold-quantity"><?php echo esc_html($sold_quantity); ?></span></span>  
                </div> 
            </div> 
            <input type="hidden" id="simple_product_data" value='<?php echo esc_attr(json_encode([
                'current_stock' => $current_stock,
                'original_stock' => $original_stock,
                'sold' => $sold_quantity,
                'percentage' => $percentage
            ])); ?>'>
            <?php
            }
        }
    }

    public function coreit_shop_product_sold_count_two() {
        $sold_items_enable = coreit_get_option('sold_items_enable' , true);
        if($sold_items_enable == false){
            return;
        }
        global $product;
        if ($product) {
            $product_id = $product->get_id();
            
            // Get current stock quantity
            $current_stock = $product->get_stock_quantity();
            if ($current_stock === null) {
                $current_stock = get_post_meta($product_id, '_stock', true);
                if ($current_stock === '') {
                    $current_stock = 0;
                }
            }
            
            // Get total sales from WooCommerce
            $sold_quantity = $product->get_total_sales();
            
            // Calculate the original stock
            $original_stock = $current_stock;
            
            // Update the _original_stock meta
            update_post_meta($product_id, '_original_stock', $original_stock);
            
            // Calculate the percentage of sold items
            $progress_percentage = $original_stock > 0 ? round(($sold_quantity / $original_stock) * 100, 2) : 0;
            
            if($sold_quantity > 0): 
            ?>
            <div class="sold_progress_bar">
                <div class="sold-done" data-done="<?php echo esc_attr($progress_percentage) ?>">
                </div>
                <div class="d-flex mt_5 align-items-center justify-content-between"> 
                    <span class="font-12"><em><?php echo esc_html__('Available', 'coreit'); ?> : </em><?php echo esc_html($original_stock); ?>
                    </span>  
                    <span class="font-12"><em><?php echo esc_html__('Sold', 'coreit'); ?> :</em> <?php echo esc_html($sold_quantity); ?>
                    </span>  
                </div> 
            </div> 
            <?php
            endif;
        }
    }

     // Add this new method to recalculate and update original stock for all products
     public function recalculate_all_original_stock() {
        $args = array(
            'post_type'      => array('product', 'product_variation'),
            'posts_per_page' => -1,
        );
        $products = get_posts($args);

        foreach ($products as $product_post) {
            $product = wc_get_product($product_post->ID);
            if ($product) {
                $current_stock = $product->get_stock_quantity();
                $sold_quantity = $product->get_total_sales();
                $original_stock = $current_stock + $sold_quantity;
                update_post_meta($product->get_id(), '_original_stock', $original_stock);
            }
        }
    }
    // Product hover image
    public function coreit_gallery_hover_image() {
        global $product;
        $product_id = get_the_ID();
        $product_permalink = get_permalink($product_id);
       if (has_post_thumbnail()) {
            ?>
            <a href="<?php echo esc_url($product_permalink); ?>">
                <?php woocommerce_template_loop_product_thumbnail(); ?>
            </a>
            <?php
        }  
    } 
    // Product Category Image /  Name
    public function coreit_category_name() { 
        $category_enable = coreit_get_option('category_enable' , true);
        if($category_enable == false){
            return;
        }
        global $product;
        $product_id = get_the_ID(); // Assuming you're inside the product loop
        $category_terms = get_the_terms( $product_id, 'product_cat' );
        if ( ! is_wp_error( $category_terms ) && ! empty( $category_terms ) ) {
            $category_term = array_shift( $category_terms );
            $category_name = $category_term->name;
            $category_link = get_term_link( $category_term );  
           ?>
            <a class="text-16 content-color-one catpro d-block mb_5" href="<?php echo esc_url( $category_link ); ?>"> 
                    <?php echo esc_attr( $category_name ); ?> 
            </a>
            <?php
        }
    }
    // Product Title
    public function coreit_product_title() {
        global $product; 
        $product_title_permalink = get_permalink(get_the_ID()); // Get the product's permalink  
        ?>
            <a href="<?php echo esc_url($product_title_permalink); ?>"><div class="font-22 mb_10 trim-2"><?php the_title(); ?></div></a>
        <?php
    }
    // Product Price
    public function coreit_product_price() {
        global $product;  
        $allowed_tags = wp_kses_allowed_html('post');
        ?>
          <?php if($price_html = $product->get_price_html() ) : ?>
            <div class="comprice"><?php echo wp_kses($price_html , $allowed_tags); ?></div>
        <?php endif; ?>
        <?php
    }
    // Product Rating
    public function coreit_product_rating() { 
        global $product; 
        $rating_enable = coreit_get_option('rating_enable' , true);
        if($rating_enable == false){
            return;
        }
        $average = $product->get_average_rating();
        $ratingcount = $product->get_review_count();
        echo '<div class="product-rate  d_flex align-items-center"><span class="star-rating"><span style="width:'.( ( esc_attr($average) / 5 ) * 100 ) . '%"><strong  class="rating">'.esc_attr($average).'</strong> '.__( 'out of 5', 'coreit' ).'</span></span> <span class="font-12">(' .esc_attr($ratingcount).')</span></div>';
    }
     // Product Add to Cart 
    public function coreit_product_add_to_cart() {  
        $add_to_cart_enable_disable = coreit_get_option('add_to_cart_enable_disable' , true);
        if($add_to_cart_enable_disable == false){
            return;
        }  
        woocommerce_template_loop_add_to_cart();   
           
    }
    public function coreit_product_add_to_cart_buynoe() { 
    do_action('getsimple_buy_now_button'); 
    }
    //  Product Short Decription 
    public function coreit_product_description() { 
        $shortdesc_enable = coreit_get_option('shortdesc_enable' , true);
        if($shortdesc_enable == false){
            return;
        }   
        global $product; 
        $excerpt = get_the_excerpt( $product->get_id());
        $allowed_tags = wp_kses_allowed_html('post');
        ?>
        <div class="list-features-six">
            <?php echo wp_kses($excerpt , $allowed_tags); ?>
        </div>
        <?php
    } 
    //  Quick View , Compare ,  Wishlist code 
    public function coreit_wishlist_compare_quickview() { 
        ?>  
          <div class="wis_co_qu trans d_flex">
            <?php 
            $quick_view_enable = coreit_get_option('quick_view_enable' , true);
            $comp_enable = coreit_get_option('comp_enable' , true);
            $wish_enable = coreit_get_option('wish_enable' , true);
                do_action('coreit_get_trending_product'); 
                if($wish_enable == true):
                do_action('coreit_get_wishlist_button'); 
            endif;
                if($comp_enable == true):
                do_action('coreit_get_compare_button'); 
            endif;
                if($quick_view_enable == true):
                do_action('quick_view_buttons'); 
                endif;
            ?>
        </div>
        <?php
    } 
    // Product card
    public function coreit_product_card_default() {
        global $product;
        $product_type = $product->get_type(); 
        ?>
        <div class="product_box style_one">
                <div class="in_upper_box position-relative">
                <?php  
                        $badge_enable = coreit_get_option('badge_enable' , true);
                        if($badge_enable == true):
                        ?>
                        <div class="d_flex badges_box">
                            <?php 
                            if ($product_type === 'variable') {
                                do_action('coreit_badge_sale_text');
                            }else{
                                do_action('coreit_get_sales_badges'); 
                            }
                            ?> 
                        </div>
                        <?php endif; ?>
                    <?php do_action('coreit_get_gallery_image_on_hover'); ?>
                    <?php do_action('coreit_get_wishlist_compare_quickview'); ?>  
                    <div class="position-relative ship_cart">
                    <?php do_action('coreit_get_shipping_name'); ?> 
                    <div class="price_cart_box d_flex align-items-center">
                        <?php do_action('coreit_get_product_price'); ?>  
                        <?php do_action('coreit_get_product_add_to_cart_buynoe'); ?>  
                        
                    </div>
                    </div>
                </div> 
                <div class="in_lower_box">  
                    <?php if ($product_type === 'simple') { do_action('coreit_get_shop_product_sold_count'); } ?> 
                    <?php do_action('coreit_get_category_name'); ?>    
                    <?php do_action('coreit_get_product_rating'); ?> 
                    <?php do_action('coreit_get_item_title'); ?>   
                    <?php do_action('coreit_get_product_deals'); ?>  
            
                            <?php do_action('coreit_get_product_add_to_cart'); ?>  
                 
                </div>
        </div> 
        <?php 
    }
    // Product Recent views
    public function coreit_product_card_recent_views() {
        global $product;
        $product_type = $product->get_type(); 
        ?>
        <div class="product_box style_recentview">
            <div class="d_flex align-items-center">
                <div class="image_box">
                <?php do_action('coreit_get_gallery_image_on_hover'); ?>
                </div>
                <div class="content_box">
                <?php do_action('coreit_get_product_rating'); ?> 
                <?php do_action('coreit_get_item_title'); ?>  
                <?php do_action('coreit_get_product_price'); ?>  

                <div class="d_flex btnsss mt_15 align-items-center">
                <?php do_action('coreit_get_product_add_to_cart'); ?> 
                </div> 
                </div>  
                </div>  
        </div> 
        <?php 
    }
    
   
      // Product card list view
    public function coreit_product_card_default_list() {
    global $product;
    $product_type = $product->get_type(); 
    ?>
     <div class="product_box display_listtype">
                <div class="upper_box d_flex align-items-center justify-content-between">  
                    <div class="d_flex cmeta">
                        <div class="d_flex cmeta_in"> 
                        <?php do_action('coreit_get_category_name'); ?>  
                        </div> 
                        <?php do_action('coreit_get_low_stock_status_thresold'); ?> 
                    </div> 
                    <?php do_action('coreit_get_shipping_name'); ?> 
                </div>
                <div class="d_flex">
                    <div class="left_box position-relative"> 
                        <?php  
                        $badge_enable = coreit_get_option('badge_enable' , true);
                        if($badge_enable == true):
                        ?>
                        <div class="d_flex badges_box">
                            <?php 
                               if ($product_type === 'variable') {
                                do_action('coreit_badge_sale_text');
                            }else{
                                do_action('coreit_get_sales_badges'); 
                            }
                            ?> 
                        </div> 
                        <?php endif ?>
                            <?php if(!empty($product_deals_images)): ?>
                                 <img src="<?php echo esc_url($product_deals_images); ?>" alt="<?php the_title(); ?>">
                            <?php else: ?>
                                <?php do_action('coreit_get_gallery_image_on_hover'); ?>
                         <?php endif; ?>
                         <?php do_action('coreit_get_wishlist_compare_quickview'); ?> 
                    </div>  
                    <div class="right_box">    
                        <?php do_action('coreit_get_item_title'); ?> 
                        <div class="mb_10">
                        <?php do_action('coreit_get_product_rating'); ?> 
                        </div>
                        <div class="mb_10">
                        <?php do_action('coreit_get_product_price'); ?>    
                       </div>   
                      <?php do_action('coreit_get_product_description'); ?>
                       
                        <?php    if ($product_type === 'simple') { do_action('coreit_get_shop_product_sold_count'); } ?>
                        <div class="buttondflex d_flex">
                        <?php do_action('coreit_get_product_add_to_cart'); ?>   
                        </div>
                    </div>
                </div>
                <?php do_action('coreit_get_product_deals'); ?>
                </div>
        <?php 
    }
}
new Card(); 
