<?php
/*
 ** ==============================
 ** coreit Post Function
 ** ==============================
 */
add_action("coreit_theme_blog_comments", "coreit_comments"); 
add_action("coreit_theme_blog_time", "coreit_blog_time");
add_action("coreit_theme_blog_time_two", "coreit_blog_time_two");
add_action("coreit_theme_blog_time_three", "coreit_blog_time_three");
add_action("coreit_theme_blog_category", "coreit_blog_category");
add_action("coreit_theme_blog_tags_and_cat", "coreit_tags_and_cat"); 
add_action("coreit_after_blogsetup_comment_timing", "coreit_comment_timing"); 
add_action("coreit_get_display_author_name_link", "coreit_display_author_name_link"); 

add_action("coreit_get_display_display_author", "coreit_display_author"); 
// Authour
function coreit_display_author_name_link() {
    // Get the author's display name
    $author_name = get_the_author();
    // Get the author's archive link
    $author_link = get_author_posts_url(get_the_author_meta('ID'));
    // Display the author's name with a link
    echo '<small class="meta_authour">
    <a href="' . esc_url($author_link) . '" class="font-16 content-color-one"><i class="coreits-user"></i>' . esc_html($author_name) . '</a>
    </small>';
}
function coreit_display_author() {
     // Get the author's display name
     $author_name = get_the_author();
     // Get the author's archive link
     $author_link = get_author_posts_url(get_the_author_meta('ID'));
     // Get the author's avatar
     $author_avatar = get_avatar(get_the_author_meta('ID'), 48); // 48 is the size of the avatar in pixels
     
     // Display the author's name with an avatar, link, and "More posts by [Author Name]" text
     echo '<div class="meta_author_two d-flex align-items-center">
                <a href="' . esc_url($author_link) . '">
                    ' . $author_avatar . '  </a>
                   
              
                <div class="athcon"> <div class="font-18">' . esc_html($author_name) . '</div>
         <a href="' . esc_url($author_link) . '">'. esc_html__('More posts' , 'coreit') .'</a>
         </div>
     </div>';
}

//  Comments
function coreit_comments(){
?>
    <div class="meta_comments">  
        <i class="coreits-chat"></i>
        <?php 
        $css_class = 'zero-comments';
        $number    = (int) get_comments_number( get_the_ID() );
        if ( 1 === $number )
            $css_class = 'one-comment';
        elseif ( 1 < $number )
            $css_class = 'multiple-comments';
        comments_popup_link( 
            __( 'Post a Comment', 'coreit' ), 
            __( '1 Comment', 'coreit' ), 
            __( '% Comments', 'coreit' ),
            $css_class,
            __( 'Comments are Closed', 'coreit' )
        );
        ?>
    </div>
<?php
}
// Blog Timing
function coreit_blog_time(){
    $time_string =
        '<time class="meta_date d_flex align-items-center  published updated" datetime="%1$s"><i class="coreits-clock mr-5"></i><span>%2$s</span></time>';
    if (get_the_time("U") !== get_the_modified_time("U")) {
        $time_string =
            '<time class="meta_date d_flex align-items-center published" datetime="%1$s"><i class="coreits-clock mr-5"></i><span>%2$s</span></time>';
    }
    $time_string = sprintf(
        $time_string,
        esc_attr(get_the_date("c")),
        esc_html(get_the_date(get_option("date_format")))
    );
    $posted_on = '' . $time_string . "";
    echo "" . $posted_on . "";
}
// Date Date
function coreit_blog_time_two() {
    $date = get_the_date('j');
    $month = get_the_date('M');
    $year = get_the_date('y'); 
    $time_string = '<time class="date_differnet published updated" datetime="%1$s"><span class="big">%2$s</span> <span class="font-14">%3$s, %4$s</span></time>';
    if (get_the_time("U") !== get_the_modified_time("U")) {
        $time_string = '<time class="date_differnet published" datetime="%1$s"><span class="big">%2$s</span> <span class="font-14">%3$s, %4$s</span></time>';
    }
    $time_string = sprintf(
        $time_string,
        esc_attr(get_the_date("c")),
        esc_html($date),
        esc_html($month),
        esc_html($year)
    );
    $posted_on = '' . $time_string . "";
    echo "" . $posted_on . "";
}
// Date Date
function coreit_blog_time_three() {
    $date = get_the_date('j');
    $month = get_the_date('F');
    $year = get_the_date('Y'); 
    $time_string = '<time class="date_differnet published updated" datetime="%1$s"><span class="big">%2$s</span> <span class="font-14">%3$s, %4$s</span></time>';
    if (get_the_time("U") !== get_the_modified_time("U")) {
        $time_string = '<time class="date_differnet published" datetime="%1$s"><span class="big">%2$s</span> <span class="font-14">%3$s, %4$s</span></time>';
    }
    $time_string = sprintf(
        $time_string,
        esc_attr(get_the_date("c")),
        esc_html($date),
        esc_html($month),
        esc_html($year)
    );
    $posted_on = '' . $time_string . "";
    echo "" . $posted_on . "";
}
// Blog Category
function coreit_blog_category(){
    $categories = get_the_category();
    if (!empty($categories)) {
        echo '<a href="' .
            esc_url(get_category_link($categories[0]->term_id)) .
            '" class="category_btn">' .
             esc_html($categories[0]->name) .
            "</a>";
    }
}
// Tag and Category After Install
function coreit_tags_and_cat() {
    $tag_enable = coreit_get_option('tag_enable', false);
    $category_enable = coreit_get_option('category_enables', false);
    $categories = get_the_category();
    $tags = get_the_tags(); 
    if ($tag_enable == true || !empty($tags) || !empty($categories) || $category_enable == true): ?>
        <div class="tags_and_cat<?php echo !empty($tags) && $tag_enable ? ' yes_tags' : ''; ?> <?php echo !empty($categories) && $category_enable ? ' yes_cate' : ''; ?>">
            <div class="d-flex">
                <?php if ($tag_enable == true): ?>
                    <?php if (!empty($tags)): ?>
                    <div class="left_one d-flex">
                        <div class="title"><?php echo esc_html__('Tags', 'coreit'); ?></div>
                        <?php foreach ($tags as $tag): ?>
                            <a class="tags" href="<?php echo esc_url(get_term_link($tag)); ?>">
                                <?php echo esc_html__('#', 'coreit') . esc_html($tag->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <?php endif; ?>
                <?php if ($category_enable == true): ?>
                    <?php if(!empty($categories)): ?>
                    <div class="right_one d-flex">
                        <div class="title"><?php echo esc_html__('Posted in', 'coreit'); ?></div>
                        <?php foreach ($categories as $category): ?>
                            <a class="cats" href="<?php echo esc_url(get_term_link($category)); ?>">
                                <?php echo esc_html($category->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    <?php endif;
}
// Comment Timing
function coreit_comment_timing(){
    $comment_date = get_comment_time("U");
    $dayscomment = round((date("U") - get_comment_time("U")) / (60 * 60 * 24));
    $deltacomment = time() - $comment_date;
    if ($deltacomment < 60) {
        echo esc_html("Less than a minute ago", "coreit");
    } elseif ($deltacomment > 60 && $deltacomment < 120) {
        echo esc_html("About a minute ago", "coreit");
    } elseif ($deltacomment > 120 && $deltacomment < 60 * 60) {
        echo strval(round($deltacomment / 60, 0)) . " minutes ago";
    } elseif ($deltacomment > 60 * 60 && $deltacomment < 120 * 60) {
        echo esc_html("About an hour ago", "coreit");
    } elseif ($deltacomment > 120 * 60 && $deltacomment < 24 * 60 * 60) {
        echo strval(round($deltacomment / 3600, 0)) . " hours ago";
    } else {
        echo get_comment_date();
    }
}
 
 
// Track post views
function coreit_set_post_views($postID) {
    $count_key = 'coreit_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if ($count == '') {
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    } else {
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}

// Display post views
function coreit_get_post_views($postID) {
    $count_key = 'coreit_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if ($count == '') {
        return '0 Views';
    }
    return $count . ' Views';
}

// Hook to increment views on single post - FIXED version without like reset
function coreit_track_post_views($postID) {
    if (!is_single()) return;

    if (empty($postID)) {
        global $post;
        $postID = $post->ID;
    }

    coreit_set_post_views($postID);
}

add_action('wp_head', 'coreit_track_post_views');

// AJAX for toggling post like - IMPROVED version
function coreit_post_like_toggle() {
    // Verify nonce for security
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coreit_like_nonce')) {
        wp_send_json_error('Invalid security token');
        return;
    }

    $post_id = intval($_POST['post_id']);
    $user_id = get_current_user_id();

    // Enhanced check for logged-in users
    if (!$user_id) {
        wp_send_json_error([
            'message' => 'Please log in to like posts',
            'code' => 'login_required',
            'redirect_url' => wp_login_url(get_permalink($post_id)) // Add login URL for redirect
        ]);
        return;
    }

    // Rest of your existing like toggle logic...
    $liked_posts = get_user_meta($user_id, 'coreit_liked_posts', true);
    $liked_posts = $liked_posts ? $liked_posts : [];

    if (in_array($post_id, $liked_posts)) {
        // Remove like logic...
        $liked_posts = array_values(array_diff($liked_posts, [$post_id]));
        update_user_meta($user_id, 'coreit_liked_posts', $liked_posts);
        
        $like_count = get_post_meta($post_id, 'coreit_post_likes_count', true);
        $like_count = max(0, intval($like_count) - 1);
        update_post_meta($post_id, 'coreit_post_likes_count', $like_count);

        wp_send_json_success([
            'liked' => false,
            'count' => $like_count,
            'text' => $like_count . ' Likes'
        ]);
    } else {
        // Add like logic...
        $liked_posts[] = $post_id;
        update_user_meta($user_id, 'coreit_liked_posts', array_unique($liked_posts));

        $like_count = get_post_meta($post_id, 'coreit_post_likes_count', true);
        $like_count = intval($like_count) + 1;
        update_post_meta($post_id, 'coreit_post_likes_count', $like_count);

        wp_send_json_success([
            'liked' => true,
            'count' => $like_count,
            'text' => $like_count . ' Likes'
        ]);
    }
}


add_action('wp_ajax_coreit_post_like_toggle', 'coreit_post_like_toggle');

// Display like count
function coreit_get_post_likes($postID) {
    $like_count = get_post_meta($postID, 'coreit_post_likes_count', true);
    return intval($like_count) . ' Likes';
}

// Enqueue scripts with nonce
function coreit_enqueue_scripts() {
    wp_enqueue_script('coreit-post-likes', get_template_directory_uri() . '/includes/main/post/post-like.js', array('jquery'), null, true);
    wp_localize_script('coreit-post-likes', 'coreitAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('coreit_like_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'coreit_enqueue_scripts');

function coreit_customize_register( $wp_customize ) {
    // Add section for the reset option
    $wp_customize->add_section( 'coreit_reset_section', array(
        'title'       => __( 'Reset Post Views and Likes', 'coreit' ),
        'description' => __( 'Reset the views and likes count for posts.', 'coreit' ),
        'priority'    => 100,
        'panel' => 'coreit_blog_settings',
    ) );

    // Add setting for reset
    $wp_customize->add_setting( 'coreit_reset_views_likes', array(
        'default'           => false,
        'sanitize_callback' => 'coreit_sanitize_checkbox',
    ) );

    // Add control for the reset option
    $wp_customize->add_control( 'coreit_reset_views_likes', array(
        'label'       => __( 'Reset Views and Likes', 'coreit' ),
        'section'     => 'coreit_reset_section',
        'type'        => 'checkbox',
        'description' => __( 'Check this box to reset the post views and likes count for all posts.', 'coreit' ),
    ) );
}

add_action( 'customize_register', 'coreit_customize_register' );

 
function coreit_reset_views_and_likes() {
    // Check if the reset option is enabled
    $reset_enabled = get_theme_mod( 'coreit_reset_views_likes', false );

    if ( $reset_enabled ) {
        // Get all posts
        $args = array(
            'posts_per_page' => -1, // Get all posts
            'post_type'      => 'post',
            'post_status'    => 'publish',
        );

        $posts = get_posts( $args );

        // Loop through each post and reset views and likes
        foreach ( $posts as $post ) {
            // Reset post views
            delete_post_meta( $post->ID, 'coreit_post_views_count' );

            // Reset post likes
            delete_post_meta( $post->ID, 'coreit_post_likes_count' );

            // Reset user likes (if any)
            $user_likes = get_users( array( 'meta_key' => 'coreit_liked_posts' ) );
            foreach ( $user_likes as $user ) {
                $liked_posts = get_user_meta( $user->ID, 'coreit_liked_posts', true );
                if ( is_array( $liked_posts ) && in_array( $post->ID, $liked_posts ) ) {
                    $liked_posts = array_diff( $liked_posts, [ $post->ID ] );
                    update_user_meta( $user->ID, 'coreit_liked_posts', $liked_posts );
                }
            }
        }

        // Optionally reset the customizer setting to avoid repeated resets
        set_theme_mod( 'coreit_reset_views_likes', false );
    }
}

add_action( 'init', 'coreit_reset_views_and_likes' );

function coreit_display_like_button($post_id) {
    $user_id = get_current_user_id();
    $liked_posts = get_user_meta($user_id, 'coreit_liked_posts', true);
    $liked_posts = $liked_posts ? $liked_posts : [];
    $is_liked = in_array($post_id, $liked_posts);
    $like_count = get_post_meta($post_id, 'coreit_post_likes_count', true);
    $like_count = intval($like_count);
    
    // Different button classes and data attributes based on login status
    $button_class = 'coreitlike-button trans';
    $button_class .= $user_id ? ($is_liked ? ' liked' : '') : ' login-required';
    
    ?>
    <div class="<?php echo esc_attr($button_class); ?>" 
         data-post-id="<?php echo esc_attr($post_id); ?>"
         <?php if (!$user_id) : ?>
         data-login-url="<?php echo esc_url(wp_login_url(get_permalink($post_id))); ?>"
         <?php endif; ?>>
        <i class="coreits-heart trans"></i>
        <span class="coreitlike-count trans"><?php echo esc_html($like_count . ' Likes'); ?></span>
    </div>
    <?php
}

