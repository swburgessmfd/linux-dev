jQuery(document).ready(function($) {
    $('.coreitlike-button').on('click', function(e) {
        e.preventDefault();
        
        var button = $(this);
        
        // Check if login is required
        if (button.hasClass('login-required')) {
            var loginUrl = button.data('login-url');
            if (confirm('Please log in to like posts. Would you like to log in now?')) {
                window.location.href = loginUrl;
            }
            return;
        }
        
        var postID = button.data('post-id');
        
        $.post(coreitAjax.ajax_url, {
            action: 'coreit_post_like_toggle',
            post_id: postID,
            nonce: coreitAjax.nonce
        }, function(response) {
            if (response.success) {
                // Update like count
                button.find('.coreitlike-count').text(response.data.text);
                
                // Update button state
                if (response.data.liked) {
                    button.addClass('liked');
                } else {
                    button.removeClass('liked');
                }
            } else {
                if (response.data.code === 'login_required') {
                    if (confirm(response.data.message + ' Would you like to log in now?')) {
                        window.location.href = response.data.redirect_url;
                    }
                } else {
                    alert(response.data.message || 'Error processing your request.');
                }
            }
        }).fail(function() {
            alert('Error processing your request. Please try again.');
        });
    });
});