/**
 * Theme Setup Wizard JavaScript
 * 
 * This file handles all the AJAX functionality for the theme setup wizard
 */

jQuery(document).ready(function($) {
    'use strict';

    /**
     * Plugin Installation and Activation
     */
    var pluginQueue = [];
    var currentPluginIndex = 0;
    var isInstalling = false;
    
    // Select all plugins checkbox
    $('#select-all-plugins').on('change', function() {
        var isChecked = $(this).prop('checked');
        $('.plugin-checkbox:not(:disabled)').prop('checked', isChecked);
    });

    // Individual plugin installation/activation
    $('.install-plugin, .activate-plugin').on('click', function(e) {
        e.preventDefault();
        
        var button = $(this);
        var action = button.data('action');
        var pluginRow = button.closest('tr');
        var slug = pluginRow.data('plugin-slug');
        var source = pluginRow.data('plugin-source');
        var path = pluginRow.data('plugin-path');
        
        // Disable button during operation
        button.prop('disabled', true);
        
        if (action === 'install') {
            installPlugin(button, slug, source, path);
        } else if (action === 'activate') {
            activatePlugin(button, slug, path);
        }
    });
    
    // Delegate event handler for dynamically created buttons
    $(document).on('click', '.install-plugin, .activate-plugin', function(e) {
        e.preventDefault();
        
        var button = $(this);
        var action = button.data('action');
        var pluginRow = button.closest('tr');
        var slug = pluginRow.data('plugin-slug');
        var source = pluginRow.data('plugin-source');
        var path = pluginRow.data('plugin-path');
        
        // Disable button during operation
        button.prop('disabled', true);
        
        if (action === 'install') {
            installPlugin(button, slug, source, path);
        } else if (action === 'activate') {
            activatePlugin(button, slug, path);
        }
    });
    
    // Install selected plugins
    $('.install-selected-plugins').on('click', function(e) {
        e.preventDefault();
        
        var button = $(this);
        button.prop('disabled', true);
        button.text('Processing...');
        
        // Build plugin queue with selected plugins
        pluginQueue = [];
        $('.plugin-checkbox:checked').each(function() {
            var row = $(this).closest('tr');
            var slug = row.data('plugin-slug');
            var source = row.data('plugin-source');
            var path = row.data('plugin-path');
            var status = row.find('.plugin-status').attr('class') || '';
            status = status.replace('plugin-status ', '');
            
            pluginQueue.push({
                row: row,
                slug: slug,
                source: source,
                path: path,
                status: status
            });
        });
        
        // Start processing queue
        currentPluginIndex = 0;
        processPluginQueue();
    });
    
    // Process plugin queue one by one
    function processPluginQueue() {
        if (currentPluginIndex >= pluginQueue.length) {
            // Queue completed
            $('.install-selected-plugins').text('All Plugins Installed & Activated');
            $('.plugin-installation-progress').html('<div class="notice notice-success"><p>All selected plugins have been installed and activated successfully.</p></div>');
            
            // Enable next button
            $('.next-step').prop('disabled', false).attr('href', function() {
                return $(this).attr('href') + '&plugins_installed=true';
            });
            return;
        }
        
        var plugin = pluginQueue[currentPluginIndex];
        var row = plugin.row;
        var button = row.find('button');
        
        // Update progress message
        $('.plugin-installation-progress').html('<div class="notice notice-info"><p>Processing: ' + (currentPluginIndex + 1) + ' of ' + pluginQueue.length + ' plugins</p></div>');
        
        // Safely get plugin status
        var status = plugin.status;
        
        if (status === 'not-installed' || status === '') {
            // Install and then activate
            installPlugin(button, plugin.slug, plugin.source, plugin.path, function() {
                activatePlugin(button, plugin.slug, plugin.path, function() {
                    currentPluginIndex++;
                    processPluginQueue();
                });
            });
        } else if (status === 'inactive') {
            // Just activate
            activatePlugin(button, plugin.slug, plugin.path, function() {
                currentPluginIndex++;
                processPluginQueue();
            });
        } else {
            // Skip already active plugins
            currentPluginIndex++;
            processPluginQueue();
        }
    }
    
    // Install plugin function with error handling
    function installPlugin(button, slug, source, path, callback) {
        button.text(theme_setup_wizard.plugin_texts.installing);
        
        $.ajax({
            url: theme_setup_wizard.ajaxurl,
            type: 'POST',
            data: {
                action: 'install_plugin',
                nonce: theme_setup_wizard.nonce,
                slug: slug,
                source: source
            },
            success: function(response) {
                if (response.success) {
                    // Update the button to become an activation button
                    button.text(theme_setup_wizard.plugin_texts.installed);
                    button.data('action', 'activate');
                    button.removeClass('install-plugin').addClass('activate-plugin');
                    button.prop('disabled', false);  // Enable the button for activation
                    
                    // Update status in the row
                    button.closest('tr').find('.plugin-status')
                          .removeClass('not-installed')
                          .addClass('inactive')
                          .text('Installed');
                    
                    // If this is part of a queue, continue with activation
                    if (typeof callback === 'function') {
                        callback();
                    } else {
                        // If clicked individually, prompt user to activate
                        button.text('Activate');
                    }
                } else {
                    handlePluginError(button, slug, 'installation', response.data ? response.data.message : null, callback);
                }
            },
            error: function(xhr, status, error) {
                handlePluginError(button, slug, 'installation', error, callback);
            }
        });
    }
    
    // Activate plugin function with error handling
    function activatePlugin(button, slug, path, callback) {
        button.text(theme_setup_wizard.plugin_texts.activating);
        
        $.ajax({
            url: theme_setup_wizard.ajaxurl,
            type: 'POST',
            data: {
                action: 'activate_plugin',
                nonce: theme_setup_wizard.nonce,
                slug: slug,
                path: path
            },
            success: function(response) {
                if (response.success) {
                    button.text(theme_setup_wizard.plugin_texts.activated);
                    button.prop('disabled', true);
                    
                    // Update status in the row
                    button.closest('tr').find('.plugin-status')
                          .removeClass('inactive')
                          .addClass('active')
                          .text('Active');
                    
                    // Replace button with checkmark
                    button.replaceWith('<span class="dashicons dashicons-yes"></span>');
                    
                    if (typeof callback === 'function') {
                        callback();
                    }
                } else {
                    handlePluginError(button, slug, 'activation', response.data ? response.data.message : null, callback);
                }
            },
            error: function(xhr, status, error) {
                handlePluginError(button, slug, 'activation', error, callback);
            }
        });
    }
    
    // Helper function to handle plugin errors but continue with queue
    function handlePluginError(button, slug, operation, errorMessage, callback) {
        console.error('Plugin ' + operation + ' failed for ' + slug + ':', errorMessage);
        
        // Show error in UI but in a non-blocking way
        var errorNotice = '<div class="notice notice-error inline"><p>' + 
            'Failed to ' + operation + ' ' + slug + 
            (errorMessage ? ': ' + errorMessage : '') + 
            '</p></div>';
            
        $('.plugin-installation-progress').append(errorNotice);
        
        // Reset button state
        if (operation === 'installation') {
            button.text(theme_setup_wizard.plugin_texts.install_failed);
            button.prop('disabled', false);
        } else {
            button.text(theme_setup_wizard.plugin_texts.activation_failed);
            button.prop('disabled', false);
        }
        
        // Continue with next plugin instead of stopping the entire process
        if (typeof callback === 'function') {
            callback();
        }
    }
    
    // Child theme installation
    $('input[name="install_child_theme"]').on('change', function() {
        if ($(this).is(':checked')) {
            var installButton = $('<button>', {
                type: 'button',
                class: 'button button-primary install-child-theme',
                text: 'Install Child Theme Now'
            });
            
            if ($('.install-child-theme').length === 0) {
                $('#child_theme_status').append(installButton);
            }
        } else {
            $('.install-child-theme').remove();
        }
    });

    // Trigger the change event to initialize the UI
    $('input[name="install_child_theme"]').trigger('change');
    
    // Child theme installation AJAX handler
    $(document).on('click', '.install-child-theme', function() {
        var button = $(this);
        var status = $('#child_theme_status');
        
        button.prop('disabled', true).text('Installing...');
        status.append('<p class="installing">Installing child theme...</p>');
        
        $.ajax({
            url: theme_setup_wizard.ajaxurl,
            type: 'POST',
            data: {
                action: 'install_child_theme',
                nonce: theme_setup_wizard.nonce
            },
            success: function(response) {
                status.find('.installing').remove();
                if (response.success) {
                    button.text('Installed').addClass('button-disabled');
                    status.append('<p class="success">' + response.data.message + '</p>');
                    
                    // Replace child-theme-option with success message
                    setTimeout(function() {
                        $('.child-theme-option').replaceWith(
                            '<div class="notice notice-success">' +
                            '<p>Child theme is now installed and active.</p>' +
                            '</div>'
                        );
                    }, 1000);
                } else {
                    button.prop('disabled', false).text('Try Again');
                    status.append('<p class="error">' + response.data.message + '</p>');
                }
            },
            error: function() {
                status.find('.installing').remove();
                button.prop('disabled', false).text('Try Again');
                status.append('<p class="error">Connection error. Please try again.</p>');
            }
        });
    });
    
    // Child theme activation AJAX handler
    $(document).on('click', '.activate-child-theme', function() {
        var button = $(this);
        var themeSlug = button.data('theme');
        
        button.prop('disabled', true).text('Activating...');
        
        $.ajax({
            url: theme_setup_wizard.ajaxurl,
            type: 'POST',
            data: {
                action: 'activate_child_theme',
                nonce: theme_setup_wizard.nonce,
                theme: themeSlug
            },
            success: function(response) {
                if (response.success) {
                    button.text('Activated').addClass('button-disabled');
                    
                    // Replace notice with success message
                    setTimeout(function() {
                        button.closest('.notice').replaceWith(
                            '<div class="notice notice-success">' +
                            '<p>Child theme is now activated successfully.</p>' +
                            '</div>'
                        );
                    }, 1000);
                } else {
                    button.prop('disabled', false).text('Try Again');
                    button.after('<p class="error">' + response.data.message + '</p>');
                }
            },
            error: function() {
                button.prop('disabled', false).text('Try Again');
                button.after('<p class="error">Connection error. Please try again.</p>');
            }
        });
    });
});
jQuery(document).ready(function ($) {
    if ($("body").hasClass("toplevel_page_coreit")) {
        var $adminMenuWrap = $("#adminmenuwrap");

        $(window).on("scroll", function () {
            if ($(this).scrollTop() > 0) {
                $adminMenuWrap.css({
                    "position": "fixed",
                    "bottom": "0"
                });
            } else {
                $adminMenuWrap.css({
                    "position": "",
                    "bottom": ""
                });
            }
        });
    }
});




