/*==================================================
                    CoreIT Theme Js 
==================================================*/
(function ($) {
    "use strict";

    // Helper Functions
    function formatIconOption(option) {
        if (!option.id) {
            return option.text;
        }
        var $icon = $('<i class="' + $(option.element).val() + '"></i>');
        return $('<span>').append($icon).append(' ' + option.text);
    }

    function initializeSelect2() {
        $(".coreit_select, .service-meta-icon-type, .portfolio-meta-icon-type, .select2-other, .fleet-meta-icon-type").select2();
        
        $('.select2-icons').select2({
            templateResult: formatIconOption,
            templateSelection: formatIconOption,
            escapeMarkup: function(m) { return m; }
        });

        $("#customize-theme-controls select").select2();
        $('#sub-accordion-section-google_fonts_panel select').select2('destroy');
    }

    function handleCheckboxChange(checkboxSelector, elementsSelector) {
        $(checkboxSelector).change(function() {
            var isChecked = $(this).prop('checked');
            $(elementsSelector).toggleClass('enable_meta', isChecked);
        }).change();
    }

    // Document Ready Functions
    $(document).ready(function() {
        // Admin Notice Handler
        var noticeClosedTime = localStorage.getItem('admin_notice_closed_times');
        if (noticeClosedTime && (new Date().getTime() - noticeClosedTime) < 24 * 60 * 60 * 1000) {
            $('.admin-notice-coreitss').hide();
        }

        $('.admin-notice .notice-dismiss').on('click', function() {
            localStorage.setItem('admin_notice_closed_times', new Date().getTime());
        });

        // Debug Notice Color Animation
        $('.admin-notice-debug_enabled').each(function() {
            var notice = $(this);
            var colors = ['#3f3eed', '#161c29', '#121623'];
            var currentIndex = 0;
            setInterval(function() {
                currentIndex = (currentIndex + 1) % colors.length;
                notice.css('background-image', 'linear-gradient(to right, ' + colors[currentIndex] + ', ' + colors[(currentIndex + 1) % colors.length] + ')');
            }, 2000);
        });

        // Icon Type Switcher
        $('.fleet-meta-icon-type, .service-meta-icon-type, .portfolio-meta-icon-type').change(function() {
            var iconType = $(this).val();
            var parentListItem = $(this).closest('li');
            var svgField = parentListItem.nextAll('.fleet-meta-icon-svg-field, .service-meta-icon-svg-field, .portfolio-meta-icon-svg-field');
            var selectField = parentListItem.nextAll('.fleet-meta-icon-select-field, .service-meta-icon-select-field, .portfolio-meta-icon-select-field');
            
            if (iconType === 'image') {
                svgField.hide();
                selectField.show();
            } else if (iconType === 'icon') {
                svgField.show();
                selectField.hide();
            }
        }).change();

        // Checkbox Handlers
        handleCheckboxChange('#custom_header_enable', '.meta_header_option');
        handleCheckboxChange('#custom_sticky_header_enable', '.meta_sticky_header_option');
        handleCheckboxChange('#custom_footer_enable', '.meta_footer_option');
        handleCheckboxChange('#custom_layout', '.meta_layout_option');
        handleCheckboxChange('#custom_sidebar_enable', '.meta_sidebar_option');

        // Image Upload Handlers
        $('.fleet-meta-image-upload, .service-meta-image-upload, .pageheader-meta-image-upload').click(function(e) {
            e.preventDefault();
            var button = $(this);
            var custom_uploader = wp.media({
                title: 'Upload Image',
                button: { text: 'Choose Image' },
                multiple: false
            });

            custom_uploader.on('select', function() {
                var attachment = custom_uploader.state().get('selection').first().toJSON();
                button.siblings('.fleet-meta-image-field, .service-meta-image-field, .pageheader-meta-image-field').val(attachment.url);
                button.siblings('.fleet-meta-image-preview, .service-meta-image-preview, .pageheader-meta-image-preview')
                     .html('<img src="' + attachment.url + '" style="max-width:300px;" />');
            });

            custom_uploader.open();
        });

        // Image Remove Handlers
        $('.fleet-meta-image-remove, .service-meta-image-remove, .pageheader-meta-image-remove').click(function(e) {
            e.preventDefault();
            $(this).siblings('.fleet-meta-image-field, .service-meta-image-field, .pageheader-meta-image-field').val('');
            $(this).siblings('.fleet-meta-image-preview, .service-meta-image-preview, .pageheader-meta-image-preview').html('');
        });

        // Portfolio Projects Repeater
        var projectIndex = $('#portfolio-projects-repeater .project-row').length;
        
        $('#add-project').on('click', function() {
            var template = wp.template('portfolio-project');
            $('.project-row-outer').append(template({ index: projectIndex }));
            
            // Initialize Select2 for the new row
            $('.project-row:last-child .select2-icons').select2({
                templateResult: formatIconOption,
                templateSelection: formatIconOption,
                escapeMarkup: function(m) { return m; }
            });
            
            projectIndex++;
        });

        $(document).on('click', '.remove-project', function() {
            $(this).closest('.project-row').find('.select2-icons').select2('destroy');
            $(this).closest('.project-row').remove();
        });

        // Team Social Media Repeater
        $('#add-media').on('click', function() {
            var template = wp.template('team-media');
            var $container = $('.media-row-outer');
            var index = $container.children().length;
            $container.append(template({ index: index }));
            
            // Initialize Select2 for the new row
            $('.media-row:last-child .select2-icons').select2({
                templateResult: formatIconOption,
                templateSelection: formatIconOption,
                escapeMarkup: function(m) { return m; }
            });
        });

        $(document).on('click', '.remove-media', function() {
            var $container = $('.media-row-outer');
            if ($container.children().length > 5) {
                $(this).closest('.media-row').find('.select2-icons').select2('destroy');
                $(this).closest('.media-row').remove();
                
                // Update indices
                $container.children().each(function(index) {
                    $(this).find('h4').text('Social Media ' + (index + 1));
                    $(this).find('select, input').each(function() {
                        var name = $(this).attr('name');
                        if (name) {
                            $(this).attr('name', name.replace(/\[\d+\]/, '[' + index + ']'));
                        }
                    });
                });
            } else {
                alert('You must maintain at least 5 social media items.');
            }
        });
    });

    // Window Load Functions
    $(window).on('load', function() {
        initializeSelect2();
    });

})(jQuery);