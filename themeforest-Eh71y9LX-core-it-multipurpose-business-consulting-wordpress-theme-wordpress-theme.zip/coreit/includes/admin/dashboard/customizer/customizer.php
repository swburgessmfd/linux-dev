<?php
/*
 ** ==============================
 ** Dashboard
 ** ==============================
 */
class Customizer{ 
    public function __construct(){  
        add_action('customize_register', [$this, 'coreit_customize_register']); 
        add_action('customize_register', [$this, 'coreit_customize_options_register']);  
        add_action('wp_enqueue_scripts', [$this, 'coreit_inline_css']);     
    } 
    /**
    * Modify the WordPress Customizer sections and create a custom panel.
    *
    * @param WP_Customize_Manager $wp_customize The WordPress Customizer manager instance.
    */
    public function coreit_customize_register($wp_customize) { 
       // Create a custom panel
       $wp_customize->add_panel('coreit_default_panel', array(
           'title'       => __('CoreIT Default Settings', 'coreit'),
           'priority'    => 0,
           'description' => __('Customize the default settings for your website.', 'coreit'),
       ));
       // Modify existing sections
       $sections_to_move = array(
           'title_tagline', // Site Identity
           'static_front_page', // Homepage Settings
           'custom_css', // Additional CSS
       );
       foreach ($sections_to_move as $section_id) {
           $section = $wp_customize->get_section($section_id); 
           if ($section instanceof WP_Customize_Section) {
               $section->panel = 'coreit_default_panel'; // Assign the section to the custom panel
               $section->priority = 20; // Set the priority (order) of the section within the panel
           }
       }   
       // Rename the WooCommerce panel
       $woocommerce_panel = $wp_customize->get_panel('woocommerce');
       if ($woocommerce_panel instanceof WP_Customize_Panel) {
           $woocommerce_panel->title = __('CoreIT WooCommerce Settings', 'coreit');
           $woocommerce_panel->priority = 70;
       }  
   }
    public function coreit_customize_options_register($wp_customize) { 
        // ================ Header / Footer Settings Section Start ===================
        $wp_customize->add_panel('header_section', array(
            'title'    => __('CoreIT Header / Footer Settings', 'coreit'),
            'priority' => 10,
        ));
        $wp_customize->add_section('admin_sub_section', array(
            'title'    => __('Admin Notice', 'coreit'),
            'priority' => 30,
            'panel'    => 'header_section', // Link this sub-section to the 'header_section' panel
        ));
        // Subsection for Header Options and Footer Options
        $wp_customize->add_section('header_sub_section', array(
            'title'    => __('Header Options', 'coreit'),
            'priority' => 30,
            'panel'    => 'header_section', // Link this sub-section to the 'header_section' panel
        ));
        $wp_customize->add_section('footer_sub_section', array(
            'title'    => __('Footer Options', 'coreit'),
            'priority' => 30,
            'panel'    => 'header_section', // Link this sub-section to the 'header_section' panel
        ));
        
        $wp_customize->add_setting('admin_notice', array(
            'default'           => true,
            'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
        )); 
        $wp_customize->add_control('admin_notice', array(
            'label'    => __('Admin Notice Enable / Disable', 'coreit'),
            'section'  => 'admin_sub_section',
            'settings' => 'admin_notice',
            'type'     => 'checkbox',
        )); 
        // ================ Header Settings Start
        $wp_customize->add_setting('header_custom_enables', array(
            'default'           => false,
            'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
        )); 
        $wp_customize->add_control('header_custom_enables', array(
            'label'    => __('Header Custom Enable / Disable', 'coreit'),
            'section'  => 'header_sub_section',
            'settings' => 'header_custom_enables',
            'type'     => 'checkbox',
        )); 
        $wp_customize->add_setting('header_custom_style', array(
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('header_custom_style', array(
            'label'       => __('Select Header Style', 'coreit'),
            'section'     => 'header_sub_section',
            'settings'    => 'header_custom_style',
            'type'        => 'select', 
            'choices'     => function_exists('coreit_common_query') ? coreit_common_query('header') : array(),
            'active_callback'    => 'header_custom_enables',
        ));
        $wp_customize->add_setting('header_archive_style', array(
            'default'           => false,
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('header_archive_style', array(
            'label'       => __('Select Header Style For Archive Pages (Blog, Product, Category, Tag)', 'coreit'),
            'section'     => 'header_sub_section',
            'settings'    => 'header_archive_style',
            'type'        => 'select', 
            'choices'     => function_exists('coreit_common_query') ? coreit_common_query('header') : array(),
            'active_callback'    => 'header_custom_enables',
        ));
        // Callback function to determine when to show the excerpt count control 
        function header_custom_enables( $control ) {
            if ( $control->manager->get_setting('header_custom_enables')->value() == true ) {
            return true;
            } else {
            return false;
            }
        }
        $wp_customize->add_setting('header_sticky', array(
            'default'           => false,
            'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
        ));
        $wp_customize->add_control('header_sticky', array(
            'label'    => __('Header Sticky Enable / Disable', 'coreit'),
            'section'  => 'header_sub_section',
            'settings' => 'header_sticky',
            'type'     => 'checkbox',
        ));
        $wp_customize->add_setting('header_sticky_custom_style', array(
            'default'           => false,
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('header_sticky_custom_style', array(
            'label'       => __('Select Sticky Header Style', 'coreit'),
            'section'     => 'header_sub_section',
            'settings'    => 'header_sticky_custom_style',
            'type'        => 'select',
            'choices'     => function_exists('coreit_common_query') ? coreit_common_query('header') : array(),
            'active_callback' => 'header_sticky_enable'
        ));
        $wp_customize->add_setting('stickyheader_archive_style', array(
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('stickyheader_archive_style', array(
            'label'       => __('Select Sticky Header Style For Archive Pages (Blog, Product, Category, Tag)', 'coreit'),
            'section'     => 'header_sub_section',
            'settings'    => 'stickyheader_archive_style',
            'type'        => 'select',
            'choices'     => function_exists('coreit_common_query') ? coreit_common_query('header') : array(),
            'active_callback' => 'header_sticky_enable'
        ));

          // Callback function to determine when to show the excerpt count control 
        function header_sticky_enable( $control ) {
            if ( $control->manager->get_setting('header_sticky')->value() == true ) {
            return true;
            } else {
            return false;
            }
        }
        // ================ Header Settings End
        // ================ Footer Settings Start
        $wp_customize->add_setting('footer_custom_enable_disable', array(
            'default'           => false,
            'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
        ));
        $wp_customize->add_control('footer_custom_enable_disable', array(
            'label'    => __('Footer Custom Enable / Disable', 'coreit'),
            'section'  => 'footer_sub_section',
            'settings' => 'footer_custom_enable_disable',
            'type'     => 'checkbox',
        ));
        $wp_customize->add_setting('footer_custom_style', array(
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('footer_custom_style', array(
            'label'       => __('Select Footer Style', 'coreit'),
            'section'     => 'footer_sub_section',
            'settings'    => 'footer_custom_style',
            'type'        => 'select',
         'choices'     => function_exists('coreit_common_query') ? coreit_common_query('footer') : array(),
            'active_callback'    => 'footer_custom_enable_disable',
        ));
        $wp_customize->add_setting('backtoenable', array(
            'default' => false,
            'sanitize_callback' => 'sanitize_key',
        ));
        $wp_customize->add_control('backtoenable', array(
            'label' => __('Back To Top Enable / Disable', 'coreit'),
            'section' => 'footer_sub_section',
            'type' => 'checkbox',
        ));
        function footer_custom_enable_disable( $control ) {
            if ( $control->manager->get_setting('footer_custom_enable_disable')->value() == true ) {
            return true;
            } else {
            return false;
            }
        }
        // ================ Footer Settings End
        // ================ Header / Footer Settings Section End ===================
        // ================ Layout Settings Start 
        // section panel for coreit layout settings
        $wp_customize->add_section('coreit_layout_settings', array(
            'title' => __('CoreIT Layout Settings', 'coreit'),
            'priority' => 20,
        ));
        // select field for default layouts
        $wp_customize->add_setting('default_layout', array(
            'default' => 'right-sidebar',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('default_layout', array(
            'label' => __('Default Layout', 'coreit'),
            'section' => 'coreit_layout_settings',
            'type' => 'select',
            'choices' => array(
                'no-sidebar' => __('No Sidebar', 'coreit'),
                'left-sidebar' => __('Left Sidebar', 'coreit'),
                'right-sidebar' => __('Right Sidebar', 'coreit'),
            ),
        ));
        // select field for page layouts
        $wp_customize->add_setting('page_layouts', array(
            'default' => 'right-sidebar',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('page_layouts', array(
            'label' => __('Page Layout', 'coreit'),
            'section' => 'coreit_layout_settings',
            'type' => 'select',
            'choices' => array(
                'no-sidebar' => __('No Sidebar', 'coreit'),
                'left-sidebar' => __('Left Sidebar', 'coreit'),
                'right-sidebar' => __('Right Sidebar', 'coreit'),
            ),
        ));
     
        // select field for portfolio layouts
        $wp_customize->add_setting('portfolio_layouts', array(
            'default' => 'right-sidebar',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('portfolio_layouts', array(
            'label' => __('Portfolio Layout', 'coreit'),
            'section' => 'coreit_layout_settings',
            'type' => 'select',
            'choices' => array(
                'no-sidebar' => __('No Sidebar', 'coreit'),
                'left-sidebar' => __('Left Sidebar', 'coreit'),
                'right-sidebar' => __('Right Sidebar', 'coreit'),
            ),
        ));  
        $wp_customize->add_setting('portfolio_single_layouts', array(
            'default' => 'right-sidebar',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('portfolio_single_layouts', array(
            'label' => __('Portfolio Single Page Layout', 'coreit'),
            'section' => 'coreit_layout_settings',
            'type' => 'select',
            'choices' => array(
                'no-sidebar' => __('No Sidebar', 'coreit'),
                'left-sidebar' => __('Left Sidebar', 'coreit'),
                'right-sidebar' => __('Right Sidebar', 'coreit'),
            ),
        ));  
        // select field for service layouts
        $wp_customize->add_setting('service_layouts', array(
            'default' => 'right-sidebar',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('service_layouts', array(
            'label' => __('Service Layout', 'coreit'),
            'section' => 'coreit_layout_settings',
            'type' => 'select',
            'choices' => array(
                'no-sidebar' => __('No Sidebar', 'coreit'),
                'left-sidebar' => __('Left Sidebar', 'coreit'),
                'right-sidebar' => __('Right Sidebar', 'coreit'),
            ),
        )); 
        $wp_customize->add_setting('service_single_layouts', array(
            'default' => 'right-sidebar',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('service_single_layouts', array(
            'label' => __('Service Single Page Layout', 'coreit'),
            'section' => 'coreit_layout_settings',
            'type' => 'select',
            'choices' => array(
                'no-sidebar' => __('No Sidebar', 'coreit'),
                'left-sidebar' => __('Left Sidebar', 'coreit'),
                'right-sidebar' => __('Right Sidebar', 'coreit'),
            ),
        )); 
        // select field for Team layouts
        $wp_customize->add_setting('team_layouts', array(
            'default' => 'right-sidebar',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('team_layouts', array(
            'label' => __('Team Layout', 'coreit'),
            'section' => 'coreit_layout_settings',
            'type' => 'select',
            'choices' => array(
                'no-sidebar' => __('No Sidebar', 'coreit'),
                'left-sidebar' => __('Left Sidebar', 'coreit'),
                'right-sidebar' => __('Right Sidebar', 'coreit'),
            ),
        )); 
        $wp_customize->add_setting('shop_layouts', array(
            'default' => 'right-sidebar',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('shop_layouts', array(
            'label' => __('Shop Layout', 'coreit'),
            'section' => 'coreit_layout_settings',
            'type' => 'select',
            'choices' => array(
                'no-sidebar' => __('No Sidebar', 'coreit'),
                'left-sidebar' => __('Left Sidebar', 'coreit'),
                'right-sidebar' => __('Right Sidebar', 'coreit'),
            ),
        ));
        $wp_customize->add_setting('shop_single_layouts', array(
            'default' => 'no-sidebar',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('shop_single_layouts', array(
            'label' => __('Shop Single Page Layout', 'coreit'),
            'section' => 'coreit_layout_settings',
            'type' => 'select',
            'choices' => array(
                'no-sidebar' => __('No Sidebar', 'coreit'),
                'left-sidebar' => __('Left Sidebar', 'coreit'),
                'right-sidebar' => __('Right Sidebar', 'coreit'),
            ),
        ));
        // job manager layout
        if (class_exists('WP_Job_Manager_Autoload')) {
            $wp_customize->add_setting('job_single_layouts', array(
                'default' => 'no-sidebar',
                'sanitize_callback' => 'sanitize_text_field',
            ));
            $wp_customize->add_control('job_single_layouts', array(
                'label' => __('Job Single Page Layout', 'coreit'),
                'section' => 'coreit_layout_settings',
                'type' => 'select',
                'choices' => array(
                    'no-sidebar' => __('No Sidebar', 'coreit'),
                    'left-sidebar' => __('Left Sidebar', 'coreit'),
                    'right-sidebar' => __('Right Sidebar', 'coreit'),
                ),
            ));
        }
        // job manager layout
        // ================ Layout Settings End  
        // ================ Page Header Settings Start 
            // coreit Page Header Settings section
            $wp_customize->add_section('coreit_page_header_settings', array(
                'title' => __('CoreIT Page Header Settings', 'coreit'),
                'priority' => 10,
            ));
            // Page header enable/disable option
            $wp_customize->add_setting('page_header_enables', array(
                'default' => true, 
                'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
            ));
            $wp_customize->add_control('page_header_enables', array(
                'label' => __('Enable Page Header', 'coreit'),
                'section' => 'coreit_page_header_settings',
                'type' => 'checkbox',
            ));
            // Page header alignment option
            $wp_customize->add_setting('page_header_alignment', array(
                'default' => 'flex-start', 
                'sanitize_callback' => 'sanitize_text_field',
            )); 
            $wp_customize->add_control('page_header_alignment', array(
                'label' => __('Page Header Alignment', 'coreit'),
                'section' => 'coreit_page_header_settings',
                'type' => 'select',
                'choices' => array(
                    'flex-start' => __('Left', 'coreit'),
                    'center' => __('Center', 'coreit'),
                    'flex-end' => __('Right', 'coreit'),
                ),
                'active_callback' => 'page_header_enables'
            ));
        // Page header style option
        $wp_customize->add_setting('page_header_style', array(
            'default' => 'default', 
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('page_header_style', array(
            'label' => __('Page Header Style', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'type' => 'select',
            'choices' => array(
                'default' => __('Page Title / Bread Crumb', 'coreit'),
                'style1' => __('Bread Crumb', 'coreit'), 
                // more styles as needed
            ),
            'active_callback' => 'page_header_enables'
        ));
        // Page header background image option
        $wp_customize->add_setting('page_header_bg_image', array(
            'default' => '', 
            'sanitize_callback' => 'sanitize_text_field',
        )); 
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'page_header_bg_image', array(
            'label' => __('Page Header Background Image', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'settings' => 'page_header_bg_image',
            'active_callback' => 'enable_page_header_default'
        )));
        $wp_customize->add_setting('blog_page_header_bg_image', array(
            'default' => '', 
            'sanitize_callback' => 'sanitize_text_field',
        )); 
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'blog_page_header_bg_image', array(
            'label' => __('Blog Page Header Background Image', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'settings' => 'blog_page_header_bg_image',
            'active_callback' => 'enable_page_header_default'
        ))); 
            // mobile header images
            $wp_customize->add_setting('mobile_page_header_bg_image', array(
                'default' => '', 
                'sanitize_callback' => 'sanitize_text_field',
            )); 
            $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'mobile_page_header_bg_image', array(
                'label' => __('Mobile Page Header Background Image', 'coreit'),
                'section' => 'coreit_page_header_settings',
                'settings' => 'mobile_page_header_bg_image',
                'active_callback' => 'enable_page_header_default'
            )));
            $wp_customize->add_setting('mobile_blog_page_header_bg_image', array(
                'default' => '', 
                'sanitize_callback' => 'sanitize_text_field',
            )); 
            $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'mobile_blog_page_header_bg_image', array(
                'label' => __('Mobile Blog Page Header Background Image', 'coreit'),
                'section' => 'coreit_page_header_settings',
                'settings' => 'mobile_blog_page_header_bg_image',
                'active_callback' => 'enable_page_header_default'
            ))); 
            // mobile header images end
    
        $wp_customize->add_setting('pageheader_bg_cover', array(
            'default' => '',
            'sanitize_callback' => 'sanitize_text_field',
            ));
            $wp_customize->add_control('pageheader_bg_cover', array(
                'label' => __('Background Cover', 'coreit'),
                'section' => 'coreit_page_header_settings',
                'type' => 'select',
                'choices' => array(
                    '' => __('Select', 'coreit'),
                    'cover' => __('Cover', 'coreit'),
                    'contain' => __('Contain', 'coreit'),
                    'auto' => __('Auto', 'coreit'),
                ),
                'active_callback' => 'enable_page_header_default'
            ));  
            $wp_customize->add_setting('pageheader_bg_position', array(
                'default' => '',
                'sanitize_callback' => 'sanitize_text_field',
            ));
            $wp_customize->add_control('pageheader_bg_position', array(
                'label' => __('Background Position', 'coreit'),
                'section' => 'coreit_page_header_settings',
                'type' => 'select',
                'choices' => array(
                    '' => __('Select', 'coreit'),
                    'left top' => __('Left Top', 'coreit'),
                    'center top' => __('Center Top', 'coreit'),
                    'right top' => __('Right Top', 'coreit'),
                    'left center' => __('Left Center', 'coreit'),
                    'center center' => __('Center Center', 'coreit'),
                    'right center' => __('Right Center', 'coreit'),
                    'left bottom' => __('Left Bottom', 'coreit'),
                    'center bottom' => __('Center Bottom', 'coreit'),
                    'right bottom' => __('Right Bottom', 'coreit'), 
                ),
                'active_callback' => 'enable_page_header_default'
            ));  
            $wp_customize->add_setting('pageheader_bg_repeat', array(
                'default' => '',
                'sanitize_callback' => 'sanitize_text_field',
            ));
            $wp_customize->add_control('pageheader_bg_repeat', array(
                'label' => __('Background Repeat', 'coreit'),
                'section' => 'coreit_page_header_settings',
                'type' => 'select',
                'choices' => array(
                    '' => __('Select', 'coreit'),
                    'repeat' => __('Repeat', 'coreit'),
                    'repeat-x' => __('Repeat Horizontally', 'coreit'),
                    'repeat-y' => __('Repeat Vertically', 'coreit'),
                    'no-repeat' => __('No Repeat', 'coreit'),
                ),
                'active_callback' => 'enable_page_header_default'
            ));  
            $wp_customize->add_setting('pageheader_bg_attachment', array(
                'default' => '',
                'sanitize_callback' => 'sanitize_text_field',
            ));
            $wp_customize->add_control('pageheader_bg_attachment', array(
                'label' => __('Background Attachment', 'coreit'),
                'section' => 'coreit_page_header_settings',
                'type' => 'select',
                'choices' => array(
                    '' => __('Select', 'coreit'),
                    'scroll' => __('Scroll', 'coreit'),
                    'fixed' => __('Fixed', 'coreit'),
                ),
                'active_callback' => 'enable_page_header_default'
            )); 
        // Breadcrumb enable/disable option
        $wp_customize->add_setting('breadcrumb_enable', array(
            'default' => true, 
            'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
        )); 
        $wp_customize->add_control('breadcrumb_enable', array(
            'label' => __('Enable Breadcrumbs', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'type' => 'checkbox',
            'active_callback' => 'page_header_enables'
        ));
        // Background Color Setting
        $wp_customize->add_setting('page_header_bg_color', array(
            'default' => '',
            'sanitize_callback' => 'sanitize_hex_color',
        )); 
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'page_header_bg_color', array(
            'label' => __('Page Header Background Color', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'settings' => 'page_header_bg_color',  
            'active_callback' => 'enable_page_header_default'
        )));
        $wp_customize->add_setting('page_header_bg_opacity', array(
            'default' => '', // Default number of excerpt characters
            'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
            'transport' => 'refresh', // Ensure changes take effect immediately
        ));  
        $wp_customize->add_control('page_header_bg_opacity', array(
            'type' => 'number', // Set the type to 'number'
            'label' => __('Opacity', 'coreit'),
            'settings' => 'page_header_bg_opacity',
            'section' => 'coreit_page_header_settings',
            'input_attrs' => array(
                'min' => 0,
                'max' => 100,
                'step' => 1,
            ), 
            'active_callback' => 'enable_page_header_default',
        )); 
        // Title Color Setting
        $wp_customize->add_setting('page_header_title_color', array(
            'default' => '',
            'sanitize_callback' => 'sanitize_hex_color',
        )); 
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'page_header_title_color', array(
            'label' => __('Page Header Title Color', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'settings' => 'page_header_title_color',  
            'active_callback' => 'enable_page_header_default'
        )));
        $wp_customize->add_setting('page_header_title_opacity', array(
            'default' => '', // Default number of excerpt characters
            'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
            'transport' => 'refresh', // Ensure changes take effect immediately
        ));  
        $wp_customize->add_control('page_header_title_opacity', array(
            'type' => 'number', // Set the type to 'number'
            'label' => __('Opacity', 'coreit'),
            'settings' => 'page_header_title_opacity',
            'section' => 'coreit_page_header_settings',
            'input_attrs' => array(
                'min' => 0,
                'max' => 100,
                'step' => 1,
            ), 
            'active_callback' => 'enable_page_header_default',
        )); 
        // Bread Crumb Color Setting
        $wp_customize->add_setting('breadcrumb_color', array(
            'default' => '',
            'sanitize_callback' => 'sanitize_hex_color',
        )); 
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'breadcrumb_color', array(
            'label' => __('Breadcrumb Color', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'settings' => 'breadcrumb_color', 
            'active_callback' => 'breadcrumb_enable'
        )));
        $wp_customize->add_setting('breadcrumb_opacity', array(
            'default' => '', // Default number of excerpt characters
            'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
            'transport' => 'refresh', // Ensure changes take effect immediately
        ));  
        $wp_customize->add_control('breadcrumb_opacity', array(
            'type' => 'number', // Set the type to 'number'
            'label' => __('Opacity', 'coreit'),
            'settings' => 'breadcrumb_opacity',
            'section' => 'coreit_page_header_settings',
            'input_attrs' => array(
                'min' => 0,
                'max' => 100,
                'step' => 1,
            ), 
            'active_callback' => 'breadcrumb_enable',
        )); 
        // Breadcrumb bg color
        $wp_customize->add_setting('breadcrumb_bg_color', array(
            'default' => '',
            'sanitize_callback' => 'sanitize_hex_color',
        )); 
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'breadcrumb_bg_color', array(
            'label' => __('Breadcrumb Background Color', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'settings' => 'breadcrumb_bg_color', 
            'active_callback' => 'enable_breadcrumb_for_two_enable'
        )));
        $wp_customize->add_setting('breadcrumb_bg_opacity', array(
            'default' => '', // Default number of excerpt characters
            'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
            'transport' => 'refresh', // Ensure changes take effect immediately
        ));  
        $wp_customize->add_control('breadcrumb_bg_opacity', array(
            'type' => 'number', // Set the type to 'number'
            'label' => __('Opacity', 'coreit'),
            'settings' => 'breadcrumb_bg_opacity',
            'section' => 'coreit_page_header_settings',
            'input_attrs' => array(
                'min' => 0,
                'max' => 100,
                'step' => 1,
            ), 
            'active_callback' => 'enable_breadcrumb_for_two_enable',
        )); 
        // Border Color
        $wp_customize->add_setting('breadcrumb_border_color', array(
            'default' => '',
            'sanitize_callback' => 'sanitize_hex_color',
        )); 
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'breadcrumb_border_color', array(
            'label' => __('Breadcrumb Border Color', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'settings' => 'breadcrumb_border_color', 
            'active_callback' => 'enable_breadcrumb_for_two_enable'
        )));
        $wp_customize->add_setting('breadcrumb_border_opacity', array(
            'default' => '', // Default number of excerpt characters
            'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
            'transport' => 'refresh', // Ensure changes take effect immediately
        ));  
        $wp_customize->add_control('breadcrumb_border_opacity', array(
            'type' => 'number', // Set the type to 'number'
            'label' => __('Opacity', 'coreit'),
            'settings' => 'breadcrumb_border_opacity',
            'section' => 'coreit_page_header_settings',
            'input_attrs' => array(
                'min' => 0,
                'max' => 100,
                'step' => 1,
            ), 
            'active_callback' => 'enable_breadcrumb_for_two_enable',
        )); 
        // ================ Padding Settings Start ================
        // Page Header Padding Top
        $wp_customize->add_setting('page_header_padding_top', array(
            'default' => '50',
            'sanitize_callback' => 'absint',
            'transport' => 'refresh',
        ));
        $wp_customize->add_control('page_header_padding_top', array(
            'type' => 'number',
            'label' => __('Page Header Padding Top (px)', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'settings' => 'page_header_padding_top',
            'input_attrs' => array(
                'min' => 0,
                'max' => 500,
                'step' => 1,
            ),
            'active_callback' => 'page_header_enables'
        ));
        
        // Page Header Padding Bottom
        $wp_customize->add_setting('page_header_padding_bottom', array(
            'default' => '50',
            'sanitize_callback' => 'absint',
            'transport' => 'refresh',
        ));
        $wp_customize->add_control('page_header_padding_bottom', array(
            'type' => 'number',
            'label' => __('Page Header Padding Bottom (px)', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'settings' => 'page_header_padding_bottom',
            'input_attrs' => array(
                'min' => 0,
                'max' => 500,
                'step' => 1,
            ),
            'active_callback' => 'page_header_enables'
        ));
        
        
        
        // Mobile Page Header Padding Top
        $wp_customize->add_setting('mobile_page_header_padding_top', array(
            'default' => '30',
            'sanitize_callback' => 'absint',
            'transport' => 'refresh',
        ));
        $wp_customize->add_control('mobile_page_header_padding_top', array(
            'type' => 'number',
            'label' => __('Mobile Page Header Padding Top (px)', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'settings' => 'mobile_page_header_padding_top',
            'input_attrs' => array(
                'min' => 0,
                'max' => 300,
                'step' => 1,
            ),
            'active_callback' => 'page_header_enables'
        ));
        
        // Mobile Page Header Padding Bottom
        $wp_customize->add_setting('mobile_page_header_padding_bottom', array(
            'default' => '30',
            'sanitize_callback' => 'absint',
            'transport' => 'refresh',
        ));
        $wp_customize->add_control('mobile_page_header_padding_bottom', array(
            'type' => 'number',
            'label' => __('Mobile Page Header Padding Bottom (px)', 'coreit'),
            'section' => 'coreit_page_header_settings',
            'settings' => 'mobile_page_header_padding_bottom',
            'input_attrs' => array(
                'min' => 0,
                'max' => 300,
                'step' => 1,
            ),
            'active_callback' => 'page_header_enables'
        ));
        // ================ Padding Settings End ==================
        // Callback function to determine when to show 
        function breadcrumb_enable( $control ) {
            // Check if 'breadcrumb_enable' is true and 'page_header_style' is 'style1'
            if ( 
                $control->manager->get_setting('breadcrumb_enable')->value() == true && 
                $control->manager->get_setting('page_header_enables')->value() == true 
            ) {
                return true;
            } else {
                return false;
            }
        } 
         // Callback function to determine when to show 
         function page_header_enables( $control ) {
            if ( $control->manager->get_setting('page_header_enables')->value() == true ) {
            return true;
            } else {
            return false;
            }
        } 
        // Callback function to determine when to show  
        function enable_page_header_default( $control ) {
            // Check if 'page_header_enables' is true and 'page_header_style' is 'default'
            if ( 
                $control->manager->get_setting('page_header_enables')->value() == true && 
                $control->manager->get_setting('page_header_style')->value() == "default" 
            ) {
                return true;
            } else {
                return false;
            }
        } 
         // Callback function to determine when to show  
         function enable_breadcrumb_for_two_enable( $control ) {
            // Check if 'page_header_enables' is true and 'page_header_style' is 'default'
            if ( 
                $control->manager->get_setting('page_header_enables')->value() == true && $control->manager->get_setting('breadcrumb_enable')->value() == true &&  
                $control->manager->get_setting('page_header_style')->value() == "style1" 
            ) {
                return true;
            } else {
                return false;
            }
        } 
    // ================ Page Header Settings End ========================
    // ================ Blog Card / Single Settings Start ===============
    // ================ Blog Card Settings Start
    // Create coreit Blog Settings section
    $wp_customize->add_panel('coreit_blog_settings', array(
        'title' => __('CoreIT Blog Settings', 'coreit'),
        'priority' => 39,
    ));
    // Blog Card Settings panel
    $wp_customize->add_section('blog_card_settings', array(
        'title' => __('Archive Settings', 'coreit'),
        'priority' => 10,
        'capability' => 'edit_theme_options',
        'panel' => 'coreit_blog_settings',
    )); 
    // fields for Blog Card Settings panel 
    $wp_customize->add_setting('blog_style', array(
        'default' => 'style_one',
        'sanitize_callback' => 'sanitize_text_field',
    )); 
    $wp_customize->add_control('blog_style', array(
        'type' => 'select',
        'label' => __('Column To Display', 'coreit'),
        'section' => 'blog_card_settings',
        'choices' => array(
            'style_one' => __('Style 1', 'coreit'),
            'style_two' => __('Style 2', 'coreit'),
            'style_three' => __('Style 3', 'coreit'),
            'style_four' => __('Style 4', 'coreit'),
            'style_five' => __('Style 5', 'coreit'),
        ),
    )); 
    // fields for Blog Card Settings panel 
    $wp_customize->add_setting('blog_columned', array(
        'default' => 'one_column',
        'sanitize_callback' => 'sanitize_text_field',
    )); 
    $wp_customize->add_control('blog_columned', array(
        'type' => 'select',
        'label' => __('Column To Display', 'coreit'),
        'section' => 'blog_card_settings',
        'choices' => array(
            'one_column' => __('1 Column', 'coreit'),
            'two_column' => __('2 Column', 'coreit'),
            'three_column' => __('3 Column', 'coreit'),
            'four_column' => __('4 Column', 'coreit'),
        ),
    )); 
    $wp_customize->add_setting('blog_cat_enable', array(
        'default'           => true,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    )); 
    $wp_customize->add_control('blog_cat_enable', array(
        'label'    => __('Category Enable / Disable', 'coreit'),
        'section'  => 'blog_card_settings',
        'settings' => 'blog_cat_enable',
        'type'     => 'checkbox',
    ));
    // settings and controls for Blog Card Settings panel
    $wp_customize->add_setting('blog_excerpt_enable', array(
        'default'           => true,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('blog_excerpt_enable', array(
        'label'    => __('Excerpt Enable / Disable', 'coreit'),
        'section'  => 'blog_card_settings',
        'settings' => 'blog_excerpt_enable',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('blog_excerpt_counts', array(
        'default' => '15', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    )); 
    $wp_customize->add_control('blog_excerpt_counts', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Excerpt Count', 'coreit'),
        'settings' => 'blog_excerpt_counts',
        'section' => 'blog_card_settings',
        'input_attrs' => array(
            'min' => 1, // Minimum value allowed
            'max' => 100, // Maximum value allowed
            'step' => 1, // Incremental steps
        ),
        'active_callback' => 'blog_excerpt_enable_active_callback', // Use a callback to determine when to show the control
    ));

    // Add a setting for width
    $wp_customize->add_setting( 'blog_image_width', array(
        'default'           => '700',
        'sanitize_callback' => 'absint', // Ensure it's an integer
    ) );
    // Add a control for width
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'blog_image_width_control', array(
        'label'    => __( 'Crop Image-Width', 'coreit' ),
        'section'  => 'blog_card_settings',
        'settings' => 'blog_image_width',
        'type'     => 'number',
        'input_attrs' => array(
            'min'  => 0,
            'step' => 1,
        ), 
    ) ) );
    // Add a setting for height
    $wp_customize->add_setting( 'blog_image_height', array(
        'default'           => '500',
        'sanitize_callback' => 'absint', // Ensure it's an integer
    ) );
    // Add a control for height
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'blog_image_height_control', array(
        'label'    => __( 'Crop Image-Height', 'coreit' ),
        'section'  => 'blog_card_settings',
        'settings' => 'blog_image_height',
        'type'     => 'number',
        'input_attrs' => array(
            'min'  => 0,
            'step' => 1,
        ), 
    ) ) );
    $wp_customize->add_setting('blog_image_fit_enable', array(
        'default'           => false,
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('blog_image_fit_enable', array(
        'label'    => __('Image Fit Enable / Disable', 'coreit'),
        'section'  => 'blog_card_settings',
        'settings' => 'blog_image_fit_enable',
        'type'     => 'checkbox', 
    ));
    $wp_customize->add_setting('blog_fit_image_height', array(
        'default' => '350', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    )); 
    $wp_customize->add_control('blog_fit_image_height', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Image Fit Height', 'coreit'),
        'settings' => 'blog_fit_image_height',
        'section' => 'blog_card_settings',
        'input_attrs' => array(
            'min' => 1, // Minimum value allowed
            'max' => 2000, // Maximum value allowed
            'step' => 1, // Incremental steps
        ),
        'active_callback' => 'blog_image_fit_active_callback',
    )); 
        // Callback function to determine when to show the excerpt count control 
        function blog_image_fit_active_callback( $control ) {
            if ( $control->manager->get_setting('blog_image_fit_enable')->value() == true ) {
            return true;
            } else {
            return false;
            }
        }
    // Callback function to determine when to show the excerpt count control 
    function blog_excerpt_enable_active_callback( $control ) {
        if ( $control->manager->get_setting('blog_excerpt_enable')->value() == true ) {
           return true;
        } else {
           return false;
        }
     }
    $wp_customize->add_setting('blog_date_enable', array(
        'default'           => true,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    )); 
    $wp_customize->add_control('blog_date_enable', array(
        'label'    => __('Date Enable / Disable', 'coreit'),
        'section'  => 'blog_card_settings',
        'settings' => 'blog_date_enable',
        'type'     => 'checkbox',
    ));
    $wp_customize->add_setting('blog_comment_enable', array(
        'default'           => true,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    )); 
    $wp_customize->add_control('blog_comment_enable', array(
        'label'    => __('Comment Enable / Disable', 'coreit'),
        'section'  => 'blog_card_settings',
        'settings' => 'blog_comment_enable',
        'type'     => 'checkbox',
    ));  
    $wp_customize->add_setting('blog_authour_enable', array(
        'default'           => true,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    )); 
    $wp_customize->add_control('blog_authour_enable', array(
        'label'    => __('Authour Enable / Disable', 'coreit'),
        'section'  => 'blog_card_settings',
        'settings' => 'blog_authour_enable',
        'type'     => 'checkbox',
    )); 
    // ================ Blog Card Settings End
    // ================ Blog Single Settings Start   
   // Blog Single Settings panel
    $wp_customize->add_section('blog_single_settings', array(
        'title' => __('Single Post Settings', 'coreit'),
        'priority' => 20,
        'capability' => 'edit_theme_options',
        'description' => __('Settings for the single blog posts', 'coreit'),
        'panel' => 'coreit_blog_settings',
    )); 
    // feature image enable field
    $wp_customize->add_setting('feature_image_enable', array(
        'default' => false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('feature_image_enable', array(
        'label' => __('Enable / Disable -  Feature Image', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'checkbox',
    ));
    // feature image width setting
    $wp_customize->add_setting('feature_image_width', array(
    'default' => '800', // Default width
    'sanitize_callback' => 'absint', // Sanitize as integer
    ));
    $wp_customize->add_control('feature_image_width', array(
        'label' => __('Feature Image Crop  Width', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'number',
    )); 
    // feature image height setting
    $wp_customize->add_setting('feature_image_height', array(
        'default' => '600', // Default height
        'sanitize_callback' => 'absint', // Sanitize as integer
    )); 
    $wp_customize->add_control('feature_image_height', array(
        'label' => __('Feature Image Crop  Height', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'number',
    )); 
     // feature image enable field
     $wp_customize->add_setting('feature_image_fit', array(
        'default' =>false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('feature_image_fit', array(
        'label' => __('Enable / Disable - Image Object Fit', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'checkbox',
    ));
    // feature image height setting
    $wp_customize->add_setting('feature_image_fit_height', array(
        'default' => '600', // Default height
        'sanitize_callback' => 'absint', // Sanitize as integer
    )); 
    $wp_customize->add_control('feature_image_fit_height', array(
        'label' => __('Feature Image Fit Height', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'number',
        'active_callback' => 'post_feature_image_fit',
    )); 
    function post_feature_image_fit( $control ) {
        if ($control->manager->get_setting('feature_image_fit')->value() == true ) {
            return true;
        } else {
            return false;
        }
    }
    // category enable field
    $wp_customize->add_setting('category_enables', array(
        'default' => false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('category_enables', array(
        'label' => __('Enable / Disable - Category', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'checkbox',
    )); 
    // Tag enable field
    $wp_customize->add_setting('tag_enable', array(
        'default' => false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('tag_enable', array(
        'label' => __('Enable / Disable - Tag', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'checkbox',
    ));
    // blog meta enable field
    $wp_customize->add_setting('single_date_enable', array(
        'default' => false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('single_date_enable', array(
        'label' => __('Enable / Disable - Blog Date', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'checkbox',
    ));
     // share disable field
     $wp_customize->add_setting('share_disable', array(
        'default' => false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('share_disable', array(
        'label' => __('Enable / Disable - Share', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'checkbox',
    ));
    // author detail disable field
    $wp_customize->add_setting('author_detail_disable', array(
        'default' => false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('author_detail_disable', array(
        'label' => __('Enable / Disable - Author Detail', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'checkbox',
    ));
    // next/prev enable field
    $wp_customize->add_setting('next_prev_enable', array(
        'default' => false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('next_prev_enable', array(
        'label'    => __('Next - Prev Post Enable / Disable', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'checkbox',
    ));
    // related post enable field
    $wp_customize->add_setting('relatedpost_enable', array(
        'default' => false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('relatedpost_enable', array(
        'label' => __('Enable / Disable - Related Post', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'checkbox',
    ));
    // related post enable field
    $wp_customize->add_setting('related_post_title', array(
        'default' => 'Related Posts',
        'sanitize_callback' => 'sanitize_text_field', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('related_post_title', array(
        'label' => __('Related Post Title', 'coreit'),
        'section' => 'blog_single_settings',
        'type' => 'text',
        'active_callback' => 'post_relatedpost_enable',
    ));
    function post_relatedpost_enable( $control ) {
        if ($control->manager->get_setting('relatedpost_enable')->value() == true ) {
            return true;
        } else {
            return false;
        }
    }
   // ================ Blog Card / Single Settings End 
   // ================ Typography Settings Start
   if(class_exists('Coreit_addons')){ 
        $wp_customize->add_panel('coreit_typography_color_section', array(
            'title'       => __('CoreIT Typography / Color Settings', 'coreit'),
            'priority'    => 50,
            'description' => __('Customize the default settings for your website.', 'coreit'),
        ));
        $wp_customize->add_section('typo_section', array(
            'title'    => __('Choose Custom Fonts / Google Fonts', 'coreit'),
            'priority' => 5,
            'panel'    => 'coreit_typography_color_section', // Link this sub-section to the 'header_section' panel
        ));
        $wp_customize->add_setting('typography_choice', array(
            'default' => 'nothing',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('typography_choice', array(
            'label' => __('Font Type', 'coreit'),
            'section' => 'typo_section',
            'type' => 'select',
            'choices' => array(
                'nothing' => __('Select Font Type', 'coreit'),
                'google-fonts' => __('Google Fonts', 'coreit'),
                'custom-fonts' => __('Custom Fonts', 'coreit'), 
            ),
        ));
    }
   // ================ Typography Settings End 
   // ================ Post Type Settings Start
   $wp_customize->add_section('coreit_post_type_panel', array(
    'title'       => __('CoreIT Cutom Post Type Settings', 'coreit'),
    'priority'    => 40, 
    ));
    // Option: Disable /  Eable Service Post
    $wp_customize->add_setting( 'disable_service_post', array(
        'default'           => true,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ) );
    $wp_customize->add_control( 'disable_service_post', array(
        'label'    => __( 'Enable / Disable Service Post Type', 'coreit' ),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'checkbox',
    ) );
    $wp_customize->add_setting('service_post_name', array(
        'default'           => 'Service',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('service_post_name', array(
        'label'    => __('Service Post Name', 'coreit'),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'text', // Use 'textarea' type for textarea field
        'active_callback' => 'service_post_active_callback',
    )); 
    $wp_customize->add_setting('service_post_slug', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('service_post_slug', array(
        'label'    => __('Service Post Url Name', 'coreit'),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'text', // Use 'textarea' type for textarea field
        'active_callback' => 'service_post_active_callback',
    )); 
    $wp_customize->add_setting('service_post_cat_slug', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('service_post_cat_slug', array(
        'label'    => __('Service Post Category Url Name', 'coreit'),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'text', // Use 'textarea' type for textarea field
        'active_callback' => 'service_post_active_callback',
    )); 
    // Callback function for service post slug
    function service_post_active_callback( $control ) {
        if ( $control->manager->get_setting('disable_service_post')->value() == false ) {
        return false;
        } else {
        return true;
        }
    }
    // Option: Disable /  Eable Service Post 
     // Option: Disable /  Eable Portfolio Post
     $wp_customize->add_setting( 'disable_portfolio_post', array(
        'default'           => true,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ) );
    $wp_customize->add_control( 'disable_portfolio_post', array(
        'label'    => __( 'Enable / Disable Portfolio Post Type', 'coreit' ),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'checkbox',
    ) );
    $wp_customize->add_setting('portfolio_post_name', array(
        'default'           => 'Our portfolio',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('portfolio_post_name', array(
        'label'    => __('Portfolio Post Name', 'coreit'),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'text', // Use 'textarea' type for textarea field
        'active_callback' => 'portfolio_post_active_callback',
    ));  
    $wp_customize->add_setting('portfolio_post_slug', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('portfolio_post_slug', array(
        'label'    => __('Portfolio Post Url Name', 'coreit'),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'text', // Use 'textarea' type for textarea field
        'active_callback' => 'portfolio_post_active_callback',
    )); 
    $wp_customize->add_setting('portfolio_post_cat_slug', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('portfolio_post_cat_slug', array(
        'label'    => __('Portfolio Post Category Url Name', 'coreit'),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'text', // Use 'textarea' type for textarea field
        'active_callback' => 'portfolio_post_active_callback',
    ));  
    // Callback function for Portfolio post slug
    function portfolio_post_active_callback( $control ) {
        if ( $control->manager->get_setting('disable_portfolio_post')->value() == false ) {
        return false;
        } else {
        return true;
        }
    }
    // Option: Disable /  Eable Portfolio Post
     // Option: Disable /  Eable Team Post
     $wp_customize->add_setting( 'disable_team_post', array(
        'default'           => true,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ) );
    $wp_customize->add_control( 'disable_team_post', array(
        'label'    => __( 'Enable / Disable Team Post Type', 'coreit' ),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'checkbox',
    ) );
    $wp_customize->add_setting('team_post_name', array(
        'default'           => 'Team',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('team_post_name', array(
        'label'    => __('Team Post Name', 'coreit'),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'text', // Use 'textarea' type for textarea field
        'active_callback' => 'team_post_active_callback',
    )); 
    $wp_customize->add_setting('team_post_slug', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('team_post_slug', array(
        'label'    => __('Team Post Url Name', 'coreit'),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'text', // Use 'textarea' type for textarea field
        'active_callback' => 'team_post_active_callback',
    )); 
    $wp_customize->add_setting('team_post_cat_slug', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('team_post_cat_slug', array(
        'label'    => __('Team Post Category Url Name', 'coreit'),
        'section'  => 'coreit_post_type_panel',
        'type'     => 'text', // Use 'textarea' type for textarea field
        'active_callback' => 'team_post_active_callback',
    )); 
    // Callback function for Team post slug
    function team_post_active_callback( $control ) {
        if ( $control->manager->get_setting('disable_team_post')->value() == false ) {
        return false;
        } else {
        return true;
        }
    }
    // Option: Disable /  Eable Team Post 
   
    $wp_customize->add_section('bobbreadcrumb_section', array(
        'title' => __('CoreIT Job Breadcrumb Settings ', 'coreit'),
        'priority'    => 50, 
    ));
    // Job manager Breadcrumb Text
    $wp_customize->add_setting('job_breadcrumb_name', array(
        'default'           => 'Jobs',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('job_breadcrumb_name', array(
        'label'    => __('Job Breadcrumb Name', 'coreit'),
        'section'  => 'bobbreadcrumb_section',
        'type'     => 'text', // Use 'textarea' type for textarea field 
    )); 
    $wp_customize->add_setting('job_breadcrumb_link', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('job_breadcrumb_link', array(
        'label'    => __('Job Breadcrumb Url', 'coreit'),
        'section'  => 'bobbreadcrumb_section',
        'type'     => 'text', // Use 'textarea' type for textarea field 
    )); 
    // Job manager Breadcrumb Text
    // ================ Post Type Settings End 
    // ================ Theme Color Settings Start  
    // Body Color Section
    $wp_customize->add_section('coreit_body_bg_section', array(
        'title' => __('Body Background', 'coreit'),
        'panel' => 'coreit_typography_color_section',
        'priority' => 10,
    ));
    // Body Color Section Fields
    $wp_customize->add_setting('enable_theme_body_bg', array(
        'default'           => false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    )); 
    $wp_customize->add_control('enable_theme_body_bg', array(
        'label'    => __('Body Background Enable / Disable', 'coreit'),
        'section'  => 'coreit_body_bg_section',
        'settings' => 'enable_theme_body_bg', 
        'type'     => 'checkbox',
    )); 
   // Background  Color Setting
    $wp_customize->add_setting('body_bg_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color',
    ));
   // Background  Color Setting
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'body_bg_color_control', array(
        'label' => __('Background Color', 'coreit'),
        'section' => 'coreit_body_bg_section',
        'settings' => 'body_bg_color',
        'active_callback' => 'enable_theme_color',
    )));
    $wp_customize->add_setting('body_bg_color_opactiy', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    )); 
    $wp_customize->add_control('body_bg_color_opactiy', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'body_bg_color_opactiy',
        'section' => 'coreit_body_bg_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_theme_body_bg',
    )); 
    $wp_customize->add_setting('body_bg_image', array(
        'default' => '', 
        'sanitize_callback' => 'sanitize_text_field',
    )); 
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'body_bg_image', array(
        'label' => __('Background Image', 'coreit'),
        'section' => 'coreit_body_bg_section',
        'settings' => 'body_bg_image',
        'active_callback' => 'enable_theme_body_bg',
    )));
    $wp_customize->add_setting('body_bg_cover', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('body_bg_cover', array(
        'label' => __('Background Cover', 'coreit'),
        'section' => 'coreit_body_bg_section',
        'type' => 'select',
        'choices' => array(
            '' => __('Select', 'coreit'),
            'cover' => __('Cover', 'coreit'),
            'contain' => __('Contain', 'coreit'),
            'auto' => __('Auto', 'coreit'),
        ),
    ));  
    $wp_customize->add_setting('body_bg_position', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('body_bg_position', array(
        'label' => __('Background Position', 'coreit'),
        'section' => 'coreit_body_bg_section',
        'type' => 'select',
        'choices' => array(
            '' => __('Select', 'coreit'),
            'left top' => __('Left Top', 'coreit'),
            'center top' => __('Center Top', 'coreit'),
            'right top' => __('Right Top', 'coreit'),
            'left center' => __('Left Center', 'coreit'),
            'center center' => __('Center Center', 'coreit'),
            'right center' => __('Right Center', 'coreit'),
            'left bottom' => __('Left Bottom', 'coreit'),
            'center bottom' => __('Center Bottom', 'coreit'),
            'right bottom' => __('Right Bottom', 'coreit'), 
        ),
    ));  
    $wp_customize->add_setting('body_bg_repeat', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('body_bg_repeat', array(
        'label' => __('Background Repeat', 'coreit'),
        'section' => 'coreit_body_bg_section',
        'type' => 'select',
        'choices' => array(
            '' => __('Select', 'coreit'),
            'repeat' => __('Repeat', 'coreit'),
            'repeat-x' => __('Repeat Horizontally', 'coreit'),
            'repeat-y' => __('Repeat Vertically', 'coreit'),
            'no-repeat' => __('No Repeat', 'coreit'),
        ),
    ));  
    $wp_customize->add_setting('body_bg_attachment', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('body_bg_attachment', array(
        'label' => __('Background Attachment', 'coreit'),
        'section' => 'coreit_body_bg_section',
        'type' => 'select',
        'choices' => array(
            '' => __('Select', 'coreit'),
            'scroll' => __('Scroll', 'coreit'),
            'fixed' => __('Fixed', 'coreit'),
        ),
    ));  
    // Callback function for Team post slug
    function enable_theme_body_bg( $control ) {
        if ( $control->manager->get_setting('enable_theme_body_bg')->value() == false ) {
        return false;
        } else {
        return true;
        }
    }
    // Entire Theme Color Section
    $wp_customize->add_section('entire_theme_color_section', array(
        'title' => __('Theme Colors', 'coreit'),
        'panel' => 'coreit_typography_color_section',
        'priority' => 20,
    ));
    // Theme Color Section Fields
    $wp_customize->add_setting('enable_theme_color', array(
        'default'           => false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    )); 
    $wp_customize->add_control('enable_theme_color', array(
        'label'    => __('Theme Color Enable / Disable', 'coreit'),
        'section'  => 'entire_theme_color_section',
        'settings' => 'enable_theme_color',
        'type'     => 'checkbox',
    )); 
    // Primary Color Setting
    $wp_customize->add_setting('primary_color_setting', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    // Primary Color Control
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'primary_color_control', array(
        'label' => __('Primary Color', 'coreit'),
        'section' => 'entire_theme_color_section',
        'settings' => 'primary_color_setting',
        'active_callback' => 'enable_theme_color',
    )));
    $wp_customize->add_setting('primary_opacity_setting', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('primary_opacity_setting', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'primary_opacity_setting',
        'section' => 'entire_theme_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_theme_color',
    ));
    // Primary Color Control
      // Primary Color Setting
      $wp_customize->add_setting('text_primary_color', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'text_primary_color_control', array(
        'label' => __('Text Color For Primary  Color', 'coreit'),
        'section' => 'entire_theme_color_section',
        'settings' => 'text_primary_color',
        'active_callback' => 'enable_theme_color',
    )));
    $wp_customize->add_setting('text_primary_opacity_setting', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('text_primary_opacity_setting', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'text_primary_opacity_setting',
        'section' => 'entire_theme_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_theme_color',
    ));
    // Secondary Color Setting
    $wp_customize->add_setting('secondary_color_setting', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    // Secondary Color Control
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'secondary_color_control', array(
        'label' => __('Secondary Color', 'coreit'),
        'section' => 'entire_theme_color_section',
        'settings' => 'secondary_color_setting',
        'active_callback' => 'enable_theme_color',
    )));
    $wp_customize->add_setting('secondary_opacity_setting', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('secondary_opacity_setting', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'secondary_opacity_setting',
        'section' => 'entire_theme_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_theme_color',
    ));
    // Secondary Color Setting
    $wp_customize->add_setting('third_color_setting', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    // Secondary Color Control
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'secondary_rgb_color_control', array(
        'label' => __('Secondary  Color ( Only Rgb )', 'coreit'),
        'section' => 'entire_theme_color_section',
        'settings' => 'third_color_setting',
        'active_callback' => 'enable_theme_color',
    )));
     // heading Color Setting
     $wp_customize->add_setting('heading_color_setting', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    // heading Color Control
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'heading_color_control', array(
        'label' => __('Heading Color', 'coreit'),
        'section' => 'entire_theme_color_section',
        'settings' => 'heading_color_setting',
        'active_callback' => 'enable_theme_color',
    )));
    $wp_customize->add_setting('heading_opacity_setting', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('heading_opacity_setting', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'heading_opacity_setting',
        'section' => 'entire_theme_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_theme_color',
    ));
     // content Color Setting
     $wp_customize->add_setting('content_color_setting', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'content_color_control', array(
        'label' => __('Text Color - 1', 'coreit'),
        'section' => 'entire_theme_color_section',
        'settings' => 'content_color_setting',
        'active_callback' => 'enable_theme_color',
    )));
    $wp_customize->add_setting('content_opacity_control', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('content_opacity_control', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'content_opacity_control',
        'section' => 'entire_theme_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_theme_color',
    ));
     // content 2 Color Setting
     $wp_customize->add_setting('content_color_two_setting', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'content_two_color_control', array(
        'label' => __('Text Color - 2', 'coreit'),
        'section' => 'entire_theme_color_section',
        'settings' => 'content_color_two_setting',
        'active_callback' => 'enable_theme_color',
    )));
    $wp_customize->add_setting('content_opacity_two_setting', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('content_opacity_two_setting', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'content_opacity_two_setting',
        'section' => 'entire_theme_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_theme_color',
    ));
    // Border Color Setting
    $wp_customize->add_setting('border_color_setting', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'border_color_control', array(
        'label' => __('Border Color', 'coreit'),
        'section' => 'entire_theme_color_section',
        'settings' => 'border_color_setting',
        'active_callback' => 'enable_theme_color',
    )));
    $wp_customize->add_setting('border_opacity_setting', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('border_opacity_setting', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'border_opacity_setting',
        'section' => 'entire_theme_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_theme_color',
    ));
     // Background Dark Color Setting
     $wp_customize->add_setting('background_dark_color_setting', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'background_dark_color_control', array(
        'label' => __('Background Light Color', 'coreit'),
        'section' => 'entire_theme_color_section',
        'settings' => 'background_dark_color_setting',
        'active_callback' => 'enable_theme_color',
    )));
    $wp_customize->add_setting('background_dark_opacity_setting', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('background_dark_opacity_setting', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'background_dark_opacity_setting',
        'section' => 'entire_theme_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_theme_color',
    ));
     // Background Light Color Setting
     $wp_customize->add_setting('background_light_color_setting', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'background_light_color_control', array(
        'label' => __('Background Light Color', 'coreit'),
        'section' => 'entire_theme_color_section',
        'settings' => 'background_light_color_setting',
        'active_callback' => 'enable_theme_color',
    )));
    $wp_customize->add_setting('background_light_opacity_setting', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('background_light_opacity_setting', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'background_light_opacity_setting',
        'section' => 'entire_theme_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_theme_color',
    ));
    // Menu Color Section
    $wp_customize->add_section('menu_color_section', array(
        'title' => __('Menu Color', 'coreit'),
        'panel' => 'coreit_typography_color_section',
        'priority' => 20,
    ));
    $wp_customize->add_setting('enable_menu_color', array(
        'default'           => false,
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    )); 
    $wp_customize->add_control('enable_menu_color', array(
        'label'    => __('Menu Color Enable / Disable', 'coreit'),
        'section'  => 'menu_color_section',
        'settings' => 'enable_menu_color',
        'type'     => 'checkbox',
    )); 
    // Menu Color Setting
    $wp_customize->add_setting('menu_color_settings', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'menu_color_settings_control', array(
        'label' => __('Menu Color', 'coreit'),
        'section' => 'menu_color_section',
        'settings' => 'menu_color_settings',
        'active_callback' => 'enable_menu_color',
    )));
    $wp_customize->add_setting('menu_opacity_settings', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('menu_opacity_settings', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'menu_opacity_settings',
        'section' => 'menu_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_menu_color',
    ));
    // Menu Active / Hover Color
    $wp_customize->add_setting('menu_active_color_settings', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'menu_active_color_settings_control', array(
        'label' => __('Menu Active / Hover Color', 'coreit'),
        'section' => 'menu_color_section',
        'settings' => 'menu_active_color_settings',
        'active_callback' => 'enable_menu_color',
    )));
    $wp_customize->add_setting('menu_active_opacity_settings', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('menu_active_opacity_settings', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'menu_active_opacity_settings',
        'section' => 'menu_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_menu_color',
    ));
     // Hover and Active Menu Background Color Setting
     $wp_customize->add_setting('menu_bg_active_color_settings', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'menu_bg_active_color_settings_control', array(
        'label' => __('Menu Active / Hover Background Color', 'coreit'),
        'section' => 'menu_color_section',
        'settings' => 'menu_bg_active_color_settings',
        'active_callback' => 'enable_menu_color',
    )));
    $wp_customize->add_setting('menu_bg_active_opacity_settings', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('menu_bg_active_opacity_settings', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'menu_bg_active_opacity_settings',
        'section' => 'menu_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_menu_color',
    ));
     //Dropdown Color
     $wp_customize->add_setting('dropdown_bg_color_settings', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'dropdown_bg_color_settings_control', array(
        'label' => __('Dropdown Background Color', 'coreit'),
        'section' => 'menu_color_section',
        'settings' => 'dropdown_bg_color_settings',
        'active_callback' => 'enable_menu_color',
    )));
    $wp_customize->add_setting('dropdown_bg_opacity_settings', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('dropdown_bg_opacity_settings', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'dropdown_bg_opacity_settings',
        'section' => 'menu_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_menu_color',
    ));
     //Dropdown Menu Color
     $wp_customize->add_setting('dropdown_menu_color_settings', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'dropdown_menu_color_settings_control', array(
        'label' => __('Dropdown Menu Color', 'coreit'),
        'section' => 'menu_color_section',
        'settings' => 'dropdown_menu_color_settings',
        'active_callback' => 'enable_menu_color',
    )));
    $wp_customize->add_setting('dropdown_menu_opacity_settings', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('dropdown_menu_opacity_settings', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'dropdown_menu_opacity_settings',
        'section' => 'menu_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_menu_color',
    ));
     //Dropdown Menu Active / Hover Color
     $wp_customize->add_setting('dropdown_menu_active_color_settings', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'dropdown_menu_active_color_settings_control', array(
        'label' => __('Dropdown Menu Active / Hover Color', 'coreit'),
        'section' => 'menu_color_section',
        'settings' => 'dropdown_menu_active_color_settings',
        'active_callback' => 'enable_menu_color',
    )));
    $wp_customize->add_setting('dropdown_menu_active_opacity_settings', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('dropdown_menu_active_opacity_settings', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'dropdown_menu_active_opacity_settings',
        'section' => 'menu_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'enable_menu_color',
    ));
    // Preloader Color Section
    $wp_customize->add_section('preloader_color_section', array(
        'title' => __('CoreIT Preloader Settings', 'coreit'), 
        'priority' => 9,
    ));
    $wp_customize->add_setting('preloader_style', array(
        'default' => 'disable',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('preloader_style', array(
        'label' => __('Preloader Styles', 'coreit'),
        'section' => 'preloader_color_section',
        'type' => 'select',
        'choices' => array(
            'style_one' => __('Style One', 'coreit'),
            'style_two' => __('Style Two', 'coreit'),
            'disable' => __('Disable', 'coreit'),
        ),
    ));  
    $wp_customize->add_setting('preloader_image', array(
        'default' => '', 
        'sanitize_callback' => 'sanitize_text_field',
    )); 
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'preloader_image', array(
        'label' => __('Preloader Image', 'coreit'),
        'section' => 'preloader_color_section',
        'settings' => 'preloader_image',
        'active_callback' => 'preloader_style_for_image',
    )));
    $wp_customize->add_setting('preloader_color_one', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'preloader_one_color_settings_control', array(
        'label' => __('Preloader Dot / Spin Color 1', 'coreit'),
        'section' => 'preloader_color_section',
        'settings' => 'preloader_color_one',
        'active_callback' => 'preloader_style',
    )));
    $wp_customize->add_setting('preloader_opacity_one', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('preloader_opacity_one', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'preloader_opacity_one',
        'section' => 'preloader_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'preloader_style',
    ));
    $wp_customize->add_setting('preloader_color_two', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'preloader_two_color_settings_control', array(
        'label' => __('Preloader Dot / Spin Color 2', 'coreit'),
        'section' => 'preloader_color_section',
        'settings' => 'preloader_color_two',
        'active_callback' => 'preloader_style',
    )));
    $wp_customize->add_setting('preloader_opacity_two', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('preloader_opacity_two', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'preloader_opacity_two',
        'section' => 'preloader_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'preloader_style',
    ));
    $wp_customize->add_setting('preloader_bg_color', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color',
    )); 
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'preloader_bg_settings_control', array(
        'label' => __('Preloader Background Color', 'coreit'),
        'section' => 'preloader_color_section',
        'settings' => 'preloader_bg_color',
        'active_callback' => 'preloader_style',
    )));
    $wp_customize->add_setting('preloader_bg_opacity', array(
        'default' => '', // Default number of excerpt characters
        'sanitize_callback' => 'absint', // Sanitize callback to ensure it's an integer
        'transport' => 'refresh', // Ensure changes take effect immediately
    ));  
    $wp_customize->add_control('preloader_bg_opacity', array(
        'type' => 'number', // Set the type to 'number'
        'label' => __('Opacity', 'coreit'),
        'settings' => 'preloader_bg_opacity',
        'section' => 'preloader_color_section',
        'input_attrs' => array(
            'min' => 0,
            'max' => 100,
            'step' => 1,
        ), 
        'active_callback' => 'preloader_style',
    ));
    // Callback function for theme color
    function preloader_style_for_image( $control ) {
        if ( $control->manager->get_setting('preloader_style')->value() == "style_one" ) {
        return true;
        } else {
        return false;
        }
    }
    // Callback function for theme color
    function preloader_style( $control ) {
        if ( $control->manager->get_setting('preloader_style')->value() != "disable" ) {
        return true;
        } else {
        return false;
        }
    }
    // Callback function for theme color
    function enable_theme_color( $control ) {
        if ( $control->manager->get_setting('enable_theme_color')->value() == false ) {
        return false;
        } else {
        return true;
        }
    }
    // Callback function for menu color
    function enable_menu_color( $control ) {
        if ( $control->manager->get_setting('enable_menu_color')->value() == false ) {
        return false;
        } else {
        return true;
        }
    }  
    // =============== Maintance Mode / Cookies 
     // Panel for Maintenance Mode / Cookies Settings
     $wp_customize->add_panel('coreit_maintenance_cookies_panel', array(
        'title' => __('CoreIT 404 / Maintenance Mode / Cookies Settings', 'coreit'),
        'priority' => 70,
    ));
     // Section for Maintenance Mode Settings
     $wp_customize->add_section('coreit_fnotfour_section', array(
        'title' => __('404  Settings', 'coreit'),
        'panel' => 'coreit_maintenance_cookies_panel',
    ));  
     // Add 404_image setting
     $wp_customize->add_setting('fornotfor_mode_blocks', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fornotfor_mode_blocks', array(
        'label'       => __('Select Blocks for 404', 'coreit'),
        'section'     => 'coreit_fnotfour_section',
        'settings'    => 'fornotfor_mode_blocks',
        'type'        => 'select', 
        'choices'     => function_exists('coreit_common_query') ? coreit_common_query('coreitblocks') : array(), 
    ));
     // Section for Maintenance Mode Settings
     $wp_customize->add_section('coreit_maintenance_mode_section', array(
        'title' => __('Maintenance Mode Settings', 'coreit'),
        'panel' => 'coreit_maintenance_cookies_panel',
    )); 
    // Field: Enable Maintenance Mode
    $wp_customize->add_setting('enable_maintenance', array(
        'default' => false,
        'transport' => 'refresh', // Refresh the page when changes are made
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('enable_maintenance', array(
        'label' => __('Enable Maintenance Mode', 'coreit'),
        'type' => 'checkbox',
        'section' => 'coreit_maintenance_mode_section',
    ));
    // Field: Maintenance Image
    $wp_customize->add_setting('maintance_mode_blocks', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('maintance_mode_blocks', array(
        'label'       => __('Select Blocks for Maintance Mode', 'coreit'),
        'section'     => 'coreit_maintenance_mode_section',
        'settings'    => 'maintance_mode_blocks',
        'type'        => 'select', 
        'choices'     => function_exists('coreit_common_query') ? coreit_common_query('coreitblocks') : array(),
        'active_callback'    => 'enable_maintenance',
    ));
    // Callback function for menu color
    function enable_maintenance( $control ) {
        if ( $control->manager->get_setting('enable_maintenance')->value() == false ) {
        return false;
        } else {
        return true;
        }
    }  
    // Section for Cookies Settings
    $wp_customize->add_section('coreit_cookies_settings_section', array(
        'title' => __('Cookies Settings', 'coreit'),
        'panel' => 'coreit_maintenance_cookies_panel',
    ));
    // Field: Enable Cookies
    $wp_customize->add_setting('enable_cookies', array(
        'default' => true,
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_key', // Adjust this based on your requirement
    ));
    $wp_customize->add_control('enable_cookies', array(
        'label' => __('Enable Cookies', 'coreit'),
        'type' => 'checkbox',
        'section' => 'coreit_cookies_settings_section',
    ));
    // Field: Cookies Description
    $wp_customize->add_setting('cookies_descriptions', array(
        'default' => 'This website uses cookies to ensure you get the best experience on our website.' ,
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cookies_descriptions', array(
        'label' => __('Cookies Description', 'coreit'),
        'type' => 'textarea',
        'section' => 'coreit_cookies_settings_section',
    ));
    // Field: Cookies Button One
    $wp_customize->add_setting('cookies_button_ones', array(
        'default' => 'Accept' ,
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cookies_button_ones', array(
        'label' => __('Cookies Button Text', 'coreit'),
        'type' => 'text',
        'section' => 'coreit_cookies_settings_section',
    ));
    
    // =============== Maintance Mode / Cookies 
   
    } 
    public function coreit_inline_css(){
            $css = '';
            // Theme Color Css
            $enable_theme_color = coreit_get_option('enable_theme_color', false);
            if ($enable_theme_color) {
                // Get primary and secondary color settings
                $primary_color_setting = coreit_get_option('primary_color_setting');
                $primary_opacity_setting = coreit_get_option('primary_opacity_setting');
                $text_primary_color = coreit_get_option('text_primary_color');
                $text_primary_opacity_setting = coreit_get_option('text_primary_opacity_setting');
                $secondary_color_setting = coreit_get_option('secondary_color_setting'); 
                $secondary_opacity_setting = coreit_get_option('secondary_opacity_setting'); 
                $third_color_setting = coreit_get_option('third_color_setting');  
                $heading_color_setting = coreit_get_option('heading_color_setting');
                $heading_opacity_setting = coreit_get_option('heading_opacity_setting');
                $content_color_setting = coreit_get_option('content_color_setting'); 
                $content_opacity_setting = coreit_get_option('content_opacity_setting'); 
                $content_color_two_setting = coreit_get_option('content_color_two_setting'); 
                $content_opacity_two_setting = coreit_get_option('content_opacity_two_setting'); 
                $border_color_setting = coreit_get_option('border_color_setting'); 
                $border_opacity_setting = coreit_get_option('border_opacity_setting'); 
                $background_dark_color_setting = coreit_get_option('background_dark_color_setting'); 
                $background_dark_opacity_setting = coreit_get_option('background_dark_opacity_setting'); 
                $background_light_color_setting = coreit_get_option('background_light_color_setting'); 
                $background_light_opacity_setting = coreit_get_option('background_light_opacity_setting'); 
                // Check if either primary or secondary color settings are not empty
                if (!empty($primary_color_setting) || !empty($text_primary_color) || !empty($secondary_color_setting) ||
                 !empty($third_color_setting) || !empty($heading_color_setting) || !empty($content_color_setting) || !empty($content_color_two_setting)
                 || !empty($border_color_setting) || !empty($background_dark_color_setting)  || !empty($background_light_color_setting)) {
                    // Start the :root block
                    $css .= ':root {'; 
                    // Add primary color CSS variable if not empty
                    list($r, $g, $b) = sscanf($primary_color_setting, "#%02x%02x%02x");
                    $primary_color_settings = "$r, $g, $b"; 
                    if (!empty($primary_color_setting)) { 
                        if (!empty($primary_opacity_setting)) {
                            $alpha_value = $primary_opacity_setting / 100; // Convert percentage to decimal
                            $css .= '--color-set-one-1: rgba(' . $primary_color_settings . ', ' . $alpha_value . ')!important; ';
                            $css .= '--color-set-one-3: rgba(' . $primary_color_settings . ', ' . $alpha_value . ')!important; ';
                        } else { 
                            $css .= '--color-set-one-1: rgb(' . $primary_color_settings . ')!important; ';
                            $css .= '--color-set-one-3: rgb(' . $primary_color_settings . ')!important; ';
                        }
                    }  
                    // text primary color
                    list($r, $g, $b) = sscanf($text_primary_color, "#%02x%02x%02x");
                    $text_primary_colors = "$r, $g, $b"; 
                    if (!empty($text_primary_color)) { 
                        if (!empty($text_primary_opacity_setting)) {
                            $alpha_value = $text_primary_opacity_setting / 100; // Convert percentage to decimal
                            $css .= '--color-set-one-1-dark: rgba(' . $text_primary_colors . ', ' . $alpha_value . ')!important; ';
                        } else { 
                            $css .= '--color-set-one-1-dark: rgb(' . $text_primary_colors . ')!important; ';
                        }
                    }  
                    // Add secondary color CSS variable if not empty 
                    list($r, $g, $b) = sscanf($secondary_color_setting, "#%02x%02x%02x");
                    $secondary_color_settings = "$r, $g, $b"; 
                    if (!empty($secondary_color_setting)) { 
                        if (!empty($secondary_opacity_setting)) {
                            $alpha_value_two = $secondary_opacity_setting / 100; // Convert percentage to decimal
                            $css .= '--color-set-one-2: rgba(' . $secondary_color_settings . ', ' . $alpha_value_two . ')!important; ';
                        } else { 
                            $css .= '--color-set-one-2: rgb(' . $secondary_color_settings . ')!important; ';
                        }
                    }  
                    // Add secondary rgb color CSS variable if not empty
                    list($r, $g, $b) = sscanf($third_color_setting, "#%02x%02x%02x");
                    $third_color_settings = "$r, $g, $b"; 
                    if (!empty($third_color_setting)) {
                        $css .= '--color-set-one-2-rgb: ' . $third_color_settings . '!important; ';
                    } 
                    // Add Heading color CSS variable if not empty 
                    list($r, $g, $b) = sscanf($heading_color_setting, "#%02x%02x%02x");
                    $heading_color_settings = "$r, $g, $b"; 
                    if (!empty($heading_color_setting)) { 
                        if (!empty($heading_opacity_setting)) {
                            $alpha_value_three = $heading_opacity_setting / 100; // Convert percentage to decimal
                            $css .= '--heading-color-one: rgba(' . $heading_color_settings . ', ' . $alpha_value_three . ')!important; ';
                        } else { 
                            $css .= '--heading-color-one: rgb(' . $heading_color_settings . ')!important; ';
                        }
                    }  
                    // Add content 1 color CSS variable if not empty 
                    list($r, $g, $b) = sscanf($content_color_setting, "#%02x%02x%02x");
                    $content_color_settings = "$r, $g, $b"; 
                    if (!empty($content_color_setting)) { 
                        if (!empty($content_opacity_setting)) {
                            $alpha_value_four = $content_opacity_setting / 100; // Convert percentage to decimal
                            $css .= '--heading-color-one: rgba(' . $content_color_settings . ', ' . $alpha_value_four . ')!important; ';
                        } else { 
                            $css .= '--content-color-one: rgb(' . $content_color_settings . ')!important; ';
                        }
                    }  
                    // Add content 2 color CSS variable if not empty 
                    list($r, $g, $b) = sscanf($content_color_two_setting, "#%02x%02x%02x");
                    $content_color_two_settings = "$r, $g, $b"; 
                    if (!empty($content_color_two_setting)) { 
                        if (!empty($content_opacity_two_setting)) {
                            $alpha_value_five = $content_opacity_two_setting / 100; // Convert percentage to decimal
                            $css .= '--heading-color-two: rgba(' . $content_color_two_settings . ', ' . $alpha_value_five . ')!important; ';
                        } else { 
                            $css .= '--content-color-two: rgb(' . $content_color_two_settings . ')!important; ';
                        }
                    }  
                    // Add Border color CSS variable if not empty 
                    list($r, $g, $b) = sscanf($border_color_setting, "#%02x%02x%02x");
                    $border_color_settings = "$r, $g, $b"; 
                    if (!empty($border_color_setting)) { 
                        if (!empty($border_opacity_setting)) {
                            $alpha_value_six = $border_opacity_setting / 100; // Convert percentage to decimal
                            $css .= '--color-set-one-bor-1: rgba(' . $border_color_settings . ', ' . $alpha_value_six . ')!important; ';
                        } else { 
                            $css .= '--color-set-one-bor-1: rgb(' . $border_color_settings . ')!important; ';
                        }
                    }  
                    // Add background dark color CSS variable if not empty 
                    list($r, $g, $b) = sscanf($background_dark_color_setting, "#%02x%02x%02x");
                    $background_dark_color_settings = "$r, $g, $b"; 
                    if (!empty($background_dark_color_setting)) { 
                        if (!empty($background_dark_opacity_setting)) {
                            $alpha_value_seven = $background_dark_opacity_setting / 100; // Convert percentage to decimal
                            $css .= '
                            --background-bg-1: rgb(' . $background_dark_color_settings . ', ' . $alpha_value_seven . ')!important; 
                            
                            ';
                        } else { 
                            $css .= '
                            --background-bg-1: rgb(' . $background_dark_color_settings . ')!important;
                             
                            ';
                        }
                    }  
                    // Add background light color CSS variable if not empty 
                    list($r, $g, $b) = sscanf($background_light_color_setting, "#%02x%02x%02x");
                    $background_light_color_settings = "$r, $g, $b"; 
                    if (!empty($background_light_color_setting)) { 
                        if (!empty($background_light_opacity_setting)) {
                            $alpha_value_eight = $background_light_opacity_setting / 100; // Convert percentage to decimal
                            $css .= ' 
                            --background-bg-2: rgb(' . $background_dark_color_settings . ', ' . $alpha_value_seven . ')!important;
                            --background-bg-3: rgb(' . $background_dark_color_settings . ', ' . $alpha_value_seven . ')!important;
                            --background-bg-4: rgb(' . $background_dark_color_settings . ', ' . $alpha_value_seven . ')!important;
                            ';
                        } else { 
                            $css .= ' 
                            --background-bg-2: rgb(' . $background_dark_color_settings . ')!important;
                            --background-bg-3: rgb(' . $background_dark_color_settings . ')!important;
                            --background-bg-4: rgb(' . $background_dark_color_settings . ')!important;
                            ';
                        }
                    }  
                    // Close the :root block
                    $css .= '}';
                }
            } 
            // Theme Color Css
            // Single Blog Css
            if(is_singular('post')){
                $feature_image_fit = coreit_get_option('feature_image_fit' , false);
                if($feature_image_fit  ==  true){
                    $feature_image_fit_height = coreit_get_option('feature_image_fit_height' , 600);
                    if(!empty($feature_image_fit_height)):
                        $css .= '  .single_feature_image img {height:'.$feature_image_fit_height.'px}';
                    endif;
                 }
            }
            // Single Portfolio Css
            if(is_singular('portfolio')){
            $sing_portfolioimage_fit_enable = coreit_get_option('sing_portfolioimage_fit_enable' , false);
            if($sing_portfolioimage_fit_enable  ==  true){
                $sing_portfolio_fit_image_height = coreit_get_option('sing_portfolio_fit_image_height' , 350);
                if(!empty($sing_portfolio_fit_image_height)):
                    $css .= ' .single_feature_image img {height:'.$sing_portfolio_fit_image_height.'px!important;}';
                endif;
             }
            }
            // Single Portfolio Css
            // Single Service Css
            if(is_singular('service')){
            $sing_serviceimage_fit_enable = coreit_get_option('sing_serviceimage_fit_enable' , false);
            if($sing_serviceimage_fit_enable  ==  true){ 
                $sing_service_fit_image_height = coreit_get_option('sing_service_fit_image_height' , 350);
                if($sing_service_fit_image_height):
                    $css .= '.single_feature_image img {height:'.$sing_service_fit_image_height.'px!important;}';
                endif;
            }}
            // Single  Service Css
            // Single  Team Css
            if(is_singular('team')){
                $sing_teamimage_fit_enable = coreit_get_option('sing_teamimage_fit_enable' , false);
                if($sing_teamimage_fit_enable  ==  true){ 
                $sing_team_fit_image_height = coreit_get_option('sing_team_fit_image_height' , 350);
                if(!empty($sing_team_fit_image_height)):
                    $css .= '.single_feature_image img {height:'.$sing_team_fit_image_height.'px!important;}';
                endif;
            }}
            // Single  Team Css

            // Single  Team Css
            if(is_singular('team')){
                $sing_teamimage_fit_enable = coreit_get_option('sing_teamimage_fit_enable' , false);
                if($sing_teamimage_fit_enable  ==  true){ 
                $sing_team_fit_image_height = coreit_get_option('sing_team_fit_image_height' , 350);
                if(!empty($sing_team_fit_image_height)):
                    $css .= '.single_feature_image img {height:'.$sing_team_fit_image_height.'px!important;}';
                endif;
            }}
            // Single  Team Css
            // Blog Card Feature Iamge css
            if (is_home() && !is_front_page()) { // Ensures it's the blog page but not the front page
                $blog_image_fit_enable = coreit_get_option('blog_image_fit_enable', false);
                
                if ($blog_image_fit_enable) { 
                    $blog_fit_image_height = coreit_get_option('blog_fit_image_height', 350);
                    
                    if (!empty($blog_fit_image_height)) {
                        $css .= '.blog .cardNews .img_obj_fit_center img {height:'.$blog_fit_image_height.'px!important;}';
                    }
                }
            } 
               // Blog Card Feature Iamge css
            // Body Css
            $body_bg_color = coreit_get_option('body_bg_color');
            list($r, $g, $b) = sscanf($body_bg_color, "#%02x%02x%02x");
            $body_bg_color_rgb = "$r, $g, $b"; // Adjust the opacity value as needed
            $body_bg_color_opactiy = coreit_get_option('body_bg_color_opactiy');  
            $body_bg_image = coreit_get_option('body_bg_image');
            $body_bg_cover = coreit_get_option('body_bg_cover');
            $body_bg_position = coreit_get_option('body_bg_position');
            $body_bg_repeat = coreit_get_option('body_bg_repeat');
            $body_bg_attachment = coreit_get_option('body_bg_attachment'); 
            if(!empty($body_bg_image) || !empty($body_bg_cover) || !empty($body_bg_position) || !empty($body_bg_repeat)
            || !empty($body_bg_attachment)){
                $css .= 'body { ';
                    if (!empty($body_bg_image)) {  $css .= '   background-image: url("' . $body_bg_image . '")!important; '; }
                    if (!empty($body_bg_cover)) {  $css .= '   background-size: ' . $body_bg_cover . '!important; '; }
                    if (!empty($body_bg_position)) {  $css .= '   background-position: ' . $body_bg_position . '!important; '; }
                    if (!empty($body_bg_repeat)) {  $css .= '   background-repeat: ' . $body_bg_repeat . '!important; '; }
                    if (!empty($body_bg_attachment)) {  $css .= '   background-attachment: ' . $body_bg_attachment . '!important; '; }
                    if (!empty($body_bg_color)) {
                        if (!empty($body_bg_color_opactiy)) {
                            $alpha_value_eight = $body_bg_color_opactiy / 100; // Convert percentage to decimal
                            $css .= ' background-color: rgba(' . $body_bg_color_rgb . ', ' . $alpha_value_eight . ')!important;';
                        }else{
                            $css .= 'background-color: rgb(' . $body_bg_color_rgb . ')!important;';
                        }
                    }
                $css .= '}';
            }
            // Body css
             // Menu Color Css
             $enable_theme_color = coreit_get_option('enable_menu_color', false);
             if ($enable_theme_color == true) { 
                 $menu_color_settings = coreit_get_option('menu_color_settings');
                 $menu_opacity_settings = coreit_get_option('menu_opacity_settings');
                 $menu_active_color_settings = coreit_get_option('menu_active_color_settings');
                 $menu_active_opacity_settings = coreit_get_option('menu_active_opacity_settings');
                 $menu_bg_active_color_settings = coreit_get_option('menu_bg_active_color_settings');
                 $menu_bg_active_opacity_settings = coreit_get_option('menu_bg_active_opacity_settings');
                 $dropdown_bg_color_settings = coreit_get_option('dropdown_bg_color_settings');
                 $dropdown_bg_opacity_settings = coreit_get_option('dropdown_bg_opacity_settings');
                 $dropdown_menu_color_settings = coreit_get_option('dropdown_menu_color_settings');
                 $dropdown_menu_opacity_settings = coreit_get_option('dropdown_menu_opacity_settings'); 
                 $dropdown_menu_active_color_settings = coreit_get_option('dropdown_menu_active_color_settings');
                 $dropdown_menu_active_opacity_settings = coreit_get_option('dropdown_menu_active_opacity_settings');    
                 // Check if either primary or secondary color settings are not empty
                 if (!empty($menu_color_settings) || !empty($menu_opacity_settings || $menu_active_color_settings
                 || $menu_bg_active_color_settings || $dropdown_bg_color_settings || $dropdown_menu_color_settings
                 || $dropdown_menu_active_color_settings)) { 
                     // Start the :root block
                     $css .= ':root {'; 
                     // Add Menu color CSS variable if not empty
                     list($r, $g, $b) = sscanf($menu_color_settings, "#%02x%02x%02x");
                     $menu_color_settingss = "$r, $g, $b"; 
                     if (!empty($menu_color_settings)) { 
                         if (!empty($menu_opacity_settings)) {
                            $alpha_value_nine = $menu_opacity_settings / 100; // Convert percentage to decimal
                             $css .= '--menu-color: rgba(' . $menu_color_settingss . ', ' . $alpha_value_nine . ')!important; ';
                             $css .= '--menu-color-white: rgba(' . $menu_color_settingss . ', ' . $alpha_value_nine . ')!important; '; 
                         } else { 
                             $css .= '--menu-color: rgb(' . $menu_color_settingss . ')!important; ';
                             $css .= '--menu-color-white: rgb(' . $menu_color_settingss . ')!important; ';
                         }
                     }  
                     // Add Menu Active color CSS variable if not empty
                     list($r, $g, $b) = sscanf($menu_active_color_settings, "#%02x%02x%02x");
                     $menu_active_color_settingss = "$r, $g, $b"; 
                     if (!empty($menu_active_color_settings)) { 
                         if (!empty($menu_active_opacity_settings)) {
                            $alpha_value_ten = $menu_active_opacity_settings / 100; // Convert percentage to decimal
                             $css .= '--menu-color-active: rgba(' . $menu_active_color_settingss . ', ' . $alpha_value_ten . ')!important; ';
                         } else { 
                             $css .= '--menu-color-active: rgb(' . $menu_active_color_settingss . ')!important; ';
                         }
                     }  
                    // Add Menu Active Bg color CSS variable if not empty
                    list($r, $g, $b) = sscanf($menu_bg_active_color_settings, "#%02x%02x%02x");
                    $menu_bg_active_color_settingss = "$r, $g, $b"; 
                    if (!empty($menu_bg_active_color_settings)) { 
                        if (!empty($menu_bg_active_opacity_settings)) {
                            $alpha_value_eleven = $menu_bg_active_opacity_settings / 100; // Convert percentage to decimal
                            $css .= '--menu-active-hover-bg-color: rgba(' . $menu_bg_active_color_settingss . ', ' . $alpha_value_eleven . ')!important; ';
                        } else { 
                            $css .= '--menu-active-hover-bg-color: rgb(' . $menu_bg_active_color_settingss . ')!important; ';
                        }
                    }  
                    // Add Drop Menu  Bg color CSS variable if not empty
                    list($r, $g, $b) = sscanf($dropdown_bg_color_settings, "#%02x%02x%02x");
                    $dropdown_bg_color_settingss = "$r, $g, $b"; 
                    if (!empty($dropdown_bg_color_settings)) { 
                        if (!empty($dropdown_bg_opacity_settings)) {
                            $alpha_value_tweleve = $dropdown_bg_opacity_settings / 100; // Convert percentage to decimal
                            $css .= '--dbg-color: rgba(' . $dropdown_bg_color_settingss . ', ' . $alpha_value_tweleve . ')!important; ';
                        } else { 
                            $css .= '--dbg-color: rgb(' . $dropdown_bg_color_settingss . ')!important; ';
                        }
                    }  
                     // Add Dropdown menu Color  color CSS variable if not empty
                     list($r, $g, $b) = sscanf($dropdown_menu_color_settings, "#%02x%02x%02x");
                     $dropdown_menu_color_settingss = "$r, $g, $b"; 
                     if (!empty($dropdown_menu_color_settings)) { 
                         if (!empty($dropdown_menu_opacity_settings)) {
                            $alpha_value_thir = $dropdown_menu_opacity_settings / 100; // Convert percentage to decimal
                             $css .= '--dmenu-color: rgba(' . $dropdown_menu_color_settingss . ', ' . $alpha_value_thir . ')!important; ';
                         } else { 
                             $css .= '--dmenu-color: rgb(' . $dropdown_menu_color_settingss . ')!important; ';
                         }
                     }  
                       // Add Dropdown menu active Color  color CSS variable if not empty
                       list($r, $g, $b) = sscanf($dropdown_menu_active_color_settings, "#%02x%02x%02x");
                       $dropdown_menu_active_color_settingss = "$r, $g, $b"; 
                       if (!empty($dropdown_menu_active_color_settingss)) { 
                           if (!empty($dropdown_menu_active_opacity_settings)) {
                            $alpha_value_fourrt = $dropdown_menu_active_opacity_settings / 100; // Convert percentage to decimal
                               $css .= '--dmenu-color: rgba(' . $dropdown_menu_active_color_settingss . ', ' . $alpha_value_fourrt . ')!important; ';
                           } else { 
                               $css .= '--dmenu-color: rgb(' . $dropdown_menu_active_color_settingss . ')!important; ';
                           }
                       }  
                    // Close the :root block
                     $css .= '}';
                 }
             } 
             // Theme Color Css
             // Preloader 
             $preloader_style =  coreit_get_option('preloader_style', 'disable');
             if($preloader_style != "disable"){
                $preloader_color_one =  coreit_get_option('preloader_color_one');
                $preloader_opacity_one =  coreit_get_option('preloader_opacity_one');
                $preloader_color_two =  coreit_get_option('preloader_color_two');
                $preloader_opacity_two =  coreit_get_option('preloader_opacity_two');
                $preloader_bg_color =  coreit_get_option('preloader_bg_color');
                $preloader_bg_opacity =  coreit_get_option('preloader_bg_opacity');
                if (!empty($preloader_color_one) || !empty($preloader_color_two) || !empty($preloader_bg_color)) { 
                $css .= ':root {'; 
                list($r, $g, $b) = sscanf($preloader_color_one, "#%02x%02x%02x");
                $preloader_color_ones = "$r, $g, $b"; 
                if (!empty($preloader_color_one)) { 
                    if (!empty($preloader_opacity_one)) {
                        $alpha_value_fifteen = $preloader_opacity_one / 100; // Convert percentage to decimal
                        $css .= '--preloader-spinner-color-1: rgba(' . $preloader_color_ones . ', ' . $alpha_value_fifteen . ')!important; ';
                    } else { 
                        $css .= '--preloader-spinner-color-1: rgb(' . $preloader_color_ones . ')!important; ';
                    }
                }  
                list($r, $g, $b) = sscanf($preloader_color_two, "#%02x%02x%02x");
                $preloader_color_twos = "$r, $g, $b"; 
                if (!empty($preloader_color_two)) { 
                    if (!empty($preloader_opacity_two)) {
                        $alpha_value_sixteen = $preloader_opacity_two / 100; // Convert percentage to decimal
                        $css .= '--preloader-spinner-color-2: rgba(' . $preloader_color_twos . ', ' . $alpha_value_sixteen . ')!important; ';
                    } else { 
                        $css .= '--preloader-spinner-color-2: rgb(' . $preloader_color_twos . ')!important; ';
                    }
                } 
                list($r, $g, $b) = sscanf($preloader_bg_color, "#%02x%02x%02x");
                $preloader_bg_colors = "$r, $g, $b"; 
                if (!empty($preloader_bg_color)) { 
                    if (!empty($preloader_bg_opacity)) {
                        $alpha_value_seventeen = $preloader_bg_opacity / 100; // Convert percentage to decimal
                        $css .= '--preloader-background-color: rgba(' . $preloader_bg_colors . ', ' . $alpha_value_seventeen . ')!important; ';
                    } else { 
                        $css .= '--preloader-background-color: rgb(' . $preloader_bg_colors . ')!important; ';
                    }
                }  
                // Close the :root block
                $css .= '}';
            }
             }
             // Preloader 
            // Page header css 
            $page_header_enables = coreit_get_option('page_header_enables', true);
            if ($page_header_enables == true) { 
                $page_header_style = coreit_get_option('page_header_style', 'default');
                $breadcrumb_enable = coreit_get_option('breadcrumb_enable', true);
                $page_header_alignment = coreit_get_option('page_header_alignment' , 'flex-start');
                $aligncenter = "";
                if($page_header_alignment == "center"){
                    $aligncenter = "center";
                }
                if($page_header_alignment == "flex-end"){
                    $aligncenter = "right";
                }
                if($page_header_alignment == "center" || $page_header_alignment == "flex-end"){
                    // Check if either primary or secondary color settings are not empty
                    if (!empty($page_header_alignment)) {   
                        $css .= '.breadcrumbs-div .inner_bx{justify-content:' . $page_header_alignment . '!important; text-align:' . $aligncenter . '!important; }
                        .breadcrumbs-only ul.breadcrumb , .breadcrumbs-div .inner_bx ul.breadcrumb{justify-content:' . $page_header_alignment . '!important; }';
                    } 
                }
                if($page_header_style == "default"){
                // background image css  
                $pageheader_bg_cover = coreit_get_option('pageheader_bg_cover');
                $pageheader_bg_position = coreit_get_option('pageheader_bg_position');
                $pageheader_bg_repeat = coreit_get_option('pageheader_bg_repeat');
                $pageheader_bg_attachment = coreit_get_option('pageheader_bg_attachment'); 
                if(!empty($pageheader_bg_cover) || !empty($pageheader_bg_position) || !empty($pageheader_bg_repeat)
                || !empty($pageheader_bg_attachment)){
                    $css .= '.breadcrumbs-div .bakground_cover{ ';
                        if (!empty($pageheader_bg_image)) {  $css .= '   background-image: url("' . $pageheader_bg_image . '")!important; '; }
                        if (!empty($pageheader_bg_cover)) {  $css .= '   background-size: ' . $pageheader_bg_cover . '!important; '; }
                        if (!empty($pageheader_bg_position)) {  $css .= '   background-position: ' . $pageheader_bg_position . '!important; '; }
                        if (!empty($pageheader_bg_repeat)) {  $css .= '   background-repeat: ' . $pageheader_bg_repeat . '!important; '; }
                        if (!empty($pageheader_bg_attachment)) {  $css .= '   background-attachment: ' . $pageheader_bg_attachment . '!important; '; }
                    $css .= '}';
                }
                // page_header_bg_color
                $page_header_bg_color = coreit_get_option('page_header_bg_color');
                $page_header_bg_opacity = coreit_get_option('page_header_bg_opacity');
                list($r, $g, $b) = sscanf($page_header_bg_color, "#%02x%02x%02x");
                $page_header_bg_colors = "$r, $g, $b"; 
                    if (!empty($page_header_bg_opacity)) { 
                        if (!empty($page_header_bg_color)) {  
                            $page_header_bg_opacity_float = $page_header_bg_opacity / 100;
                            $css .= '.breadcrumbs-div , .breadcrumbs-div .bakground_cover::before{background: rgba(' . $page_header_bg_colors . ', ' . $page_header_bg_opacity_float . ')!important; opacity:1!important;}';
                        }
                    } else { 
                        if (!empty($page_header_bg_color)) { 
                        $css .= '.breadcrumbs-div , .breadcrumbs-div .bakground_cover::before{background: rgb(' . $page_header_bg_colors . ')!important; }';
                    }
                    }
                 // page_header_title_color
                 $page_header_title_color = coreit_get_option('page_header_title_color');
                 $page_header_title_opacity = coreit_get_option('page_header_title_opacity');
                 list($r, $g, $b) = sscanf($page_header_title_color, "#%02x%02x%02x");
                 $page_header_title_colors = "$r, $g, $b"; 
                 if (!empty($page_header_title_color)) { 
                     if (!empty($page_header_title_opacity)) {
                        $alpha_value_eighteen = $page_header_title_opacity / 100; // Convert percentage to decimal
                         $css .= '.breadcrumbs-div .inner_bx .page_title{color: rgba(' . $page_header_title_colors . ', ' . $alpha_value_eighteen . ')!important;} ';
                     } else { 
                         $css .= '.breadcrumbs-div .inner_bx .page_title{color: rgb(' . $page_header_title_colors . ')!important;} ';
                     }
                 }
                }
                   // breadcrumb_color
                   $breadcrumb_color = coreit_get_option('breadcrumb_color');
                   $breadcrumb_opacity = coreit_get_option('page_header_title_opacity');
                   list($r, $g, $b) = sscanf($breadcrumb_color, "#%02x%02x%02x");
                   $breadcrumb_colors = "$r, $g, $b"; 
                   if (!empty($breadcrumb_color)) { 
                       if (!empty($breadcrumb_opacity)) {
                           $css .= 'body ul.breadcrumb li , body  ul.breadcrumb li::before, body  ul.breadcrumb li a{color: rgba(' . $breadcrumb_colors . ', ' . $breadcrumb_opacity . ')!important;} ';
                       } else { 
                           $css .= 'body  ul.breadcrumb li , body  ul.breadcrumb li::before, body  ul.breadcrumb li a{color: rgb(' . $breadcrumb_colors . ')!important;} ';
                       }
                   }  
                   if($page_header_style == "style1"){
                    // breadcrumb_bg_color
                   $breadcrumb_bg_color = coreit_get_option('breadcrumb_bg_color');
                   $breadcrumb_bg_opacity = coreit_get_option('breadcrumb_bg_opacity');
                   list($r, $g, $b) = sscanf($breadcrumb_bg_color, "#%02x%02x%02x");
                   $breadcrumb_bg_colors = "$r, $g, $b"; 
                   if (!empty($breadcrumb_bg_color)) { 
                       if (!empty($breadcrumb_bg_opacity)) {
                        $alpha_value_ninteen = $breadcrumb_bg_opacity / 100; // Convert percentage to decimal
                           $css .= '.breadcrumbs-only{background: rgba(' . $breadcrumb_bg_colors . ', ' . $alpha_value_ninteen . ')!important;} ';
                       } else { 
                           $css .= '.breadcrumbs-only{background: rgb(' . $breadcrumb_bg_colors . ')!important;} ';
                       }
                   } 
                      // breadcrumb_border_opacity
                      $breadcrumb_border_color = coreit_get_option('breadcrumb_border_color');
                      $breadcrumb_border_opacity = coreit_get_option('breadcrumb_border_opacity');
                      list($r, $g, $b) = sscanf($breadcrumb_border_color, "#%02x%02x%02x");
                      $breadcrumb_border_colors = "$r, $g, $b"; 
                      if (!empty($breadcrumb_border_color)) { 
                          if (!empty($breadcrumb_border_opacity)) {
                            $alpha_value_twenty = $breadcrumb_border_opacity / 100; // Convert percentage to decimal
                              $css .= '.breadcrumbs-only{border-bottom: 1px solid rgba(' . $breadcrumb_border_colors . ', ' . $alpha_value_twenty . ')!important;} ';
                          } else { 
                              $css .= '.breadcrumbs-only{border-bottom: 1px solid rgb(' . $breadcrumb_border_colors . ')!important;} ';
                          }
                      } 
                    }
            } 
            // Page Header Padding CSS 
            if ($page_header_enables == true) {
                // Get padding settings
                $page_header_padding_top = coreit_get_option('page_header_padding_top', '50');
                $page_header_padding_bottom = coreit_get_option('page_header_padding_bottom', '50');
              
                $mobile_page_header_padding_top = coreit_get_option('mobile_page_header_padding_top', '30');
                $mobile_page_header_padding_bottom = coreit_get_option('mobile_page_header_padding_bottom', '30');
                
                // Desktop padding
                if (!empty($page_header_padding_top) || !empty($page_header_padding_bottom) || 
                    !empty($page_header_padding_left) || !empty($page_header_padding_right)) {
                    $css .= '.breadcrumbs-div { ';
                    if (!empty($page_header_padding_top)) { 
                        $css .= 'padding-top: ' . $page_header_padding_top . 'px!important; '; 
                    }
                    if (!empty($page_header_padding_bottom)) { 
                        $css .= 'padding-bottom: ' . $page_header_padding_bottom . 'px!important; '; 
                    } 
                    $css .= '}';
                }
                
                // Mobile padding
                if (!empty($mobile_page_header_padding_top) || !empty($mobile_page_header_padding_bottom)) {
                    $css .= '@media (max-width: 768px) { ';
                    $css .= '.breadcrumbs-div { ';
                    if (!empty($mobile_page_header_padding_top)) { 
                        $css .= 'padding-top: ' . $mobile_page_header_padding_top . 'px!important; '; 
                    }
                    if (!empty($mobile_page_header_padding_bottom)) { 
                        $css .= 'padding-bottom: ' . $mobile_page_header_padding_bottom . 'px!important; '; 
                    }
                    $css .= '}';
                    $css .= '}';
                }
                
                // For breadcrumb-only style (style1)
                $page_header_style = coreit_get_option('page_header_style', 'default');
                if ($page_header_style == "style1") {
                    if (!empty($page_header_padding_top) || !empty($page_header_padding_bottom)) {
                        $css .= '.breadcrumbs-only { ';
                        if (!empty($page_header_padding_top)) { 
                            $css .= 'padding-top: ' . $page_header_padding_top . 'px!important; '; 
                        }
                        if (!empty($page_header_padding_bottom)) { 
                            $css .= 'padding-bottom: ' . $page_header_padding_bottom . 'px!important; '; 
                        }
                        
                        $css .= '}';
                    }
                     
                    // Mobile padding for breadcrumb-only
                    if (!empty($mobile_page_header_padding_top) || !empty($mobile_page_header_padding_bottom)) {
                        $css .= '@media (max-width: 768px) { ';
                        $css .= '.breadcrumbs-only { ';
                        if (!empty($mobile_page_header_padding_top)) { 
                            $css .= 'padding-top: ' . $mobile_page_header_padding_top . 'px!important; '; 
                        }
                        if (!empty($mobile_page_header_padding_bottom)) { 
                            $css .= 'padding-bottom: ' . $mobile_page_header_padding_bottom . 'px!important; '; 
                        }
                        $css .= '}';
                        $css .= '}';
                    }
                }
            }
            // Page Header Padding CSS End 
            wp_add_inline_style('coreit-style', $css);
        }
}  
new Customizer();
