<?php
/*
 ** ==============================
 ** Dashboard
 ** ==============================
 */
class coreit_Admin_Woo_Customizer{ 
    public function __construct(){   
        add_action('customize_register', [$this, 'coreit_woo_customize_options_register']);    
        add_action('wp_enqueue_scripts', [$this, 'coreit_woo_inline_css']);     
    } 
    public function coreit_woo_customize_options_register($wp_customize) { 
        // Card Start =================================
        /**
         * Woocommerce Product Card Settings
         */
        $wp_customize->add_section(
            'woocommerce_product_card_settings',
            array(
                'title'    => __('CoreIT Product Card  Settings', 'coreit'),
                'priority' => 30,
                'panel'    => 'woocommerce', // Link this sub-section to the 'header_section' panel
            )
        ); 
        
        // Rating Enable / Disable
        $wp_customize->add_setting(
            'rating_enable',
            array(
                'default'           => true,
                'sanitize_callback' => 'coreit_sanitize_checkbox',
            )
        );
        $wp_customize->add_control(
            'rating_enable',
            array(
                'type'     => 'checkbox',
                'section'  => 'woocommerce_product_card_settings',
                'label'    => __('Rating Enable / Disable', 'coreit'),
            )
        );
         // Rating Enable / Disable
         $wp_customize->add_setting(
            'shortdesc_enable',
            array(
                'default'           => true,
                'sanitize_callback' => 'coreit_sanitize_checkbox',
            )
        );
        $wp_customize->add_control(
            'shortdesc_enable',
            array(
                'type'     => 'checkbox',
                'section'  => 'woocommerce_product_card_settings',
                'label'    => __('Short Description Enable / Disable', 'coreit'),
            )
        );
        // Category Enable / Disable
        $wp_customize->add_setting(
            'category_enable',
            array(
                'default'           => true,
                'sanitize_callback' => 'coreit_sanitize_checkbox',
            )
        );
        $wp_customize->add_control(
            'category_enable',
            array(
                'type'     => 'checkbox',
                'section'  => 'woocommerce_product_card_settings',
                'label'    => __('Category Enable  / Disable', 'coreit'),
            )
        );
      
        // Add to Cart Enable / Disable 
        $wp_customize->add_setting(
            'add_to_cart_enable_disable',
            array(
                'default'           => true,
                'sanitize_callback' => 'coreit_sanitize_checkbox',
            )
        );
        $wp_customize->add_control(
            'add_to_cart_enable_disable',
            array(
                'type'     => 'checkbox',
                'section'  => 'woocommerce_product_card_settings',
                'label'    => __('Add To Cart Enable  / Disable ', 'coreit'),
            )
        );              
        // Sold Items Progress Bar Enable / Disable
        $wp_customize->add_setting(
            'sold_items_enable',
            array(
                'default'           => true,
                'sanitize_callback' => 'coreit_sanitize_checkbox',
            )
        );
        $wp_customize->add_control(
            'sold_items_enable',
            array(
                'type'     => 'checkbox',
                'section'  => 'woocommerce_product_card_settings',
                'label'    => __('Sold Items Progress Bar Enable  / Disable ', 'coreit'),
            )
        );
        // Badge Enable / Disable
        $wp_customize->add_setting(
            'badge_enable',
            array(
                'default'           => true,
                'sanitize_callback' => 'coreit_sanitize_checkbox',
            )
        );
        $wp_customize->add_control(
            'badge_enable',
            array(
                'type'     => 'checkbox',
                'section'  => 'woocommerce_product_card_settings',
                'label'    => __('Badge Enable  / Disable ', 'coreit'),
            )
        );
         // Quick View Enable / Disable
         $wp_customize->add_setting(
            'quick_view_enable',
            array(
                'default'           => true,
                'sanitize_callback' => 'coreit_sanitize_checkbox',
            )
        );
        $wp_customize->add_control(
            'quick_view_enable',
            array(
                'type'     => 'checkbox',
                'section'  => 'woocommerce_product_card_settings',
                'label'    => __('Quick View Enable  / Disable ', 'coreit'),
            )
        ); 
           // Compare Enable / Disable
           $wp_customize->add_setting(
            'comp_enable',
            array(
                'default'           => true,
                'sanitize_callback' => 'coreit_sanitize_checkbox',
            )
        );
        $wp_customize->add_control(
            'comp_enable',
            array(
                'type'     => 'checkbox',
                'section'  => 'woocommerce_product_card_settings',
                'label'    => __('Compare Enable  / Disable ', 'coreit'),
            )
        ); 
           // Quick View Enable / Disable
           $wp_customize->add_setting(
            'wish_enable',
            array(
                'default'           => true,
                'sanitize_callback' => 'coreit_sanitize_checkbox',
            )
        );
        $wp_customize->add_control(
            'wish_enable',
            array(
                'type'     => 'checkbox',
                'section'  => 'woocommerce_product_card_settings',
                'label'    => __('Wishlist Enable  / Disable ', 'coreit'),
            )
        ); 
        // Card End =================================
        // Archive Start ================================= 
        // Add Sections
        $wp_customize->add_section('woocommerce_archive_settings', array(
            'title'    => __('CoreIT Shop Settings', 'coreit'),
            'priority' => 30,
            'panel'    => 'woocommerce', // Link this sub-section to the 'header_section' panel
        ));
        
        $wp_customize->add_section('woocommerce_deals_settings', array(
            'title'    => __('CoreIT Deals Text Changing', 'coreit'),
            'priority' => 33,
            'panel'    => 'woocommerce', // Link this sub-section to the 'header_section' panel
        ));
        // Archive Settings
        
        $wp_customize->add_setting('grid_list_vide_enable', array(
            'default'           => true,
            'sanitize_callback' => 'coreit_sanitize_checkbox',
        ));
        $wp_customize->add_control('grid_list_vide_enable', array(
            'type'    => 'checkbox',
            'section' => 'woocommerce_archive_settings',
            'label'   => __('Grid / List View Enable / Disable In Shop Page', 'coreit'),
        ));
        $wp_customize->add_setting('per_page_enable', array(
            'default'           => true,
            'sanitize_callback' => 'coreit_sanitize_checkbox',
        ));
        $wp_customize->add_control('per_page_enable', array(
            'type'    => 'checkbox',
            'section' => 'woocommerce_archive_settings',
            'label'   => __('Select Products Per Page View Enable / Disable In Shop Page', 'coreit'),
        ));
        $wp_customize->add_setting('filter_content_enable', array(
            'default'           => true,
            'sanitize_callback' => 'coreit_sanitize_checkbox',
        ));
        $wp_customize->add_control('filter_content_enable', array(
            'type'    => 'checkbox',
            'section' => 'woocommerce_archive_settings',
            'label'   => __('Filter Button Enable / Disable In Shop Page', 'coreit'),
        ));
        $wp_customize->add_setting('recently_viewd_poducts', array(
            'default'           => true,
            'sanitize_callback' => 'coreit_sanitize_checkbox',
        ));
        $wp_customize->add_control('recently_viewd_poducts', array(
            'type'    => 'checkbox',
            'section' => 'woocommerce_archive_settings',
            'label'   => __('Recently Viewed Products Enable / Disable In Shop Page', 'coreit'),
        ));
        $wp_customize->add_setting('recent_title', array(
            'default'           => __('Recently Viewed Products', 'coreit'),
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('recent_title', array(
            'type'            => 'text',
            'section'         => 'woocommerce_archive_settings',
            'label'           => __('Recently Viewed Products Title', 'coreit'),
            'active_callback' => function () use ( $wp_customize ) {
                return $wp_customize->get_setting('recently_viewd_poducts')->value();
            },
        ));
        //$wp_customize->add_setting('product_single_style', array(
            //'default'           => 'style_one',
            //'sanitize_callback' => 'sanitize_text_field',
        //));
        //$wp_customize->add_control('product_single_style', array(
            //'type'    => 'select',
            //'section' => 'woocommerce_archive_settings',
            ////'label'   => __('Product Single Style', 'coreit'),
            //'choices' => array(
               // 'style_one'   => __('Style One (Default)', 'coreit'),
                //'style_two'   => __('Style Two', 'coreit'),
                //'style_three' => __('Style Three', 'coreit'),
                //'style_four'  => __('Style Four', 'coreit'),
           // ),
       // ));
        $wp_customize->add_setting('product_paginaion_type', array(
            'default'           => 'pagination',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('product_paginaion_type', array(
            'type'    => 'radio',
            'section' => 'woocommerce_archive_settings',
            'label'   => __('Pagination, Load More or Infinite Product Scroll', 'coreit'),
            'choices' => array(
                'pagination' => __('Woocommerce Product Pagination', 'coreit'),
                'loadmore'   => __('Woocommerce Product Loadmore', 'coreit'),
                'infinite'   => __('Woocommerce Product Infinite Scroll', 'coreit'),
            ),
        ));
        // Single Settings 
         // Deals Text Changing 
         $wp_customize->add_setting('deals_enable', array(
            'default'           => true,
            'sanitize_callback' => 'coreit_sanitize_checkbox',
        ));
        $wp_customize->add_control('deals_enable', array(
            'type'    => 'checkbox',
            'section' => 'woocommerce_deals_settings',
            'label'   => __('Deals Enable / Disable', 'coreit'),
        ));
        $wp_customize->add_setting('deal_days', array(
            'default'           => __('Days', 'coreit'),
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('deal_days', array(
            'type'    => 'text',
            'section' => 'woocommerce_deals_settings',
            'label'   => __('Days', 'coreit'),
        ));
        $wp_customize->add_setting('deal_hour', array(
            'default'           => __('Hours', 'coreit'),
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('deal_hour', array(
            'type'    => 'text',
            'section' => 'woocommerce_deals_settings',
            'label'   => __('Hours', 'coreit'),
        ));
        $wp_customize->add_setting('deal_mins', array(
            'default'           => __('Mins', 'coreit'),
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('deal_mins', array(
            'type'    => 'text',
            'section' => 'woocommerce_deals_settings',
            'label'   => __('Minutes', 'coreit'),
        ));
        $wp_customize->add_setting('deal_secs', array(
            'default'           => __('Secs', 'coreit'),
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('deal_secs', array(
            'type'    => 'text',
            'section' => 'woocommerce_deals_settings',
            'label'   => __('Secs', 'coreit'),
        ));
        // Archive End =================================
        
        // Woocommerce Share eend =================================
        // Woocommerce Wishlist Start =================================
        $wp_customize->add_section('woocommerce_compare_settings', array(
            'title'    => __('CoreIT Compare / Wishlist Settings', 'coreit'),
            'priority' => 35,
            'panel' => 'woocommerce'
        ));
        $wp_customize->add_setting('compare_enable', array(
            'default'           => false,
            'sanitize_callback' => 'coreit_sanitize_checkbox',
        ));
        $wp_customize->add_control('compare_enable', array(
            'type'    => 'checkbox',
            'section' => 'woocommerce_compare_settings',
            'label'   => __('Compare Enable / Disable', 'coreit'),
        ));
        // Option: Compare Page ID Select
        $wp_customize->add_setting( 'compare_archive_id', array(
            'default'           => '',
            'sanitize_callback' => 'absint',
        ) );
        $wp_customize->add_control( 'compare_archive_id', array(
            'label'    => __( 'Compare Page', 'coreit' ),
            'section'  => 'woocommerce_compare_settings',
            'type'     => 'dropdown-pages',
            'active_callback' => function () use ( $wp_customize ) {
                return $wp_customize->get_setting('compare_enable')->value();
            },
        ) ); 
        // Add settings and controls for text comparison
        $wp_customize->add_setting('coreit_compare_text', array(
            'default'           => 'Compare',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('coreit_compare_text', array(
            'label'    => __('Comparison Text', 'coreit'),
            'section'  => 'woocommerce_compare_settings',
            'settings' => 'coreit_compare_text',
            'type'     => 'text',
            'active_callback' => function () use ( $wp_customize ) {
                return $wp_customize->get_setting('compare_enable')->value();
            },
        )); 
        // Option: Wishlist Page ID Select
        $wp_customize->add_setting('wishlist_enable', array(
            'default'           => false,
            'sanitize_callback' => 'coreit_sanitize_checkbox',
        ));
        $wp_customize->add_control('wishlist_enable', array(
            'type'    => 'checkbox',
            'section' => 'woocommerce_compare_settings',
            'label'   => __('Wishlist Enable / Disable', 'coreit'),
        ));
        $wp_customize->add_setting( 'wishlist_archive_id', array(
            'default'           => '',
            'sanitize_callback' => 'absint',
        ) );
        $wp_customize->add_control( 'wishlist_archive_id', array(
            'label'    => __( 'Wishlist Page', 'coreit' ),
            'section'  => 'woocommerce_compare_settings',
            'type'     => 'dropdown-pages',
            'active_callback' => function () use ( $wp_customize ) {
                return $wp_customize->get_setting('wishlist_enable')->value();
            },
        ) );
         // Add settings and controls for text comparison
         $wp_customize->add_setting('coreit_wishlist_text', array(
            'default'           => 'Wishlist',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('coreit_wishlist_text', array(
            'label'    => __('Wishlist Text', 'coreit'),
            'section'  => 'woocommerce_compare_settings',
            'settings' => 'coreit_wishlist_text',
            'type'     => 'text',
            'active_callback' => function () use ( $wp_customize ) {
                return $wp_customize->get_setting('wishlist_enable')->value();
            },
        ));
        // Woocommerce Wishlist End =================================
        // Add section for Free Shipping Bar Start =================================
        $wp_customize->add_section( 'free_shipping_bar_section' , array(
            'title'      => __( 'CoreIT Free Shipping Bar', 'coreit' ),
            'priority'   => 30,
            'panel' => 'woocommerce'
        ));
        function my_custom_get_shipping_zones() {
            $zones = WC_Shipping_Zones::get_zones();
            $choices = array();
            foreach ($zones as $zone) {
                $choices[$zone['id']] = $zone['zone_name'];
            }
            return $choices;
        }
        $wp_customize->add_setting('free_shipping_zone', array(
            'default' => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('free_shipping_zone', array(
            'label'    => __('Free Shipping Zone', 'coreit'),
            'section'  => 'free_shipping_bar_section',
            'type'     => 'select',
            'choices'  => my_custom_get_shipping_zones(),
        ));
        // Add section for Free Shipping Bar End ================================= 
         /**
         * Sanitize checkbox value
         *
         * @param bool $checked Whether the checkbox is checked or not.
         * @return bool Whether the checkbox is checked or not.
         */
        function coreit_sanitize_checkbox( $checked ) {
            return ( ( isset( $checked ) && true == $checked ) ? true : false );
        }
    } 
    public function coreit_woo_inline_css() {
        $css = ''; 
        // Get primary and secondary color settings
        $deal_day = coreit_get_option('deal_days', 'Days');
        $deal_hours = coreit_get_option('deal_hour', 'Hours');
        $deal_min = coreit_get_option('deal_mins', 'Min'); 
        $deal_sec = coreit_get_option('deal_secs', 'Sec'); 
        if (!empty($deal_day)) {
            $css .= '.deals_box .deals-countdown .countdown-period.days:before { content: "' . esc_attr($deal_day) . '"; }';
        } 
        if (!empty($deal_hours)) {
            $css .= '.deals_box .deals-countdown .countdown-period.hours:before { content: "' . esc_attr($deal_hours) . '"; }';
        } 
        if (!empty($deal_min)) {
            $css .= '.deals_box .deals-countdown .countdown-period.mins:before { content: "' . esc_attr($deal_min) . '"; }';
        } 
        if (!empty($deal_sec)) {
            $css .= '.deals_box .deals-countdown .countdown-period.sec:before { content: "' . esc_attr($deal_sec) . '"; }';
        }
        // Add inline CSS
        if (!empty($css)) {
            wp_add_inline_style('coreit-style', $css);
        }
    }
}  
new coreit_Admin_Woo_Customizer();
