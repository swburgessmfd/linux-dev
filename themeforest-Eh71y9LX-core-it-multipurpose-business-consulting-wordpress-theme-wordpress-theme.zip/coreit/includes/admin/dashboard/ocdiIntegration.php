<?php
/**
 * OCDI Integration with Theme Setup Wizard
 * This file handles the integration of One Click Demo Import plugin
 * with your theme's custom setup wizard
 * Place this file in your theme's includes/admin/dashboard/ directory
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class to handle OCDI integration
 */
class CoreIT_OCDI_Integration {
    /**
     * Constructor
     */
    public function __construct() {
        // Remove original OCDI menu item
        add_action('admin_menu', array($this, 'remove_ocdi_menu_item'), 20);
        
        // Register modified OCDI callback function
        add_action('admin_menu', array($this, 'register_custom_ocdi_page'), 25);
        
        // Add the OCDI steps display on custom page
        add_action('admin_init', array($this, 'setup_ocdi_integration'));
        
        // Redirect OCDI requests to our custom URL
        add_action('init', array($this, 'redirect_ocdi_urls'), 5);
        
        // Add our custom wizard steps to OCDI pages
        add_action('ocdi/before_content', array($this, 'display_wizard_steps_before_content'), 5);
        
        // Add "Continue to Final Step" button after import
        add_action('ocdi/after_all_import_output', array($this, 'add_continue_button'));

        // Modify OCDI page settings to keep it within our wizard
        add_filter('ocdi/plugin_page_setup', array($this, 'modify_ocdi_page_setup'));
    }
    
    /**
     * Modify OCDI page settings to keep it within our wizard
     */
    public function modify_ocdi_page_setup($settings) {
        $settings['parent_slug'] = 'admin.php?page=coreit&step=demo_import';
        $settings['page_title']  = esc_html__('Demo Import', 'coreit');
        $settings['menu_title']  = esc_html__('Demo Import', 'coreit');
        $settings['capability']  = 'import';
        $settings['menu_slug']   = 'coreit-demo-import';
        
        return $settings;
    }
    
    /**
     * Remove the original OCDI menu item from Appearance
     */
    public function remove_ocdi_menu_item() {
        // Only remove if the class exists (plugin is active)
        if (class_exists('OCDI\\OneClickDemoImport')) {
            remove_submenu_page('themes.php', 'one-click-demo-import');
        }
    }
    
    /**
     * Register our custom OCDI page
     */
    public function register_custom_ocdi_page() {
        // Only add if the class exists (plugin is active)
        if (class_exists('OCDI\\OneClickDemoImport')) {
            // Get the OCDI instance
            $ocdi = OCDI\OneClickDemoImport::get_instance();
            
            // Call display_plugin_page() directly from our custom page
            add_submenu_page(
                'admin.php?page=coreit&step=demo_import', // Parent slug to keep it within our wizard
                esc_html__('Demo Import', 'coreit'),
                esc_html__('Demo Import', 'coreit'),
                'import',
                'coreit-demo-import', // Changed menu slug
                array($ocdi, 'display_plugin_page')
            );
        }
    }
    
    /**
     * Setup OCDI integration with our theme
     */
    public function setup_ocdi_integration() {
        // Only proceed if OCDI plugin is active
        if (!class_exists('OCDI\\OneClickDemoImport')) {
            return;
        }
        
        // Add styles for the wizard steps on OCDI pages
        add_action('admin_head', array($this, 'add_ocdi_integration_styles'));
    }
    
    /**
     * Add CSS styles for the wizard steps on OCDI pages
     */
    public function add_ocdi_integration_styles() {
        // Only add on OCDI pages
        global $pagenow;
        
        if ((isset($_GET['page']) && $_GET['page'] === 'coreit-demo-import') || 
            (isset($_GET['page']) && $_GET['page'] === 'one-click-demo-import')) {
            ?>
            <style>
                /* Previous styles remain the same */
                
                /* Additional style to integrate OCDI with wizard */
                .ocdi__content-container {
                    margin-top: 20px;
                }
                
                /* Hide unnecessary navigation if we want to keep it in the wizard */
                .ocdi__admin-header {
                    display: none;
                }
                
                /* Adjust content to fit wizard layout */
                .ocdi__content-container {
                    margin-left: 0;
                    margin-right: 0;
                }
            </style>
            <?php
        }
    }
    
    /**
     * Redirect OCDI URLs to our custom URL
     */
    public function redirect_ocdi_urls() {
        global $pagenow;
        
        // Redirect from themes.php?page=one-click-demo-import to our custom URL
        if ($pagenow === 'themes.php' && isset($_GET['page']) && $_GET['page'] === 'one-click-demo-import') {
            // Preserve all other query parameters
            $query_params = $_GET;
            unset($query_params['page']);
            
            // Set our custom parameters
            $query_params['page'] = 'coreit';
            $query_params['step'] = 'demo_import';
            
            // Redirect
            wp_redirect(add_query_arg($query_params, admin_url('admin.php')));
            exit;
        }
        
        // Redirect from custom-one-click-demo-import to our wizard
        if (isset($_GET['page']) && $_GET['page'] === 'custom-one-click-demo-import') {
            $query_params = $_GET;
            unset($query_params['page']);
            
            $query_params['page'] = 'coreit';
            $query_params['step'] = 'demo_import';
            
            wp_redirect(add_query_arg($query_params, admin_url('admin.php')));
            exit;
        }
    }
    
    /**
     * Display wizard steps before OCDI content
     */
    public function display_wizard_steps_before_content() {
        // Get the theme name
        $theme_name = wp_get_theme()->get('Name');
        
        // Define the wizard steps (must match those in the wizard class)
        $steps = array(
            'welcome'     => __('Welcome', 'coreit'),
            'child_theme' => __('Child Theme', 'coreit'),
            'plugins'     => __('Plugins', 'coreit'),
            'demo_import' => __('Demo Import', 'coreit'),
            'done'        => __('Done', 'coreit'),
        );
        
        // Output the wizard steps HTML
        echo '<div class="theme-setup-wizard ocdi-wizard-steps">';
        echo '<header class="wizard-header">';
        echo '<h1>' . sprintf(__('%s Setup', 'coreit'), $theme_name) . '</h1>';
        echo '</header>';
        
        // Output the wizard steps
        echo '<ul class="wizard-steps">';
        
        foreach ($steps as $step_key => $step_name) {
            $class = '';
            
            // Set classes based on step
            if ($step_key === 'demo_import') {
                $class = 'active';
            } elseif (array_search($step_key, array_keys($steps)) < array_search('demo_import', array_keys($steps))) {
                $class = 'done';
            }
            
            echo '<li class="' . esc_attr($class) . '">' . esc_html($step_name) . '</li>';
        }
        
        echo '</ul>';
        echo '</div>';
    }
    
    /**
     * Add "Continue to Final Step" button after import
     */
    public function add_continue_button() {
        $next_step_url = admin_url('admin.php?page=coreit&step=done');
        
        echo '<div class="ocdi-continue-wizard">';
        echo '<a href="' . esc_url($next_step_url) . '" class="button button-primary button-hero">';
        echo __('Continue to Final Step', 'coreit');
        echo '</a>';
        echo '</div>';
    }
}

// Initialize the class
new CoreIT_OCDI_Integration();
 