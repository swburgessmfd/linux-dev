<?php 
/**
 * Include theme setup wizard
 */
require_once get_template_directory() . '/includes/admin/dashboard/Themewizard.php';  

/**
 * Theme Setup Wizard Redirection
 * 
 * This function redirects users to the theme setup wizard
 * every time a theme (parent or child) is activated.
 */
function theme_setup_wizard_redirect() {
    global $pagenow;
    
    // Check if we're on the theme activation page
    if (is_admin() && 'themes.php' == $pagenow && isset($_GET['activated'])) {
        // Redirect to the setup wizard
        wp_redirect(admin_url('admin.php?page=coreit'));
        exit;
    }
}
add_action('admin_init', 'theme_setup_wizard_redirect');

/**
 * Optional: Add a cleanup function to remove activation flags for old themes
 */
function theme_setup_wizard_cleanup_activation_flags() {
    // Get all themes
    $themes = wp_get_themes();
    
    // Collect current theme slugs
    $current_theme_slugs = array_map(function($theme) {
        return $theme->get_stylesheet();
    }, $themes);
    
    // Find and delete old activation flags
    $option_prefix = 'theme_first_activation_';
    
    global $wpdb;
    $activation_flags = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} 
             WHERE option_name LIKE %s",
            $wpdb->esc_like($option_prefix) . '%'
        )
    );
    
    foreach ($activation_flags as $flag) {
        $theme_slug = str_replace($option_prefix, '', $flag->option_name);
        
        // Remove flag if theme no longer exists
        if (!in_array($theme_slug, $current_theme_slugs)) {
            delete_option($flag->option_name);
        }
    }
}
add_action('after_switch_theme', 'theme_setup_wizard_cleanup_activation_flags');

 
// Include TGM Plugin Activation
require_once get_template_directory() . '/includes/admin/dashboard/class-tgm-plugin-activation.php'; 
require_once get_template_directory() . '/includes/admin/dashboard/Plugins.php'; 
 
 
function ocdi_import_files() { 
    return [
      [
        'import_file_name'             => 'Demo Import 1',
        'categories'                   => [ 'Demo 1' ],
        'local_import_file'            => trailingslashit( get_template_directory() ) . 'includes/admin/dashboard/demos/v1/content.xml',
        'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'includes/admin/dashboard/demos/v1/widgets.wie',
        'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'includes/admin/dashboard/demos/v1/customizer.dat',
        'description' => 'Demo 1 - Comes with home 1 to 8 and All inner pages',
        'import_preview_image_url'     => trailingslashit( get_template_directory_uri() ) . 'screenshot.jpg',
        'preview_url'                  => 'https://coreit.themepanthers.com/demo',
      ],
      [
        'import_file_name'             => 'Demo Import 2',
        'categories'                   => [ 'Demo 2' ],
        'description' => 'Demo 1 - Comes with home 9 to 16',
        'local_import_file'            => trailingslashit( get_template_directory() ) . 'includes/admin/dashboard/demos/v2/content.xml',
        //'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'includes/admin/dashboard/demos/v2/widgets.wie',
        'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'includes/admin/dashboard/demos/v2/customizer.dat', 
        'import_preview_image_url'     => trailingslashit( get_template_directory_uri() ) . 'includes/admin/dashboard/demos/v2/demo-2.jpg', 
        'preview_url'                  => 'https://coreit.themepanthers.com/demo',
      ],
      [ 
        'import_file_name'             => 'Demo Import 3',
        'categories'                   => [ 'Demo 3' ],
        'description' => 'Demo 1 - Comes with home 17 and 18',
        'local_import_file'            => trailingslashit( get_template_directory() ) . 'includes/admin/dashboard/demos/v3/content.xml', 
        'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'includes/admin/dashboard/demos/v3/customizer.dat', 
        'import_preview_image_url'     => trailingslashit( get_template_directory_uri() ) . 'includes/admin/dashboard/demos/v3/demo-3.jpg', 
        'preview_url'                  => 'https://coreit.themepanthers.com/demo',
      ],
    ];
  }
  add_filter( 'ocdi/import_files', 'ocdi_import_files' );

/**
 * Actions to perform after import
 */
function theme_ocdi_after_import_setup($selected_import) {
    // Assign menus to their locations.
    $top_menu = get_term_by('name', 'Primary Menu', 'nav_menu');
    set_theme_mod('nav_menu_locations', array(
        'primary' => $top_menu->term_id,
    )); 

    // Set Front page 
    if ( 'Demo Import 3' === $selected_import['import_file_name'] ) { 
        $page = get_page_by_title('Home 17'); 
    }
    elseif ( 'Demo Import 2' === $selected_import['import_file_name'] ) { 
        $page = get_page_by_title('Home 9'); 
    }else{
        $page = get_page_by_title('Home'); 
    }
    update_option('page_on_front', $page->ID);
    update_option('show_on_front', 'page'); 

    // Set Blog page
    $blogpage = get_page_by_title('Blog'); 
    update_option('page_for_posts', $blogpage->ID);

    // Set permalink structure to "Post Name"
    update_option('permalink_structure', '/%postname%/');

    // Import Elementor site settings
    $elementor_settings = array(
        'custom_colors' => array(
            array('_id' => '72ed3cd', 'title' => 'CoreIt Light Bg', 'color' => '#F9F7F1'),
            array('_id' => '4526a05', 'title' => 'CoreIt Main Theme Color 2', 'color' => '#002B22'),
            array('_id' => 'ac1adaf', 'title' => 'CoreIt Main Theme Color 1', 'color' => '#C5E96B'),
            array('_id' => '4076084', 'title' => 'CoreIt Main Theme Color 3', 'color' => '#B2D45B'),
            array('_id' => '1688aac', 'title' => 'CoreIt Heading Color 1', 'color' => '#182F27'),
            array('_id' => '1cba9b3', 'title' => 'CoreIt Content Color 1', 'color' => '#6B6A66'),
            array('_id' => 'c06f1d9', 'title' => 'Coreit Content Color 2', 'color' => '#A9A7A1'),
            array('_id' => 'c17fe23', 'title' => 'Coreit Content Light Color 1', 'color' => '#A7B5BB'),
            array('_id' => '8987a51', 'title' => 'CoreIt Border Color 1', 'color' => '#ECEBE4'),
            array('_id' => '45295a1', 'title' => 'CoreIt Border Color 2', 'color' => '#E4E2D7'),
            array('_id' => 'eea3424', 'title' => 'CoreIt Color White', 'color' => '#FFFFFF'),
            array('_id' => '4a242fc', 'title' => 'CoreIt Background White', 'color' => '#FFFFFF'),
            array('_id' => 'ccd536d', 'title' => 'CoreIt Border White', 'color' => '#FFFFFF'),
            array('_id' => '7992c1f', 'title' => 'CoreIt Menu Color', 'color' => '#182F27'),
            array('_id' => '4941c3f', 'title' => 'CoreIt Menu Color White', 'color' => '#FFFFFF'),
            array('_id' => '75b1088', 'title' => 'CoreIt Menu Active Color', 'color' => '#C6E96C'),
            array('_id' => 'b67fde9', 'title' => 'CoreIt Light Bg 1', 'color' => '#F9F8F2'),
            array('_id' => '51ddb00', 'title' => 'Content Color Light 2', 'color' => '#7F9590'),
            array('_id' => '64c1724', 'title' => 'CoreIt border color dark 1', 'color' => '#1C443C'),
            array('_id' => 'eaf5c75', 'title' => 'Coreit Mid Dark Background', 'color' => '#05352B'),
            array('_id' => '767ec27', 'title' => 'CoreIt Background Light 2', 'color' => '#ECEBE5'),
            array('_id' => 'bdc886a', 'title' => 'CoreIt Theme Color 2 Opacity Less', 'color' => '#002B22E0'),
            array('_id' => 'ed88c22', 'title' => 'CoreIT Theme Color 3', 'color' => '#B2D45B'),
            array('_id' => '7ad13e3', 'title' => 'CoreIt Mid Dark Background 2', 'color' => '#A3B993'),
            array('_id' => 'b6f052b', 'title' => 'CoreIt Text Color For Main Theme Color1', 'color' => '#182F27')
        ),
        'system_colors' => array(
            array('_id' => 'primary', 'title' => 'Primary', 'color' => '#6EC1E4'),
            array('_id' => 'secondary', 'title' => 'Secondary', 'color' => '#54595F'),
            array('_id' => 'text', 'title' => 'Text', 'color' => '#7A7A7A'),
            array('_id' => 'accent', 'title' => 'Accent', 'color' => '#61CE70')
        ), 
        'default_generic_fonts' => 'Sans-serif',
        'page_title_selector' => 'h1.entry-title',
        'activeItemIndex' => 25,
        'viewport_md' => 768,
        'viewport_lg' => 1025,
        'active_breakpoints' => array(
            'viewport_mobile',
            'viewport_mobile_extra',
            'viewport_tablet',
            'viewport_tablet_extra',
            'viewport_laptop',
            'viewport_widescreen'
        ), 
        'colors_enable_styleguide_preview' => 'yes'
    );

    // Ensure Elementor is active
    if (!did_action('elementor/loaded')) {
        return;
    }

    // Update Elementor site settings
    update_option('elementor_site_settings', $elementor_settings);

    // Update active kit if needed
    $active_kit_id = get_option('elementor_active_kit');
    if ($active_kit_id) {
        update_post_meta($active_kit_id, '_elementor_page_settings', $elementor_settings);
    }

    // Additional Elementor settings
    update_option('elementor_disable_color_schemes', 'yes');
    update_option('elementor_disable_typography_schemes', 'yes');
    update_option('elementor_container_width', '1290');
    update_option('elementor_space_between_widgets', '0');
    update_option('elementor_global_image_lightbox', 'yes');
   
}
add_action('ocdi/after_import', 'theme_ocdi_after_import_setup');
 
 
 



/**
 * Disable OCDI branding and speed up import
 */
add_filter('ocdi/disable_pt_branding', '__return_true');
add_filter('ocdi/regenerate_thumbnails_in_content_import', '__return_false'); 
  

/**
 * Add logging to track which demo import is running
 */
function log_demo_import_process($selected_import) {
    // Log which demo is being imported to the WordPress error log
    error_log('CoreIT IMPORTING DEMO: ' . $selected_import['import_file_name']);
    error_log('CoreIT IMPORT FILE: ' . $selected_import['local_import_file']);
    
    // You can also create a custom log file if needed
    $log_file = WP_CONTENT_DIR . '/coreit-import-log.txt';
    $log_message = date('[Y-m-d H:i:s]') . ' Importing: ' . $selected_import['import_file_name'] . 
                  ' - File: ' . $selected_import['local_import_file'] . PHP_EOL;
    
    file_put_contents($log_file, $log_message, FILE_APPEND);
}
add_action('ocdi/before_content_import', 'log_demo_import_process');

/**
 * Log when the import is complete
 */
function log_demo_import_completion($selected_import) {
    error_log('CoreIT IMPORT COMPLETED: ' . $selected_import['import_file_name']);
    
    // Also log to custom file
    $log_file = WP_CONTENT_DIR . '/coreit-import-log.txt';
    $log_message = date('[Y-m-d H:i:s]') . ' Import completed: ' . $selected_import['import_file_name'] . PHP_EOL;
    
    file_put_contents($log_file, $log_message, FILE_APPEND);
}
add_action('ocdi/after_import', 'log_demo_import_completion');

/**
 * Disable OCDI branding and speed up import
 */
add_filter('ocdi/disable_pt_branding', '__return_true');
add_filter('ocdi/regenerate_thumbnails_in_content_import', '__return_false'); 
 
 
 
 /**
 * Admin page for manual cleanup
 */
add_action('coreit_cleanup_duplicates_page' , 'cleanup_duplicates_page');
function cleanup_duplicates_page() {
  
    
    ?>
    <div class="duplicatecleaner">
        <?php 
  // Check if cleanup action was requested
  if (isset($_POST['cleanup_duplicates']) && wp_verify_nonce($_POST['_wpnonce'], 'cleanup_duplicates_nonce')) {
    $results = cleanup_existing_duplicates();
    echo '<div class="resultcleanup"><p>Cleanup completed. ' . $results['count'] . ' post duplicates and ' . $results['media_count'] . ' media duplicates removed.</p></div>';
}

?>
        <h1>Post-Import Duplicate Cleanup</h1>
        <div class=" notice-warning" style="padding: 10px; margin: 10px 0;">
            <h3 style="margin-top: 0; color: #d63638;">⚠️ IMPORTANT: Use Only AFTER Import</h3>
            <p><strong>This tool should only be used AFTER your One-Click Demo Import is complete!</strong></p>
            <p>Running this before or during import may cause issues with your site content.</p>
        </div>
        
        <p>This tool will scan for and remove duplicate posts, pages, footers, headers, and other custom post types created during the import process.</p>
        
        <h3>What This Tool Will Do:</h3>
        <ol>
            <li>Find and remove duplicate <strong>posts</strong>, <strong>pages</strong>, <strong>service</strong>, <strong>portfolio</strong> items</li>
            <li>Find and remove duplicate <strong>headers</strong>, <strong>footers</strong>, and <strong>mega_menu</strong> items</li>
            <li>Find and remove duplicate <strong>coreitblocks</strong>, <strong>coreitsliders</strong>, and <strong>team</strong> items</li>
            <li>Find and remove duplicate <strong>media files</strong> (images) using both filename and content analysis</li>
        </ol>
        
        <h3>Recommended Steps:</h3>
        <ol>
            <li>Complete your One-Click Demo Import</li>
            <li>Make a backup of your site</li>
            <li>Run this cleanup tool</li>
            <li>Verify your site content</li>
        </ol>
        
        <form method="post">
            <?php wp_nonce_field('cleanup_duplicates_nonce'); ?>
          
                <input type="submit" name="cleanup_duplicates" class="button button-primary" value="Run Post-Import Cleanup">
           
        </form>
    </div>
    <?php
}

/**
 * Function to clean up existing duplicates
 */
function cleanup_existing_duplicates() {
    global $wpdb;
    $count = 0;
    $media_count = 0;
    
    // Post types to check
    $post_types = [
        'post', 'page', 'service', 'portfolio', 
        'coreitblocks', 'coreitsliders', 'team', 
        'header', 'footer', 'mega_menu'
    ];
    
    foreach ($post_types as $post_type) {
        // Get all posts of this type, ordered by ID (oldest first)
        $posts = get_posts([
            'post_type' => $post_type,
            'posts_per_page' => -1,
            'orderby' => 'ID',
            'order' => 'ASC',
        ]);
        
        $processed_titles = [];
        
        foreach ($posts as $post) {
            if (in_array($post->post_title, $processed_titles)) {
                // This is a duplicate, remove it
                wp_delete_post($post->ID, true);
                $count++;
            } else {
                // Add to processed titles
                $processed_titles[] = $post->post_title;
            }
        }
    }
    
    // Now clean up duplicate media files
    $media_count = cleanup_duplicate_media();
    
    return ['success' => true, 'count' => $count, 'media_count' => $media_count];
}

/**
 * Clean up duplicate media files
 */
function cleanup_duplicate_media() {
    global $wpdb;
    $count = 0;
    
    // Get all attachments
    $attachments = $wpdb->get_results(
        "SELECT ID, post_title, guid FROM {$wpdb->posts} 
         WHERE post_type = 'attachment' 
         ORDER BY ID ASC"
    );
    
    // Group by filename
    $file_groups = [];
    $processed_files = [];
    
    foreach ($attachments as $attachment) {
        $file_url = $attachment->guid;
        $filename = basename($file_url);
        
        if (!isset($file_groups[$filename])) {
            $file_groups[$filename] = [];
        }
        
        $file_groups[$filename][] = $attachment->ID;
    }
    
    // Find and remove duplicates
    foreach ($file_groups as $filename => $attachment_ids) {
        if (count($attachment_ids) > 1) {
            // Keep the first one, delete the rest
            $keep_id = array_shift($attachment_ids);
            
            foreach ($attachment_ids as $delete_id) {
                wp_delete_attachment($delete_id, true);
                $count++;
            }
        }
    }
    
    // Look for more duplicates by checking file hashes (for files with different names but same content)
    if (function_exists('md5_file')) {
        $hash_groups = [];
        $uploads_dir = wp_upload_dir();
        $base_dir = $uploads_dir['basedir'];
        
        $remaining_attachments = get_posts([
            'post_type' => 'attachment',
            'posts_per_page' => -1,
        ]);
        
        foreach ($remaining_attachments as $attachment) {
            $file_path = get_attached_file($attachment->ID);
            
            if (file_exists($file_path)) {
                $hash = md5_file($file_path);
                
                if (!isset($hash_groups[$hash])) {
                    $hash_groups[$hash] = [];
                }
                
                $hash_groups[$hash][] = $attachment->ID;
            }
        }
        
        // Remove duplicates with the same hash
        foreach ($hash_groups as $hash => $attachment_ids) {
            if (count($attachment_ids) > 1) {
                // Keep the first one, delete the rest
                $keep_id = array_shift($attachment_ids);
                
                foreach ($attachment_ids as $delete_id) {
                    wp_delete_attachment($delete_id, true);
                    $count++;
                }
            }
        }
    }
    
    return $count;
}

/**
 * AJAX handler for duplicate cleanup
 */
function coreit_cleanup_duplicates_ajax_handler() {
    // Verify nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'cleanup_duplicates_nonce')) {
        wp_send_json_error(array('message' => 'Nonce verification failed. Please refresh the page and try again.'));
    }

    // Check permissions
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
    }

    // Call the cleanup function
    $results = cleanup_existing_duplicates();

    // Return the results
    if ($results && isset($results['success']) && $results['success']) {
        wp_send_json_success(array(
            'count' => $results['count'],
            'media_count' => $results['media_count']
        ));
    } else {
        wp_send_json_error(array('message' => 'Error during cleanup process.'));
    }
}
add_action('wp_ajax_cleanup_duplicates_action', 'coreit_cleanup_duplicates_ajax_handler');

/**
 * CoreIT - OCDI Enhancement Implementation
 * Advanced UI Improvements for One Click Demo Import
 */

/**
 * Enqueue custom styles and scripts to enhance One Click Demo Import UI
 */
function coreit_enhance_ocdi_interface() {
    // Only run on OCDI pages
    $screen = get_current_screen();
    if (!$screen || (strpos($screen->base, 'one-click-demo-import') === false && 
                    !isset($_GET['page']) || $_GET['page'] !== 'one-click-demo-import')) {
        return;
    }
    
    // Enqueue the custom CSS
    wp_enqueue_style(
        'coreit-ocdi-enhanced',
        get_template_directory_uri() . '/includes/admin/dashboard/assets/css/ocdi-enhanced.css',
        array(),
        '1.0.2'
    );
    
    // Enqueue the custom JavaScript
    wp_enqueue_script(
        'coreit-ocdi-enhanced',
        get_template_directory_uri() . '/includes/admin/dashboard/assets/js/ocdi-enhanced.js',
        array('jquery'),
        '1.0.2',
        true
    );
    
    // Enqueue dashicons if not already loaded
    wp_enqueue_style('dashicons');
}
add_action('admin_enqueue_scripts', 'coreit_enhance_ocdi_interface', 20);

/**
 * Add dashboard link to all OCDI pages
 */
function coreit_add_dashboard_link() {
    $screen = get_current_screen();
    if (!$screen || (strpos($screen->base, 'one-click-demo-import') === false && 
                    !isset($_GET['page']) || $_GET['page'] !== 'one-click-demo-import')) {
        return;
    }
    
    echo '<a href="' . esc_url(admin_url('index.php')) . '" class="coreit-dashboard-link">' . 
         '<span class="dashicons dashicons-arrow-left-alt"></span> Back to Dashboard</a>';
}
add_action('admin_notices', 'coreit_add_dashboard_link');
 

/**
 * Modify import complete buttons
 */
/**
 * Add top navigation to OCDI pages
 */
function coreit_add_ocdi_top_navigation() {
    $screen = get_current_screen();
    if (!$screen || (strpos($screen->base, 'one-click-demo-import') === false && 
                    !isset($_GET['page']) || $_GET['page'] !== 'one-click-demo-import')) {
        return;
    }
    
    ?>
    <div class="ocdi-top-navigation">
        <a href="<?php echo esc_url(admin_url('admin.php?page=coreit&step=demo_import')); ?>" class="import-more-demos">
            Import More Demos
        </a>
        <a href="<?php echo esc_url(admin_url('index.php')); ?>" class="dashboard-link">
            <span class="dashicons dashicons-arrow-right-alt2"></span> Dashboard
        </a>
    </div>
    <?php
}
add_action('admin_notices', 'coreit_add_ocdi_top_navigation', 1);

/**
 * Modify import buttons
 */
function coreit_modify_import_buttons($buttons) {
    $modified_buttons = array(
        array(
            'title' => 'Theme Settings',
            'url'   => admin_url('customize.php'),
            'class' => 'button button-primary',
        ),
        array(
            'title' => 'Visit Site',
            'url'   => home_url(),
            'class' => 'button button-secondary',
        ),
        array(
            'title' => 'Import More Demos',
            'url'   => admin_url('admin.php?page=coreit&step=demo_import'),
            'class' => 'button button-secondary',
        ),
        array(
            'title' => 'Go to Dashboard',
            'url'   => admin_url('index.php'),
            'class' => 'button button-secondary',
        )
    );
    
    return $modified_buttons;
}
add_filter('ocdi/import_done_buttons', 'coreit_modify_import_buttons');

/**
 * Remove admin notices on OCDI pages
 */
function coreit_remove_ocdi_notices() {
    $screen = get_current_screen();
    if (!$screen || (strpos($screen->base, 'one-click-demo-import') === false && 
                    !isset($_GET['page']) || $_GET['page'] !== 'one-click-demo-import')) {
        return;
    }
    
    remove_all_actions('admin_notices');
    remove_all_actions('all_admin_notices');
}
add_action('admin_head', 'coreit_remove_ocdi_notices', 1);