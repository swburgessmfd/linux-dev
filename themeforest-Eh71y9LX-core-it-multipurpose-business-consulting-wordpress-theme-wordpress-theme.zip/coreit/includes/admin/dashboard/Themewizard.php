<?php
/**
 * Theme Setup Wizard with Integrated Plugin Installation and Demo Import
 * This file handles the theme setup wizard functionality with inline plugin installation
 * and demo content import without redirecting to separate pages
 * Place this file in your theme's includes/main/Demo/ directory
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Include dependencies
require_once get_template_directory() . '/includes/admin/dashboard/Capability.php'; 
 
/**
 * Theme Setup Wizard Class
 */
class Integrated_Theme_Setup_Wizard {
    /**
     * Current step
     */
    private $step = '';
    
    /**
     * Steps for the setup wizard
     */
    private $steps = array();
    
    /**
     * Theme name
     */
    private $theme_name = '';
    
    /**
     * Theme slug
     */
    private $theme_slug = '';
     
    /**
     * Required plugins
     */
    private $required_plugins = array();
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->theme_name = wp_get_theme()->get('Name');
        $this->theme_slug = wp_get_theme()->get_stylesheet();
        
        // Define the wizard steps
        $this->steps = array(
            'welcome'     => array(
                'name'    => __('Welcome', 'coreit'),
                'view'    => array($this, 'welcome_step'),
                'handler' => '',
            ),
            'child_theme' => array(
                'name' => __('Child Theme', 'coreit'),
                'view' => array($this, 'child_theme_step'),
                'handler' => array($this, 'process_child_theme_step'),
            ),
            'plugins'     => array(
                'name'    => __('Plugins', 'coreit'),
                'view'    => array($this, 'plugins_step'),
                'handler' => '',
            ), 
            'demo_import' => array(
                'name'    => __('Demo Import', 'coreit'), 
                'view'    => array($this, 'demo_import_step'), 
                'handler' => '',
            ),
            'done'        => array(
                'name'    => __('Done', 'coreit'),
                'view'    => array($this, 'done_step'),
                'handler' => '',
            ),
        );
         
        // Get required plugins
        $this->get_required_plugins();
        
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Add admin scripts
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // AJAX handlers
        add_action('wp_ajax_install_child_theme', array($this, 'ajax_install_child_theme'));
        add_action('wp_ajax_activate_child_theme', array($this, 'ajax_activate_child_theme'));
        add_action('wp_ajax_install_plugin', array($this, 'ajax_install_plugin'));
        add_action('wp_ajax_activate_plugin', array($this, 'ajax_activate_plugin')); 
        add_action('wp_ajax_deactivate_plugin', array($this, 'ajax_deactivate_plugin')); // Add this line
        // Additional actions from Theme_Admin_Panel
        add_action("admin_init", [$this, "register_settings"]);
        add_action("admin_notices", [$this, "display_admin_notice"]); 
 
        add_action("admin_notices", [$this, "display_header_admin_notice"], 110);
        // Add styles and scripts for the admin panel
        add_action("admin_enqueue_scripts", [$this, "coreit_admin_scripts"]);
         
        // Check current step
        if (isset($_GET['step'])) {
            $this->step = sanitize_key($_GET['step']);
        } else {
            $this->step = array_keys($this->steps)[0];
        }
        
        // Handle form submissions
        if (!empty($_POST) && isset($_POST['wizard_nonce'])) {
            check_admin_referer('wizard_nonce', 'wizard_nonce');
            
            if (isset($_POST['save_step']) && isset($this->steps[$this->step]['handler'])) {
                call_user_func($this->steps[$this->step]['handler']);
            }
            
            wp_redirect(esc_url_raw($this->get_next_step_link()));
            exit;
        }
    }
 
 
/**
 * Helper method to output the wizard steps HTML
 * This is used by multiple hooks
 */
private function output_wizard_steps_html() {
    // Output the wizard steps HTML
    echo '<div class="theme-setup-wizard ocdi-wizard-steps">';
    echo '<header class="wizard-header">';
    echo '<h1>' . sprintf(__('%s Setup', 'coreit'), $this->theme_name) . '</h1>';
    echo '</header>';
    
    // Output the wizard steps
    echo '<ul class="wizard-steps">';
    $current_step = 'demo_import'; // Set current step to demo_import
    
    foreach ($this->steps as $step_key => $step) {
        $class = '';
        
        if ($step_key === $current_step) {
            $class = 'active';
        } elseif ($this->is_step_completed($step_key)) {
            $class = 'done';
        }
        
        echo '<li class="' . esc_attr($class) . '">';
        echo esc_html($step['name']);
        echo '</li>';
    }
    
    echo '</ul>';
    echo '</div>';
}
    /**
     * Get required plugins from the existing TGMPA configuration
     */
    private function get_required_plugins() {
        // Extract plugins from your existing code
        $this->required_plugins = array(
            array(
                'name'     => 'Elementor',
                'slug'     => 'elementor',
                'source'   => '',
             'required' => true,
            ),
            array(
                'name'     => 'One Click Demo Import',
                'slug'     => 'one-click-demo-import',
                'source'   => '',
                'required' => true,
            ),
            array(
                'name'     => 'WooCommerce',
                'slug'     => 'woocommerce',
                'source'   => '',
                'required' => false,
            ),
            array(
                'name'     => 'Contact Form 7',
                'slug'     => 'contact-form-7',
                'source'   => '',
                'required' => true,
            ),
            array(
                'name'     => 'CoreIt Addons',
                'slug'     => 'coreit-addons',
                'source'   => get_template_directory() . '/includes/admin/dashboard/pluigns/files/coreit-addons.zip',
                'required' => true,
            ),
            array(
                'name'     => 'The MailChimp for WordPress',
                'slug'     => 'mailchimp-for-wp',
                'source'   => '',
                'required' => false,
            ),
            array(
                'name'     => 'Amelia Appointment Booking',
                'slug'     => 'ameliabooking',
                'source'   => '',
                'required' => false,
            ),
            array(
                'name'     => 'Translate WordPress with GTranslate',
                'slug'     => 'gtranslate',
                'source'   => '',
                'required' => false,
            ),
            array(
                'name'     => 'WP Job Manager',
                'slug'     => 'wp-job-manager',
                'source'   => '',
                'required' => false,
            ),
            array(
                'name'     => 'CoreIt Template Importer',
                'slug'     => 'coreit-template-importer',
                'source'   => get_template_directory() . '/includes/admin/dashboard/pluigns/files/coreit-template-importer.zip',
                'required' => false,
            ),
        );
    }
    
    /**
     * Add admin menu
     * This combines both the original menu function and Theme_Admin_Panel's function
     */
    public function add_admin_menu() {
        // Add a top-level menu item with a specific position
        add_menu_page(
            "CoreIT", // Page title
            "CoreIT", // Menu title
            "manage_options", // Capability required to access the menu item
            "coreit", // Menu slug
            [$this, "setup_wizard"], // Callback function to render the page
            "dashicons-admin-settings", // Icon for the menu item
            2
        );
        
        // Add subpages
        add_submenu_page(
            "coreit",
            "Theme Setup / Import",
            "Theme Setup / Import ",
            "manage_options",
            "coreit",
            [$this, "setup_wizard"],
            0
        );
        
        // Coreit Imported
        if (class_exists("Coreit_importer") && class_exists("Coreit_importer")) {
            add_submenu_page(
                'coreit', // Parent menu slug
                'Template Importer', // Page title
                'Template Importer', // Menu title
                'manage_options', // Capability required to access the submenu item
                'elementor-template-importer', // Menu slug
                'elementor_template_importer_page', // Callback function to render the page 
            );
        } 
        
        // Add theme options submenu under coreit
        add_submenu_page(
            "coreit",
            "Theme Options", // Page title
            "Theme Options", // Submenu title
            "manage_options", // Capability required to access the submenu item
            "customize.php", // Link to the customizer
            null // No callback function needed as it links to the customizer directly
        );
        
    }
    
   
/**
 * Enqueue additional scripts and styles
 * Add this to the enqueue_scripts method
 */
public function enqueue_scripts() {
    $screen = get_current_screen();

    // Check for CoreIT related admin pages
    if (isset($_GET['page']) && ($_GET['page'] === 'coreit' || $_GET['page'] === 'one-click-demo-import')) {
        // Enqueue modern dashboard styles
        wp_enqueue_style('coreit-modern-dashboard', get_template_directory_uri() . '/includes/admin/dashboard/assets/css/modern-dashboard.css', array(), '2.0.0');
        
        // Enqueue ONLY modern dashboard script - removing wizard.js reference
        wp_enqueue_script('coreit-modern-dashboard', get_template_directory_uri() . '/includes/admin/dashboard/assets/js/modern-dashboard.js', array('jquery'), '2.0.0', true);
        
        // Localize script with combined data from both previous localizations
        wp_localize_script('coreit-modern-dashboard', 'theme_setup_wizard', array(
            'ajaxurl'       => admin_url('admin-ajax.php'),
            'nonce'         => wp_create_nonce('theme_setup_wizard'),
            'admin_url'     => admin_url('admin.php?page=coreit'),
            'plugin_texts'  => array(
                'installing'        => __('Installing...', 'coreit'),
                'installed'         => __('Installed', 'coreit'),
                'install_failed'    => __('Installation Failed', 'coreit'),
                'activating'        => __('Activating...', 'coreit'),
                'activated'         => __('Activated', 'coreit'),
                'activation_failed' => __('Activation Failed', 'coreit'),
                'deactivating'      => __('Deactivating...', 'coreit'),
                'deactivated'       => __('Deactivated', 'coreit'),
                'deactivation_failed' => __('Deactivation Failed', 'coreit'),
            ),
            'texts' => array(
                'installing' => __('Installing...', 'coreit'),
                'installed' => __('Installed', 'coreit'),
                'error' => __('Error', 'coreit'),
            )
        ));
        
        // Add server check localization to the same script
        wp_localize_script('coreit-modern-dashboard', 'coreit_server_check', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('refresh_server_check_nonce'),
            'refreshing_text' => __('Refreshing...', 'coreit')
        ));
    }
}

    
    /**
     * Additional admin panel scripts from Theme_Admin_Panel
     */
    public function coreit_admin_scripts() { 
        wp_enqueue_style('coreit-meta-box', get_template_directory_uri().'/includes/admin/dashboard/assets/css/admin.css' ); 
        wp_enqueue_style('coreit-uione', get_template_directory_uri().'/assets/css/scss/icons/all-icons.css' );   
        wp_enqueue_style('coreit-uitwo', get_template_directory_uri().'/assets/css/plugins/icons.css' );       
        wp_enqueue_script("coreit-admin-select", get_template_directory_uri() . "/includes/admin/dashboard/assets/js/select2.min.js", ["jquery"], "1.0", true);
        wp_enqueue_script("coreit-admin", get_template_directory_uri() . "/includes/admin/dashboard/assets/js/admin.js", ["jquery"], "1.0", true);
    }
    
    /**
     * Register theme settings from Theme_Admin_Panel
     */
    public function register_settings() {
        // Register any settings you need for your theme options
    }
    
    
    
    /**
     * Display admin notice from Theme_Admin_Panel
     */
    public function display_admin_notice() { 
        $admin_notice_enable = function_exists('coreit_get_option') ? coreit_get_option('admin_notice', true) : true; 
        $admin_dashboard_url = admin_url('admin.php?page=coreit'); 
        ?>
       <div class="admin-notice admin-notice-coreitss notice notice-info is-dismissible <?php if($admin_notice_enable == false): ?> disable_copt_notice <?php endif; ?>">
        <ul> 
            <li><?php echo esc_html('Before Import Demo Content Check the server configuration here', 'coreit'); ?> <a target="_blank" href="<?php echo esc_url($admin_dashboard_url);?>"><?php echo esc_html('Click here...', 'coreit'); ?></a></li>
            <li><?php echo esc_html('We are here to help you.For any issues please submit your ticket here', 'coreit'); ?> <a target="_blank" href="https://steelthemes.ticksy.com/submit/#100023380"><?php echo esc_html('Get Support', 'coreit'); ?></a></li>
            <li><?php echo esc_html('Looking for coreit Documentation', 'coreit'); ?> <a target="_blank" href="https://coreit.themepanthers.com/documentation/"><?php echo esc_html('Click here', 'coreit'); ?></a></li>
            </ul>
            <p>To disable this notice go to CreIt ▸ Theme Options  ▸ CoreIT Header / Footer Settings ▸  Admin Notice</p>
          </div> 
       <?php
    }
    
    /**
     * Display header admin notice from Theme_Admin_Panel
     */
    public function display_header_admin_notice() {
        $screen = get_current_screen();
        if (class_exists("Coreit_Addons")) {
            // Check if the current screen is the header post type edit screen
            if ($screen && $screen->post_type === "header") {
                $this->add_single_tabs("header");
            }
            // Check if the current screen is the footer post type edit screen
            if ($screen && $screen->post_type === "footer") {
                $this->add_single_tabs("footer");
            }
            // Check if the current screen is the mega_menu post type edit screen
            if ($screen && $screen->post_type === "mega_menu") {
                $this->add_single_tabs("megamenu");
            }
            // Check if the current screen is the theme otpion post type edit screen
            if (
                isset($_GET["page"]) &&
                $_GET["page"] === "coreit-theme-options"
            ) {
                $this->add_single_tabs("themeoptions");
            }
        }
        if (class_exists("Coreit_importer")) {
            // Check if the current screen is the theme otpion post type edit screen
              if (isset($_GET["page"]) && $_GET["page"] === "elementor-template-importer") {
                  $this->add_single_tabs("elementortemplateimporter");
              }
          }
        if ($screen && $screen->base === "nav-menus") {
            $this->add_single_tabs("menus");
        }
        if ($screen && $screen->base === "widgets") {
            $this->add_single_tabs("widgets"); 
        }
        if ($screen->id === 'appearance_page_install-required-plugins') {
            $this->add_single_tabs("plugin");
        }
        if (class_exists("OCDI_Plugin")) {
            // Check if the current screen is the one click post type edit screen
            if (
                isset($_GET["page"]) &&
                $_GET["page"] === "one-click-demo-import"
            ) {
                $this->add_single_tabs("oneclick");
            }
        }
    }
    
    /**
     * Add single tabs from Theme_Admin_Panel
     */
    public function add_single_tabs($tab_activate) {
        $navtabs["main"] = [
            "title" => esc_html__("Theme Setup", "coreit"),
            "link" => "admin.php?page=coreit",
        ];
        $navtabs["plugin"] = [
            "title" => esc_html__("Install Plugins", "coreit"),
            "link" => "themes.php?page=install-required-plugins",
        ];
        if (class_exists("OCDI_Plugin")) {
            $navtabs["oneclick"] = [
                "title" => esc_html__("Import Demo Content", "coreit"),
                "link" => "themes.php?page=one-click-demo-import",
            ];
        }
        $navtabs["menus"] = [
            "title" => esc_html__("Menu", "coreit"),
            "link" => "nav-menus.php",
        ];
        $navtabs["widgets"] = [
            "title" => esc_html__("Widgets", "coreit"),
            "link" => "widgets.php",
        ];
        if (class_exists("Coreit_Addons")) {
            $navtabs["header"] = [
                "title" => esc_html__("Create Header", "coreit"),
                "link" => "edit.php?post_type=header",
            ];
            $navtabs["footer"] = [
                "title" => esc_html__("Create Footer", "coreit"),
                "link" => "edit.php?post_type=footer",
            ];
            $navtabs["megamenu"] = [
                "title" => esc_html__("Create Megamenu", "coreit"),
                "link" => "edit.php?post_type=mega_menu",
            ];
            $navtabs["themeoptions"] = [
                "title" => esc_html__("Theme Options", "coreit"),
                "link" => "customize.php",
            ];
        } 
        ?>
            <div class="nav-tab-wrapper admin_dashboad">
            <?php foreach ($navtabs as $key => $tab) {
                    if ($tab_activate == $key){ ?>
                    <span class="nav-tab nav-tab-active"><?php echo sprintf(__("%s", "coreit"), $tab["title"]); ?></span>
                   <?php }else{ ?>
                    <a href="<?php echo esc_url($tab["link"]); ?>" class="nav-tab"><?php echo sprintf(__("%s", "coreit"), $tab["title"]); ?></a>
                    <?php
                    }
                } ?>
            </div>
        <?php
    }
    
    /**
     * Get the next step link
     */
    public function get_next_step_link() {
        $keys = array_keys($this->steps);
        $current_step_index = array_search($this->step, $keys);
        
        if ($current_step_index < count($keys) - 1) {
            $next_step = $keys[$current_step_index + 1];
            return add_query_arg('step', $next_step, admin_url('admin.php?page=coreit'));
        }
        
        return admin_url();
    }
    
    /**
     * Get the previous step link
     */
    public function get_prev_step_link() {
        $keys = array_keys($this->steps);
        $current_step_index = array_search($this->step, $keys);
        
        if ($current_step_index > 0) {
            $prev_step = $keys[$current_step_index - 1];
            return add_query_arg('step', $prev_step, admin_url('admin.php?page=coreit'));
        }
        
        return admin_url();
    }
    
    /**
     * Setup wizard page
     */
    public function setup_wizard() {
        $this->setup_wizard_header();
        $this->setup_wizard_steps();
        $this->setup_wizard_content();
        $this->setup_wizard_footer();
    }
    
   
/**
 * Add header enhancements for the theme setup wizard
 * Add this to the setup_wizard_header method
 */
public function setup_wizard_header() {
    ?>
    <!DOCTYPE html>
    <html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php printf(__('%s &rsaquo; Setup Wizard', 'coreit'), $this->theme_name); ?></title>
        <?php wp_print_styles(); ?>
        <?php do_action('admin_print_styles'); ?>
        <?php do_action('admin_head'); ?>
    </head>
    <body class="theme-setup-wizard-body">
        <div class="theme-setup-wizard">
            <header class="wizard-header">
                <div class="wizard-header-logo">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/includes/admin/dashboard/assets/img/steellogo.png'); ?>" alt="<?php echo esc_attr($this->theme_name); ?> Logo">
                    <h1><?php printf(__('%s Setup', 'coreit'), $this->theme_name); ?></h1>
                </div>
                <div class="wizard-header-actions">
                    
                        <a href="<?php echo esc_url(admin_url('index.php')); ?>" class="button button-secondary">
                            <span class="dashicons dashicons-dashboard"></span> Dashboard
                        </a>
                  
                </div>
            </header>
    <?php
}
    /**
     * Setup wizard steps
     */
    public function setup_wizard_steps() {
        $current_step = $this->step;
        
        ?>
        <ul class="wizard-steps">
            <?php foreach ($this->steps as $step_key => $step) : ?>
                <li class="<?php echo $step_key === $current_step ? 'active' : ($this->is_step_completed($step_key) ? 'done' : ''); ?>">
                    <?php echo esc_html($step['name']); ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php
    }
    
    /**
     * Check if step is completed
     */
    private function is_step_completed($step) {
        $keys = array_keys($this->steps);
        $current_step_index = array_search($this->step, $keys);
        $step_index = array_search($step, $keys);
        
        return $step_index < $current_step_index;
    }
    
    /**
     * Setup wizard content
     */
    public function setup_wizard_content() {
        echo '<div class="wizard-content">';
        
        if (!empty($this->steps[$this->step]['view'])) {
            call_user_func($this->steps[$this->step]['view']);
        }
        
        echo '</div>';
    }
    
    /**
     * Setup wizard footer
     */
    public function setup_wizard_footer() {
        ?>
                <footer class="wizard-footer">
                    <div class="wizard-footer-links">
                        <?php if ($this->step !== array_keys($this->steps)[0]) : ?>
                            <a class="button button-secondary" href="<?php echo esc_url($this->get_prev_step_link()); ?>"><?php _e('Back', 'coreit'); ?></a>
                        <?php endif; ?>
                        
                        <?php if ($this->step !== array_keys($this->steps)[count($this->steps) - 1]) : ?>
                            <a class="button button-primary next-step" href="<?php echo esc_url($this->get_next_step_link()); ?>"><?php _e('Next', 'coreit'); ?></a>
                        <?php endif; ?>
                    </div>
                </footer>
            </div>
            <?php wp_print_scripts(); ?>
            <?php do_action('admin_print_scripts'); ?>
            <?php do_action('admin_footer'); ?>
        </body>
        </html>
        <?php
        exit;
    }
    
   /**
 * Enhanced welcome step with better UI
 * Replace the existing welcome_step method
 */
public function welcome_step() {
    ?>
    <div class="wizard-step-content welcome_content">
        <div class="welcomeblocks">
            <h2><?php printf(__('Welcome to %s Setup Wizard', 'coreit'), $this->theme_name); ?></h2>
            <p><?php _e('Thank you for choosing our theme. This wizard will help you set up your website quickly and easily.', 'coreit'); ?></p>
            <p><?php _e('This wizard will guide you through:', 'coreit'); ?></p>
            <ol>
                <li><?php _e('Installing and activating essential plugins', 'coreit'); ?></li>
                <li><?php _e('Creating a child theme (optional but recommended)', 'coreit'); ?></li>
                <li><?php _e('Importing demo content to match our theme demos', 'coreit'); ?></li>
            </ol>
        </div>
        
        <p><?php _e('The setup should only take a few minutes to complete.', 'coreit'); ?></p>
        
        <div class="notice notice-info">
            <p><?php _e('Using a child theme is recommended if you plan to customize your site. Demo content import is optional and can be skipped if you prefer to start with a blank site.', 'coreit'); ?></p>
        </div>
        
        <?php 
        // Display server capability check
        Theme_Server_Capability_Check::display_server_capability_check();
        ?>
        
        <div class="wizard-action-buttons">
            <a class="button button-primary button-hero" href="<?php echo esc_url($this->get_next_step_link()); ?>">
                <?php _e('Let\'s Get Started', 'coreit'); ?>
                <span class="dashicons dashicons-arrow-right-alt"></span>
            </a>
        </div>
    </div>
    <?php
}
    
    /**
     * Improved child theme step with better detection of existing active child theme
     */
    public function child_theme_step() {
        // Get current active theme
        $current_theme = wp_get_theme();
        $parent_theme = $current_theme->parent() ? $current_theme->parent() : $current_theme;
        
        // Get theme info
        $parent_theme_name = $parent_theme->get('Name');
        $parent_theme_slug = $parent_theme->get_stylesheet();
        
        // Check for any child theme of this parent
        $is_child_theme = ($current_theme->parent() && $current_theme->parent()->get_stylesheet() === $parent_theme_slug);
        
        // Alternative detection specifically for a theme named with "-child" suffix
        $child_theme_slug = $parent_theme_slug . '-child';
        $specific_child_theme = wp_get_theme($child_theme_slug);
        $specific_child_exists = $specific_child_theme->exists();
        $specific_child_active = ($current_theme->get_stylesheet() === $child_theme_slug);
        
        // Check both detection methods - either we're on ANY child theme of this parent, or specifically on the "-child" named version
        $is_on_child_theme = $is_child_theme || $specific_child_active;
        
        ?>
        <div class="wizard-step-content">
            <h2><?php esc_html_e('Child Theme Setup', 'coreit'); ?></h2>
            <p><?php esc_html_e('A child theme allows you to make customizations without losing your changes when updating the parent theme.', 'coreit'); ?></p>
            
            <?php if ($is_on_child_theme): ?>
                <div class="notice notice-success">
                    <p><?php esc_html_e('You are already using a child theme.', 'coreit'); ?></p>
                    <p><strong><?php esc_html_e('Active theme:', 'coreit'); ?></strong> <?php echo esc_html($current_theme->get('Name')); ?></p>
                    <p><strong><?php esc_html_e('Parent theme:', 'coreit'); ?></strong> <?php echo esc_html($parent_theme->get('Name')); ?></p>
                </div>
            <?php elseif ($specific_child_exists): ?>
                <div class="notice notice-info">
                    <p><?php esc_html_e('Child theme is installed but not active.', 'coreit'); ?></p>
                    <p><strong><?php esc_html_e('Theme name:', 'coreit'); ?></strong> <?php echo esc_html($specific_child_theme->get('Name')); ?></p>
                    <button type="button" class="button button-primary activate-child-theme" data-theme="<?php echo esc_attr($child_theme_slug); ?>">
                        <?php esc_html_e('Activate Child Theme', 'coreit'); ?>
                    </button>
                </div>
            <?php else: ?>
                <div class="child-theme-option">
                    <label>
                        <input type="checkbox" name="install_child_theme" value="1" checked>
                        <?php esc_html_e('Install and activate a child theme', 'coreit'); ?>
                    </label>
                    <div class="child-theme-details">
                        <p><?php esc_html_e('Child theme name:', 'coreit'); ?> <strong><?php echo esc_html($parent_theme_name); ?> Child</strong></p>
                        <div id="child_theme_status"></div>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="child-theme-info">
                <h3><?php esc_html_e('Why use a child theme?', 'coreit'); ?></h3>
                <ul>
                    <li><?php esc_html_e('Preserves your customizations during theme updates', 'coreit'); ?></li>
                    <li><?php esc_html_e('Makes your site more maintainable', 'coreit'); ?></li>
                    <li><?php esc_html_e('Allows for safer customization of theme files', 'coreit'); ?></li>
                </ul>
            </div>
        </div>
        <?php
    }

    /**
     * Process child theme step
     */
    public function process_child_theme_step() {
        if (isset($_POST['install_child_theme']) && $_POST['install_child_theme'] === '1') {
            if (!$this->check_child_theme_exists()) {
                $this->create_child_theme();
            }
        }
        return true;
    }
    
    /**
     * Enhanced check if child theme exists and is active
     * This method is more robust in detecting child themes
     */
    private function check_child_theme_exists() {
        // Get current active theme
        $current_theme = wp_get_theme();
        $parent_theme = $current_theme->parent() ? $current_theme->parent() : $current_theme;
        $parent_theme_slug = $parent_theme->get_stylesheet();
        
        // Check if current theme is ANY child theme of this parent
        if ($current_theme->parent() && $current_theme->parent()->get_stylesheet() === $parent_theme_slug) {
            return true;
        }
        
        // Check for specific named child theme
        $child_theme_slug = $parent_theme_slug . '-child';
        
        // If current theme is the specific named child theme
        if ($current_theme->get_stylesheet() === $child_theme_slug) {
            return true;
        }
        
        // Check if specific named child theme exists but isn't active
        $child_theme = wp_get_theme($child_theme_slug);
        return $child_theme->exists();
    }
    
    /**
     * Create and activate child theme
     */
    private function create_child_theme() {
        $parent_theme = wp_get_theme();
        $parent_theme_name = $parent_theme->get('Name');
        $parent_theme_slug = $parent_theme->get_stylesheet();
        $child_theme_slug = $parent_theme_slug . '-child';
        
        $child_theme_path = WP_CONTENT_DIR . '/themes/' . $child_theme_slug;
        
        // Create child theme directory
        if (!file_exists($child_theme_path)) {
            wp_mkdir_p($child_theme_path);
        }

        // Create style.css
        $style_css = "/*
Theme Name: {$parent_theme_name} Child
Theme URI: 
Description: A child theme of {$parent_theme_name}
Author: 
Author URI: 
Template: {$parent_theme_slug}
Version: 1.0.0
Text Domain: {$parent_theme_slug}-child
*/

/* Add your custom styles below this line */
";
        file_put_contents($child_theme_path . '/style.css', $style_css);

        // Create functions.php
        $functions_php = "<?php
/**
 * {$parent_theme_name} Child Theme functions and definitions
 */

function {$parent_theme_slug}_child_enqueue_styles() {
    wp_enqueue_style( '{$parent_theme_slug}-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( '{$parent_theme_slug}-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( '{$parent_theme_slug}-style' ),
        wp_get_theme()->get('Version')
    );
}
add_action( 'wp_enqueue_scripts', '{$parent_theme_slug}_child_enqueue_styles' );

// Add custom functions below this line
";
        file_put_contents($child_theme_path . '/functions.php', $functions_php);

        // Create screenshot.png
        $parent_screenshot = get_template_directory() . '/screenshot.jpg';  // Try jpg first
        if (!file_exists($parent_screenshot)) {
            $parent_screenshot = get_template_directory() . '/screenshot.png';  // Try png if jpg doesn't exist
        }
        
        if (file_exists($parent_screenshot)) {
            copy($parent_screenshot, $child_theme_path . '/' . basename($parent_screenshot));
        }

        // Activate child theme
        $child_theme = wp_get_theme($child_theme_slug);
        if ($child_theme->exists()) {
            switch_theme($child_theme->get_stylesheet());
            return true;
        }
        
        throw new Exception(__('Child theme created but could not be activated.', 'coreit'));
    }
    
    /**
     * AJAX handler for installing child theme
     */
    public function ajax_install_child_theme() {
        check_ajax_referer('theme_setup_wizard', 'nonce');
        
        if (!current_user_can('install_themes')) {
            wp_send_json_error(array('message' => __('You do not have permission to install themes.', 'coreit')));
        }

        try {
            $this->create_child_theme();
            wp_send_json_success(array('message' => __('Child theme installed and activated successfully.', 'coreit')));
        } catch (Exception $e) {
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }
    
    /**
     * AJAX handler for activating existing child theme
     */
    public function ajax_activate_child_theme() {
        check_ajax_referer('theme_setup_wizard', 'nonce');
        
        if (!current_user_can('switch_themes')) {
            wp_send_json_error(array('message' => __('You do not have permission to switch themes.', 'coreit')));
        }
        
        $theme_slug = isset($_POST['theme']) ? sanitize_text_field($_POST['theme']) : '';
        
        if (empty($theme_slug)) {
            wp_send_json_error(array('message' => __('Theme slug is required.', 'coreit')));
        }
        
        // Check if theme exists
        $theme = wp_get_theme($theme_slug);
        if (!$theme->exists()) {
            wp_send_json_error(array('message' => __('Theme does not exist.', 'coreit')));
        }
        
        // Activate the theme
        switch_theme($theme_slug);
        
        // Check if activation was successful
        $active_theme = wp_get_theme();
        if ($active_theme->get_stylesheet() === $theme_slug) {
            wp_send_json_success(array('message' => __('Child theme activated successfully.', 'coreit')));
        } else {
            wp_send_json_error(array('message' => __('Failed to activate child theme.', 'coreit')));
        }
    }
    
  /**
 * Update plugins_step method to show deactivate option for active plugins
 * Replace or modify your existing plugins_step method
 */
public function plugins_step() {
    ?>
    <div class="wizard-step-content plugins-page">
        <h2><?php _e('Manage Plugins', 'coreit'); ?></h2>
        <p><?php _e('Install, activate, or deactivate plugins for your website.', 'coreit'); ?></p>
        
        <div class="plugin-installation">
            <table class="plugin-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="select-all-plugins"></th>
                        <th><?php _e('Plugin', 'coreit'); ?></th>
                        <th><?php _e('Status', 'coreit'); ?></th>
                        <th><?php _e('Action', 'coreit'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($this->required_plugins as $plugin) : 
                        $plugin_path = $this->get_plugin_path($plugin['slug']);
                        $is_installed = file_exists(WP_PLUGIN_DIR . '/' . $plugin_path);
                        $is_active = is_plugin_active($plugin_path);
                        $plugin_status = 'not-installed';
                        
                        if ($is_installed) {
                            $plugin_status = $is_active ? 'active' : 'inactive';
                        }
                        
                        $button_text = '';
                        $button_class = '';
                        $button_action = '';
                        
                        if ($plugin_status === 'not-installed') {
                            $button_text = __('Install', 'coreit');
                            $button_class = 'install-plugin';
                            $button_action = 'install';
                        } elseif ($plugin_status === 'inactive') {
                            $button_text = __('Activate', 'coreit');
                            $button_class = 'activate-plugin';
                            $button_action = 'activate';
                        } else {
                            // For active plugins, show deactivate button (unless required)
                            if ($plugin['required']) {
                                $button_text = __('Active (Required)', 'coreit');
                                $button_class = 'button-disabled';
                                $button_action = '';
                            } else {
                                $button_text = __('Deactivate', 'coreit');
                                $button_class = 'deactivate-plugin';
                                $button_action = 'deactivate';
                            }
                        }
                    ?>
                        <tr data-plugin-slug="<?php echo esc_attr($plugin['slug']); ?>" 
                            data-plugin-source="<?php echo esc_attr($plugin['source']); ?>" 
                            data-plugin-path="<?php echo esc_attr($plugin_path); ?>">
                            <td>
                                <input type="checkbox" 
                                       class="plugin-checkbox" 
                                       <?php echo $plugin['required'] ? 'checked disabled' : ''; ?> 
                                       data-required="<?php echo $plugin['required'] ? '1' : '0'; ?>">
                            </td>
                            <td>
                                <strong><?php echo esc_html($plugin['name']); ?></strong>
                                <?php if ($plugin['required']) : ?>
                                    <span class="required-label"><?php _e('(Required)', 'coreit'); ?></span>
                                <?php else : ?>
                                    <span class="recommended-label"><?php _e('(Recommended)', 'coreit'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="plugin-status <?php echo esc_attr($plugin_status); ?>">
                                <?php 
                                if ($plugin_status === 'active') {
                                    _e('Active', 'coreit');
                                } elseif ($plugin_status === 'inactive') {
                                    _e('Installed', 'coreit');
                                } else {
                                    _e('Not Installed', 'coreit');
                                }
                                ?>
                            </td>
                            <td>
                                <?php if ($button_class !== 'button-disabled') : ?>
                                    <button 
                                        class="button <?php echo esc_attr($button_class); ?>" 
                                        data-action="<?php echo esc_attr($button_action); ?>">
                                        <?php echo esc_html($button_text); ?>
                                    </button>
                                <?php else : ?>
                                    <span class="plugin-status-text"><?php echo esc_html($button_text); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="plugin-installation-status">
                <p class="plugin-installation-progress"></p>
            </div>
            
            <div class="plugin-installation-actions">
                <button class="button button-primary install-selected-plugins"><?php _e('Install & Activate Selected', 'coreit'); ?></button>
                <button class="button button-secondary deactivate-selected-plugins"><?php _e('Deactivate Selected', 'coreit'); ?></button>
            </div>
        </div>
    </div>
    <?php
}
    
   
  
/**
 * Enhanced demo import step method with modern UI
 * Replace the existing demo_import_step method
 */
public function demo_import_step() {
    // Define available demo imports based on the OCDI import files
    $demos = array( 
        array(
            'id' => 0,
            'name' => 'CoreIT Demo Import V1',
            'description' => __('Home Page 1 to 8 and all the inner pages', 'coreit'),
            'screenshot' => get_template_directory_uri() . '/screenshot.jpg',
            'preview_url' => 'https://coreit.themepanthers.com/demo',  
            'import_file' => get_parent_theme_file_path('/includes/admin/dashboard/demos/v1/content.xml'),
        ),
        array(
            'id' => 1,
            'name' => 'CoreIT Demo Import V2',
            'description'   => __('Home Page 9 to 16 Pages', 'coreit'), 
            'screenshot' => get_template_directory_uri() . '/includes/admin/dashboard/demos/v2/demo-2.jpg',
            'preview_url' => 'https://coreit.themepanthers.com/demo',   
        ), 
        array(
            'id' => 2,
            'name' => 'CoreIT Demo Import V3',
            'description'   => __('Home Page 17 and 18 Page', 'coreit'), 
            'screenshot' => get_template_directory_uri() . '/includes/admin/dashboard/demos/v3/demo-3.jpg',
            'preview_url' => 'https://coreit.themepanthers.com/demo',   
        ), 
    );
    ?>
    <div class="wizard-step-content">
        <h2><?php _e('Demo Content Import', 'coreit'); ?></h2>
        <p><?php _e('Choose a demo layout to quickly set up your website with pre-designed content.', 'coreit'); ?></p> 
        
        <div class="demo-import-section">
            <?php 
            // Check if One Click Demo Import plugin is installed and active
            $ocdi_plugin_path = 'one-click-demo-import/one-click-demo-import.php';
            $is_ocdi_active = is_plugin_active($ocdi_plugin_path);
            
            if ($is_ocdi_active) : ?>
                <div class="notice notice-info">
                    <p><?php _e('One Click Demo Import plugin is ready. Select a demo below to begin importing.', 'coreit'); ?></p>
                </div>
                
                <div class="stats-card-row">
                    <div class="stats-card">
                        <h4 class="stats-card-title"><?php _e('Available Demos', 'coreit'); ?></h4>
                        <h3 class="stats-card-value"><?php echo count($demos); ?></h3>
                    </div>
                    <div class="stats-card">
                        <h4 class="stats-card-title"><?php _e('Import Time', 'coreit'); ?></h4>
                        <h3 class="stats-card-value">~5-10min</h3>
                    </div>
                    <div class="stats-card">
                        <h4 class="stats-card-title"><?php _e('Server Status', 'coreit'); ?></h4>
                        <h3 class="stats-card-value">
                            <?php 
                            $status = Theme_Server_Capability_Check::get_server_status();
                            if ($status === 'good') {
                                echo '<span style="color:var(--success-color)"><span class="dashicons dashicons-yes-alt"></span> Ready</span>';
                            } elseif ($status === 'warning') {
                                echo '<span style="color:var(--warning-color)"><span class="dashicons dashicons-warning"></span> Warning</span>';
                            } else {
                                echo '<span style="color:var(--danger-color)"><span class="dashicons dashicons-warning"></span> Issues</span>';
                            }
                            ?>
                        </h3>
                    </div>
                </div>
                
                <div class="demo-selection">
                    <?php foreach ($demos as $demo) : ?>
                        <div class="demo-item">
                            <h3><?php echo esc_html($demo['name']); ?></h3>
                            
                            <div class="demo-preview">
                                <?php if (!empty($demo['screenshot'])) : ?>
                                    <img src="<?php echo esc_url($demo['screenshot']); ?>" 
                                         alt="<?php echo esc_attr($demo['name']); ?> Screenshot" 
                                         class="demo-screenshot">
                                <?php endif; ?>
                                
                                <div class="demo-actions">
                                    <?php if (!empty($demo['preview_url'])) : ?>
                                        <a href="<?php echo esc_url($demo['preview_url']); ?>" 
                                           class="button button-secondary" 
                                           target="_blank">
                                            <span class="dashicons dashicons-visibility"></span>
                                            <?php _e('Preview', 'coreit'); ?>
                                        </a>
                                    <?php endif; ?>
                                    
                                    <a href="<?php echo esc_url(admin_url('themes.php?page=one-click-demo-import&step=import&import=' . $demo['id'])); ?>" 
                                       class="button button-primary import-demo-button">
                                        <span class="dashicons dashicons-download"></span>
                                        <?php _e('Import Demo', 'coreit'); ?>
                                    </a>
                                </div>
                            </div>
                            
                            <p><?php echo esc_html($demo['description']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>

            <?php else : ?>
                <div class="notice notice-warning">
                    <p><?php _e('One Click Demo Import plugin is not active. Please install and activate it first.', 'coreit'); ?></p>
                </div>
                <div class="demo-import-actions">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=coreit&step=plugins')); ?>" 
                       class="button button-primary button-hero">
                        <span class="dashicons dashicons-admin-plugins"></span>
                        <?php _e('Go to Plugins Step', 'coreit'); ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="demo-import-note">
            <div class="notice notice-info">
                <h4><?php _e('Import Information', 'coreit'); ?></h4>
                <p><?php _e('Importing demo content will add pages, posts, images, and theme settings to your site.', 'coreit'); ?></p>
                <p><?php _e('We recommend doing this on a fresh WordPress installation to avoid conflicts with your existing content.', 'coreit'); ?></p>
                <p><strong><?php _e('Note:', 'coreit'); ?></strong> <?php _e('The import process may take several minutes depending on your server configuration.', 'coreit'); ?></p>
            </div>
        </div>
        
        <?php do_action('coreit_cleanup_duplicates_page') ?>
    </div>
    <?php
}

    
  
/**
 * Enhanced done step with better UI
 * Replace the existing done_step method
 */
public function done_step() {
     // Get current theme
     $current_theme = wp_get_theme();
     $parent_theme = $current_theme->parent() ? $current_theme->parent() : $current_theme;
     $parent_theme_slug = $parent_theme->get_stylesheet();
     $child_theme_slug = $parent_theme_slug . '-child';
 
     // Check child theme status
     $child_theme_status = 'Not Created';
     $child_theme_exists = wp_get_theme($child_theme_slug);
     
     if ($current_theme->parent()) {
         $child_theme_status = 'Active';
     } elseif ($child_theme_exists->exists()) {
         $child_theme_status = 'Installed (Not Active)';
     }
 
    ?>
    <div class="wizard-step-content">
    <div class="completed_setup">
    <div class="setup-complete-icon">
            <span class="dashicons dashicons-yes-alt"></span>
        </div>
        <h2><?php _e('Setup Complete!', 'coreit'); ?></h2>
        <p><?php printf(__('Congratulations! %s has been set up successfully.', 'coreit'), $this->theme_name); ?></p>
</div>
        
        <div class="stats-card-row">
            <div class="stats-card">
                <h4 class="stats-card-title"><?php _e('Theme', 'coreit'); ?></h4>
                <h3 class="stats-card-value"><?php echo $this->theme_name; ?> <span class="dashicons dashicons-yes-alt" style="color:var(--success-color);"></span></h3>
            </div>
            <div class="stats-card">
                <h4 class="stats-card-title"><?php _e('Plugins Activated', 'coreit'); ?></h4>
                <h3 class="stats-card-value">
                    <?php 
                    $active_plugins = count(get_option('active_plugins'));
                    echo $active_plugins;
                    ?>
                </h3>
            </div>
            <div class="stats-card">
                <h4 class="stats-card-title"><?php _e('Child Theme', 'coreit'); ?></h4>
                <h3 class="stats-card-value">
                <?php 
                    if ($child_theme_status === 'Active') {
                        echo '<span style="color:var(--success-color)"><span class="dashicons dashicons-yes-alt"></span> Active</span>';
                    } elseif ($child_theme_status === 'Installed (Not Active)') {
                        echo '<span style="color:var(--warning-color)"><span class="dashicons dashicons-warning"></span> Installed (Not Active)</span>';
                    } else {
                        echo '<span style="color:var(--text-medium)">Not Created</span>';
                    }
                    ?>
                </h3>
            </div>
        </div>
        
        <div class="next-steps">
            <h3><?php _e('Next Steps', 'coreit'); ?></h3>
            <ul class="next-steps-list">
                <li>
                    <span class="dashicons dashicons-admin-appearance"></span>
                    <div class="next-step-content">
                        <h4><?php _e('Customize Your Theme', 'coreit'); ?></h4>
                        <p><?php _e('Adjust colors, layouts, and more to match your brand.', 'coreit'); ?></p>
                        <a class="button button-primary" href="<?php echo esc_url(admin_url('customize.php')); ?>">
                            <?php _e('Customize Theme', 'coreit'); ?>
                        </a>
                    </div>
                </li>
                <li>
                    <span class="dashicons dashicons-admin-page"></span>
                    <div class="next-step-content">
                        <h4><?php _e('Edit Your Pages', 'coreit'); ?></h4>
                        <p><?php _e('Review and modify your imported pages or create new ones.', 'coreit'); ?></p>
                        <a class="button button-secondary" href="<?php echo esc_url(admin_url('edit.php?post_type=page')); ?>">
                            <?php _e('Manage Pages', 'coreit'); ?>
                        </a>
                    </div>
                </li>
                <li>
                    <span class="dashicons dashicons-dashboard"></span>
                    <div class="next-step-content">
                        <h4><?php _e('Return to Dashboard', 'coreit'); ?></h4>
                        <p><?php _e('Go back to WordPress dashboard to manage your content.', 'coreit'); ?></p>
                        <a class="button button-secondary" href="<?php echo esc_url(admin_url()); ?>">
                            <?php _e('Go to Dashboard', 'coreit'); ?>
                        </a>
                    </div>
                </li>
            </ul>
        </div>
        
     
    </div>
    
    <style>
        .setup-complete-icon {
            text-align: center;
            margin: 0 auto 30px;
        }
        .setup-complete-icon .dashicons {
            font-size: 80px;
            width: 80px;
            height: 80px;
            background: var(--success-color);
            color: white;
            border-radius: 50%;
            padding: 20px;
        }
        .next-steps-list {
            list-style: none;
            padding: 0;
            margin: 30px 0;
            display: flex;
            gap: 1rem;
        }
        .next-steps-list li {
            display: flex;
            margin-bottom: 20px;
            padding: 20px;
            background: var(--bg-light);
            border-radius: var(--radius-md);
            border: 1px solid var(--border-color);
        }
        .next-steps-list .dashicons {
            font-size: 30px;
            width: 30px;
            height: 30px;
            margin-right: 20px;
            color: var(--primary-color);
        }
        .next-step-content {
            flex: 1;
        }
        .next-step-content h4 {
            margin-top: 0;
            margin-bottom: 10px;
        }
        .next-step-content p {
            margin-bottom: 15px;
        }
        .setup-complete-message {
            text-align: center;
            margin-top: 40px;
        }
    </style>
    <?php
}

    /**
     * Get plugin path based on slug
     */
    private function get_plugin_path($plugin_slug) {
        switch ($plugin_slug) {
            case 'elementor':
                return 'elementor/elementor.php';
            case 'one-click-demo-import':
                return 'one-click-demo-import/one-click-demo-import.php';
            case 'woocommerce':
                return 'woocommerce/woocommerce.php';
            case 'contact-form-7':
                return 'contact-form-7/wp-contact-form-7.php';
            case 'coreit-addons':
                return 'coreit-addons/class-coreit-addons.php';
            case 'mailchimp-for-wp':
                return 'mailchimp-for-wp/mailchimp-for-wp.php';
            case 'ameliabooking':
                return 'ameliabooking/ameliabooking.php';
            case 'gtranslate':
                return 'gtranslate/gtranslate.php';
            case 'wp-job-manager':
                return 'wp-job-manager/wp-job-manager.php';
            case 'coreit-template-importer':
                return 'coreit-template-importer/coreit-template-importer.php';
            default:
                return $plugin_slug . '/' . $plugin_slug . '.php';
        }
    }
    
    /**
     * AJAX handler for plugin installation
     */
    public function ajax_install_plugin() {
        // Check nonce
        check_ajax_referer('theme_setup_wizard', 'nonce');
        
        // Check permissions
        if (!current_user_can('install_plugins')) {
            wp_send_json_error(array('message' => __('You do not have permission to install plugins.', 'coreit')));
        }
        
        // Get plugin slug
        $plugin_slug = isset($_POST['slug']) ? sanitize_text_field($_POST['slug']) : '';
        $plugin_source = isset($_POST['source']) ? sanitize_text_field($_POST['source']) : '';
        
        if (empty($plugin_slug)) {
            wp_send_json_error(array('message' => __('Plugin slug is required.', 'coreit')));
        }
        
        // Include required files for plugin installation
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php';
        
        // Check if plugin is already installed
        $plugin_path = $this->get_plugin_path($plugin_slug);
        if (file_exists(WP_PLUGIN_DIR . '/' . $plugin_path)) {
            wp_send_json_success(array(
                'message' => __('Plugin is already installed.', 'coreit'),
                'slug' => $plugin_slug,
                'path' => $plugin_path
            ));
        }
        
        // Set up the upgrader
        $skin = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);
        
        // Install from custom source (bundled plugin) or WordPress repository
        if (!empty($plugin_source)) {
            // Install from local source
            $result = $upgrader->install($plugin_source);
        } else {
            // Get plugin info from repository
            $api = plugins_api('plugin_information', array(
                'slug' => $plugin_slug,
                'fields' => array(
                    'short_description' => false,
                    'sections' => false,
                    'requires' => false,
                    'rating' => false,
                    'ratings' => false,
                    'downloaded' => false,
                    'last_updated' => false,
                    'added' => false,
                    'tags' => false,
                    'compatibility' => false,
                    'homepage' => false,
                    'donate_link' => false,
                ),
            ));
            
            if (is_wp_error($api)) {
                wp_send_json_error(array('message' => $api->get_error_message()));
            }
            
            // Install from WordPress repository
            $result = $upgrader->install($api->download_link);
        }
        
        // Check for installation errors
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        } elseif (is_wp_error($skin->result)) {
            wp_send_json_error(array('message' => $skin->result->get_error_message()));
        } elseif ($skin->get_errors()->has_errors()) {
            wp_send_json_error(array('message' => $skin->get_error_messages()));
        } elseif (is_null($result)) {
            wp_send_json_error(array('message' => __('Plugin installation failed for an unknown reason.', 'coreit')));
        }
        
        // Installation was successful, return success response
        wp_send_json_success(array(
            'message' => __('Plugin installed successfully.', 'coreit'),
            'slug' => $plugin_slug,
            'path' => $plugin_path
        ));
    }
    /**
 * AJAX handler for plugin deactivation
 */
public function ajax_deactivate_plugin() {
    // Check nonce
    check_ajax_referer('theme_setup_wizard', 'nonce');
    
    // Check permissions
    if (!current_user_can('deactivate_plugins')) {
        wp_send_json_error(array('message' => __('You do not have permission to deactivate plugins.', 'coreit')));
    }
    
    // Get plugin path
    $plugin_path = isset($_POST['path']) ? sanitize_text_field($_POST['path']) : '';
    
    if (empty($plugin_path)) {
        wp_send_json_error(array('message' => __('Plugin path is required.', 'coreit')));
    }
    
    // Include required files
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    
    // Check if plugin is active
    if (!is_plugin_active($plugin_path)) {
        wp_send_json_success(array(
            'message' => __('Plugin is already deactivated.', 'coreit'),
            'path' => $plugin_path
        ));
    }
    
    // Deactivate the plugin
    deactivate_plugins($plugin_path);
    
    // Check if deactivation was successful
    if (!is_plugin_active($plugin_path)) {
        wp_send_json_success(array(
            'message' => __('Plugin deactivated successfully.', 'coreit'),
            'path' => $plugin_path
        ));
    } else {
        wp_send_json_error(array('message' => __('Failed to deactivate plugin.', 'coreit')));
    }
}
    /**
     * AJAX handler for plugin activation
     */
    public function ajax_activate_plugin() {
        // Check nonce
        check_ajax_referer('theme_setup_wizard', 'nonce');
        
        // Check permissions
        if (!current_user_can('activate_plugins')) {
            wp_send_json_error(array('message' => __('You do not have permission to activate plugins.', 'coreit')));
        }
        
        // Get plugin path
        $plugin_path = isset($_POST['path']) ? sanitize_text_field($_POST['path']) : '';
        
        if (empty($plugin_path)) {
            wp_send_json_error(array('message' => __('Plugin path is required.', 'coreit')));
        }
        
        // Include required files
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        
        // Check if plugin is already active
        if (is_plugin_active($plugin_path)) {
            wp_send_json_success(array(
                'message' => __('Plugin is already active.', 'coreit'),
                'path' => $plugin_path
            ));
        }
        
        // Activate the plugin
        $result = activate_plugin($plugin_path);
        
        // Check for activation errors
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        // Activation was successful, return success response
        wp_send_json_success(array(
            'message' => __('Plugin activated successfully.', 'coreit'),
            'path' => $plugin_path
        ));
    }
}

// Initialize the class
new Integrated_Theme_Setup_Wizard();