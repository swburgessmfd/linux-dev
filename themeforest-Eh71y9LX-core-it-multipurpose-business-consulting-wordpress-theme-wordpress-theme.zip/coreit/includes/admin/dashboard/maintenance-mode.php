<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue Elementor styles properly
function enqueue_elementor_styles() {
    if (class_exists('Elementor\Plugin')) {
        \Elementor\Plugin::$instance->frontend->enqueue_styles();
    }
}
add_action('wp_enqueue_scripts', 'enqueue_elementor_styles', 11);
add_filter('body_class', function($classes) {
    if (class_exists('Elementor\Plugin')) {
        $kit_id = \Elementor\Plugin::$instance->kits_manager->get_active_id(); // Get active kit ID
        $classes[] = 'elementor-default';
        $classes[] = 'elementor-page';
        $classes[] = 'elementor-kit-' . esc_attr($kit_id);
    }
    return $classes;
}); 
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class('maintenance-mode'); ?>> <!-- Ensure maintenance mode class is added -->

    <div id="page" class="page_wrapper maintenance hfeed site">
        <?php
        // Fetch the Elementor block ID from theme options
        $maintenance_mode_blocks = coreit_get_option('maintance_mode_blocks');

        // Display the maintenance mode block if it exists
        if (!empty($maintenance_mode_blocks)) {
            echo do_shortcode('[coreit-blocks id="' . esc_attr($maintenance_mode_blocks) . '"]');  
        } else {
            // Fallback message
            echo '<div class="maintenance-content">';
            echo '<h1>Site Under Maintenance</h1>';
            echo '<p>We are currently performing scheduled maintenance. Please check back later.</p>';
            echo '</div>';
        }
        ?>
    </div>

    <?php wp_footer(); ?>
</body>
</html>
