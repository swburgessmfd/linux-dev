<?php
// ThemeHelper
namespace Coreit; 
final class ThemeHelper {
    private static $instance = null;
    // Method to get the singleton instance
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }  
    // Make the constructor private to enforce singleton pattern
    public function __construct() {   
        // Load styles
        add_action('wp_enqueue_scripts', array( $this, 'coreit_load_style_scripts' )); 
        // Admin files 
        $this->coreit_get_admin_files();
        // Files
        $this->coreit_get_files();
        // Theme setup
        add_action( 'after_setup_theme', array( $this, 'coreit_theme_setup' ));
        // Register Widgets
        add_action('widgets_init', array( $this, 'coreit_register_sidebar')); 
        // Disble Elementor Redirect
        add_action('init', array( $this, 'coreit_onboarding_redirect')); 
        // Post Feature Image
        add_action('coreit_get_post_feature_image', array( $this, 'coreit_post_feature_image')); 
        add_action('template_redirect', [$this , 'coreit_maintenance_mode']); 
        add_action('coreit_get_authour_content' , [$this , 'coreit_authour_content']);
        add_action('coreit_get_search' , array($this , 'coreit_search'));
        // Disable WooCommerce Page Installation
        add_filter( 'woocommerce_create_pages', '__return_false' );
        // Disable redirection after activating The Woocommerce
        add_filter( 'woocommerce_prevent_automatic_wizard_redirect', '__return_true' );  
        add_action('template_redirect', [$this, 'check_maintenance_mode']);
    }
    /**
     * Check maintenance mode from Theme_Admin_Panel
     */
    public function check_maintenance_mode() {
        $maintenance_enabled = get_theme_mod('enable_maintenance', false);

        if ($maintenance_enabled && !is_user_logged_in() && !is_admin()) {
            wp_die(
                file_get_contents(get_template_directory() . '/includes/admin/dashboard/maintenance-mode.php'),
                'Maintenance Mode',
                array('response' => 503)
            );
        }
    }
    // coreit search
    public function coreit_search() { ?>
        <form  method="get" action="<?php echo esc_url(home_url( '/' )); ?>">
            <input type="search" class="search" placeholder="<?php echo esc_attr__( 'Search...', 'coreit' ); ?>"
                value="<?php echo get_search_query() ?>" name="s" title="Search" />
            <button type="submit" class="sch_btn"> <i class="coreits-search"></i></button>
        </form>
    <?php 
    }  
    // Authour Content
    public function coreit_authour_content(){
        ?>
        <div class="author-details">
                <?php 
                    // Get author data
                    $author = get_queried_object(); 
                    // Display author image
                    echo '<div class="author-image mb_20 d_flex align-items-center">';
                    echo get_avatar( $author->ID, 100 );
                    // Display author name
                    echo '<div class="font-24">' . esc_html( $author->display_name ) . '</div>';
                    echo '</div>'; 
                    // Display author biography
                    echo '<p class="text-14 mb_10">' . esc_html( get_the_author_meta( 'description', $author->ID ) ) . '</p>';
                    // Display author email
                    echo '<p  class="text-14 mb_10">Email: <a href="mailto:' . esc_attr( $author->user_email ) . '">' . esc_html( $author->user_email ) . '</a></p>';
                    // Display author website
                    if ( $author->user_url ) {
                        echo '<p  class="text-14 mb_10">Website: <a href="' . esc_url( $author->user_url ) . '" target="_blank">' . esc_html( $author->user_url ) . '</a></p>';
                    }
                    do_action('coreit_theme_authour_share');
                ?>
            </div>
        <?php
    }
    // Get Files
    public function coreit_get_files() { 

        require_once get_template_directory() . '/includes/admin/dashboard/Setup.php'; 
        require_once get_template_directory() . '/includes/main/libs/Coreit_navwalker.php';   
        require_once get_template_directory() . '/includes/main/breadcrumb/file.php'; 
        require_once get_template_directory() . '/includes/main/function.php';  
        require_once get_template_directory() . '/includes/main/post/meta.php'; 
        require_once get_template_directory() . '/includes/main/comment/comment.php';    
        
        if ( class_exists( 'WooCommerce' ) ) {

            require_once get_template_directory() . '/includes/main/Woo/Action.php';
            require_once get_template_directory() . '/includes/main/Woo/Card.php';
        } 
    } 
    //  Ge5 admin files
    public function coreit_get_admin_files() {   
        require_once get_template_directory() . '/includes/admin/dashboard/customizer/customizer.php';  
        if ( class_exists( 'WooCommerce' ) ) {

            require_once get_template_directory() . '/includes/admin/dashboard/customizer/woocommerce-cutomizer.php';  
        } 
        require_once get_template_directory() . '/includes/admin/dashboard/menu/menu-option.php'; 
    }  
    public function coreit_maintenance_mode() { 
        $enable_maintenance = coreit_get_option('enable_maintenance', false);
        if ($enable_maintenance == true && !current_user_can('manage_options')) {
            get_template_part('includes/admin/dashboard/maintenance-mode');
            exit();
        }
    }
   
    // coreit theme setup
    public function coreit_theme_setup(){
        if (!isset($content_width))
        $content_width = 840; 
        // Make theme available for translation
        load_theme_textdomain('coreit', get_template_directory() . '/lang');
        // Add Theme Support
        add_theme_support('post-thumbnails');
        add_theme_support('title-tag');
        add_theme_support('html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        )); 
        add_theme_support('post_format', ['aside', 'gallery', 'link', 'image', 'quote', 'status', 'video', 'audio', 'chat']);
        // Add default posts and comments RSS feed links to head.
        add_theme_support('automatic-feed-links');
        // Load default block styles.
        add_theme_support('wp-block-styles');
        // Add support for responsive embeds.
        add_theme_support('responsive-embeds');
        // Add support for wide and full alignment.
        add_theme_support('align-wide');
        // Register_nav_menus
        register_nav_menus(array(
            'primary' => esc_html__('Primary Menu', 'coreit'),
        ));  
        // Image size
        add_image_size( 'coreit-blog-image-1200-700', 1200, 700, true ); 
        add_image_size( 'coreit-image-370-270', 370, 270, true ); 
        add_image_size( 'coreit-related-post-470-370', 470, 370, true ); 
        add_image_size( 'coreit-team-single-image-1200-700', 1200, 700, true ); 
         // Woocommerce Theme Support 
         add_theme_support( 'woocommerce');
         add_theme_support( 'wc-product-gallery-zoom' ); 
         add_theme_support( 'wc-product-gallery-slider' );
       
    
    
    }
    public function coreit_post_feature_image(){
        $feature_image_width = coreit_get_option('feature_image_width', 1200);
        $feature_image_height = coreit_get_option('feature_image_height', 700);  
        // Extract width and height from the selected dimensions
        $custom_width = isset($feature_image_width) ? $feature_image_width : '';
        $custom_height = isset($feature_image_height) ? $feature_image_height : '';
        // Build the size attribute for the_post_thumbnail() based on the selected dimensions
        $sing_thumbnail_size = 'coreit-blog-image-1200-700'; // Default thumbnail size
        if (!empty($custom_width) && !empty($custom_height)) {
            // If custom width and height are provided, create a new thumbnail size with custom dimensions
            $sing_thumbnail_size = array($custom_width, $custom_height);
        } elseif (!empty($custom_width)) {
            // If only custom width is provided, resize thumbnail with custom width and maintain aspect ratio
            $sing_thumbnail_size = array($custom_width, '');
        } elseif (!empty($custom_height)) {
            // If only custom height is provided, resize thumbnail with custom height and maintain aspect ratio
            $sing_thumbnail_size = array('', $custom_height);
        }  
      the_post_thumbnail($sing_thumbnail_size, array('class' => 'trans'));
    }
    // disable elementor redirect
    public function coreit_onboarding_redirect() {
        delete_transient( 'elementor_activation_redirect' ); 
    }
    // Register Sidebar
    public function coreit_register_sidebar(){
        $sidebars = array(
            'sidebar-blog' => esc_html__('Blog Sidebar', 'coreit') ,
            'page-sidebar' => esc_html__('Page Sidebar', 'coreit') ,
            'portfolio-sidebar' => esc_html__('Portfolio Sidebar', 'coreit') ,
            'service-sidebar' => esc_html__('Service Sidebar', 'coreit') ,
            'team-sidebar' => esc_html__('Team Sidebar', 'coreit') , 
            'shop-sidebar' => esc_html__('Shop Sidebar', 'coreit') , 
            'shop-single-sidebar' => esc_html__('Shop Single Sidebar', 'coreit') , 
        );
        // Add Job Sidebar if WP_Job_Manager_Autoload exists
        if (class_exists('WP_Job_Manager_Autoload')) {
            $sidebars['job-sidebar'] = esc_html__('Job Sidebar', 'coreit'); // New Job Sidebar
        }
        // Register sidebars
        foreach ($sidebars as $id => $name) {
            register_sidebar(
                array(
                    'name' => $name,
                    'id' => $id,
                    'description' => esc_html__('Add widgets here in order to display on pages', 'coreit') ,
                    'before_widget' => '<div class="widgets_grid_box"><div id="%1$s" class="widget %2$s">',
                    'after_widget' => '</div> </div>',
                    'before_title' => '<h4 class="widget-title">',
                    'after_title' => '</h4>',
                ));
        }
    } 
    // coreit theme fonts
    public function coreit_theme_fonts(){
        $fonts_url = ''; 
        $SpaceGrotesk = _x( 'on', 'Space Grotesk font: on or off', 'coreit' );    
        $Outfit = _x( 'on', 'Outfit font: on or off', 'coreit' );    
        if ('off' !== $SpaceGrotesk || 'off' !== $Outfit) {
            $font_families = array(); 
            if ( 'off' !== $SpaceGrotesk ) {
                $font_families[] = 'Space Grotesk:400,500,600,700,800,900&display=swap';
            }  
            if ( 'off' !== $Outfit ) {
                $font_families[] = 'Outfit:400,500,600,700&display=swap'; 
            }  
            $query_args = array(
                'family' => urlencode( implode( '|', $font_families ) ),
                'subset' => urlencode( 'latin,latin-ext' ),
            );
            $protocol  = is_ssl() ? 'https' : 'http';
            $fonts_url = add_query_arg( $query_args, $protocol . '://fonts.googleapis.com/css' );
        }
        return esc_url_raw( $fonts_url ); 
    }
    // coreit Check Blog
    public function coreit_is_blog () {
        return ( is_archive() || is_author() || is_category() || is_home() || is_tag()) && 'post' == get_post_type();
    }
    // coreit Enque styles and scripts
    public function coreit_load_style_scripts() { 
        // Step 1: Always enqueue styles (whether combined or not)
        wp_enqueue_style('coreit-icons', get_template_directory_uri() . '/assets/css/scss/icons/icons-url.css', array(), time(), 'all');
        wp_enqueue_style('coreit-theme-style', get_template_directory_uri() . '/assets/css/theme.min.css', array(), time(), 'all');
        wp_enqueue_style('coreit-style', get_template_directory_uri() . '/style.css', array(), time(), 'all');
        wp_enqueue_style('coreit-fonts', $this->coreit_theme_fonts(), array(), null);
        // Comment scripts for single posts
        if (is_singular() && comments_open() && get_option('thread_comments')) {
            wp_enqueue_script('comment-reply');
        } 
        // Enqueue JavaScript files
        wp_enqueue_script('coreit-library', get_template_directory_uri() . '/assets/js/coreit-library.js', array('jquery'), '1.0.0', true);
        wp_enqueue_script('coreit-theme', get_template_directory_uri() . '/assets/js/coreit-theme.js', array('jquery'), '1.0.0', true);
     
    } 

} 
ThemeHelper::instance();