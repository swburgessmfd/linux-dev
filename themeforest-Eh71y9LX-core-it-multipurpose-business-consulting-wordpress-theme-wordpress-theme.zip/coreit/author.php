<?php
/** 
 * Authour
 * @package coreit wordpress theme
 * @version 1.0.0
 * *
* */
get_header(); ?>
        <div class="col-lg-4 col-md-4 col-sm-6">
            <?php do_action('coreit_get_authour_content'); ?>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
            <div class="author-posts">
                <?php if(have_posts()) : ?>
                <?php while(have_posts()) : the_post(); ?>
                <?php
                        /* Include the Post-Format-specific template for the content.
                        * ifyou want to override this in a child theme, then include a file
                        * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                        */
                        get_template_part('template-parts/content/content', 'authour');
                    ?>
                <?php endwhile; ?>
                <?php else : ?>
                <?php get_template_part('template-parts/content/content', 'none'); ?>
                <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                    <?php do_action('coreit_custom_pagination'); ?>
                    </div>
                </div> 
            </div><!-- .author-posts -->
        </div>
<?php get_footer(); ?>