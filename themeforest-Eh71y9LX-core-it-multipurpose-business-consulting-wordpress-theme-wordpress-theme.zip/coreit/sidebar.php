<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package coreit
*/
if( 'no-sidebar' == coreit_get_layout() ) {
	return;
} 
$sidebar = 'sidebar-blog' ;
$side_class_inner = 'blog_siderbar side_bar_default_class';
if(is_page() && !is_post_type_archive('product')) {
	$sidebar = 'page-sidebar'; 
	$side_class_inner = 'page_siderbar side_bar_default_class';
} 
elseif (is_tax('service')  || is_singular('service')) {
	$sidebar = 'service-sidebar';
	$side_class_inner = 'service_siderbar side_bar_default_class';
}
elseif (is_tax('team')  || is_singular('team')) {
	$sidebar = 'team-sidebar';
	$side_class_inner = 'team_siderbar side_bar_default_class';
}
elseif (is_tax('product_cat')  || is_post_type_archive('product')) {
	$sidebar = 'shop-sidebar';
	$side_class_inner = 'shop_siderbar side_bar_default_class';
}
elseif (is_singular('product')) {
	$sidebar = 'shop-single-sidebar';
	$side_class_inner = 'shop_siderbar side_bar_default_class';
}
elseif (is_singular('job_listing')) {
	$sidebar = 'job-sidebar';
	$side_class_inner = 'joblisitng_siderbar side_bar_default_class';
}
if (is_page() || is_singular('service') || is_singular('team') || is_singular('post')) {
	$select_sidebar = get_post_meta(get_the_ID() , 'select_sidebar' , true); 
	$custom_sidebar_enable = get_post_meta(get_the_ID() , 'custom_sidebar_enable' , true);
	if($custom_sidebar_enable == "on"){
		$sidebar = $select_sidebar;
	}
}
// Portfolio
$port_sidebar = "";
$port_side_class_inner = "";
if (is_tax('portfolio')  || is_singular('portfolio')) {
	$port_sidebar = 'portfolio-sidebar';
	$port_side_class_inner = 'portfolio_siderbar side_bar_default_class';
} 
if (is_singular('portfolio')) {
	$select_port_sidebar = get_post_meta(get_the_ID() , 'select_sidebar' , true); 
	$custom_port_sidebar_enable = get_post_meta(get_the_ID() , 'custom_sidebar_enable' , true);
	if($custom_port_sidebar_enable == "on"){
		$port_sidebar = $select_port_sidebar;
	}
}
$post_id = get_the_ID(); // Get the current post ID
$portfolio_info = get_post_meta($post_id, 'portfolio_info', true);
// POrtfolio End
if(!is_singular('portfolio')) {
if(is_active_sidebar($sidebar)): ?>
<aside id="secondary" class="all_side_bar <?php echo esc_attr($sidebar); ?> col-lg-4 col-md-12 col-sm-12">		
	<div class="<?php echo esc_attr($side_class_inner); ?>">
	<?php dynamic_sidebar( $sidebar ) ?>
	</div>
</aside>
<?php endif; ?>
<?php } else{ ?>

<aside id="secondary" class="all_side_bar <?php echo esc_attr($port_sidebar); ?> col-lg-4 col-md-12 col-sm-12">	
	<div class="portfolio_info mb_30">
		<div class="font-24"><?php echo esc_html($portfolio_info); ?></div>
		<?php do_action('coreit_portfolio_projects'); ?>
	</div>	  
	<?php do_action('coreit_theme_share'); ?> 
	<?php if(is_active_sidebar($port_sidebar)): ?> 
	<div class="<?php echo esc_attr($port_side_class_inner); ?>">
		<?php dynamic_sidebar( $port_sidebar ) ?>
	</div> 
	<?php endif; ?>
</aside>

<?php } ?>