<?php
/*
** ============================== 
** coreit Content Service
** ==============================
*/ 
$service_share_disable =  coreit_get_option('service_share_disable'); 
$sing_serviceimage_fit_enable  =  coreit_get_option('sing_serviceimage_fit_enable' , false); 
$service_next_prev_enable = coreit_get_option('service_next_prev_enable' ,  true); 
$service_feature_image_enable = coreit_get_option('service_feature_image_enable' , false); 
$service_relatedpost_enable = coreit_get_option('service_relatedpost_enable' , true); 
$comment_class = "";
if (comments_open()){
    $comment_class = "has_comment";
}
?>
<section id="post-<?php esc_attr(the_ID()); ?>" <?php esc_attr(post_class($comment_class)); ?>>
<div class="service_single_details_outer  content-sservice"> 
    <div class="single_content_upper">
        <?php if($service_feature_image_enable == true) : ?>
            <?php if(has_post_thumbnail()) : ?>
                <div class="single_feature_image <?php if($sing_serviceimage_fit_enable == true): ?>img_obj_fit_center<?php endif; ?>">
                    <?php do_action('coreit_service_post_thumbnail'); ?> 
                </div>
            <?php endif; ?>
        <?php endif; ?>  
        <div class="post_single_content">
            <?php the_content(); ?>
            <div class="clearfix"></div>
            <?php wp_link_pages(); ?>
        </div>     
        <?php if($service_share_disable == true): ?>
          <?php do_action('coreit_theme_share'); ?>
        <?php endif;?>  
    </div> 
    <?php if ($service_next_prev_enable == true) : ?>
        <?php do_action('coreit_custom_pagination_width_img'); ?>
    <?php endif; ?> 
    </div> 
    <?php if($service_relatedpost_enable == true) :
         	do_action('coreit_get_related_post');
    endif; ?>
    <div class="single_content_lower">
        <?php
          // If comments are open or we have at least one comment, load up the comment template
          if (comments_open() || get_comments_number()) :
              comments_template();
          endif;
        ?>
    </div> 
</section>