<?php
/**
 * The template used for displaying single services content in single pages for custom Post tyes
 *
 * @package Coreit wordpress theme
 */
$clerfix = 'clearfix col-lg-12';
?>

<article id="post-<?php the_ID(); ?>" <?php post_class($clerfix); ?>>

	<div class="entry-content job_wp_manager_single clearfix">
		<?php the_content(); ?>
		<div class="clearfix"></div>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Service:', 'coreit' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->
	<?php wp_link_pages(); ?>
</article><!-- #post-## --> 