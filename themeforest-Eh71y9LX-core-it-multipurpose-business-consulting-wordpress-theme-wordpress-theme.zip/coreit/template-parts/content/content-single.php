<?php
/*
** ============================== 
** coreit Content Single
** ==============================
*/ 
$post_sub_title = get_post_meta(get_the_ID(), 'post_sub_title', true);
$post_featured_image = get_post_meta(get_the_ID(), 'post_featured_image', true);
$share_disable =   coreit_get_option('share_disable' , false);
$author_detail_disable =   coreit_get_option('author_detail_disable' , false);
$next_prev_enable =  coreit_get_option('next_prev_enable' , false);
$category_enable = coreit_get_option('bcategory_enable' , false); 
$feature_image_enable =   coreit_get_option('feature_image_enable' , false);
$feature_image_fit =   coreit_get_option('feature_image_fit'); 
$relatedpost_enable =   coreit_get_option('relatedpost_enable' , false);
$date_enable =   coreit_get_option('single_date_enable' , false);
$single_comment_enable =   coreit_get_option('single_comment_enable' , false);
$comment_class = "";
if (comments_open()){
    $comment_class = "has_comment";
} 
?> 
<section id="post-<?php esc_attr(the_ID()); ?>" <?php esc_attr(post_class($comment_class)); ?>>
<div class="blog_single_details_outer  content-Sblog"> 
    <div class="single_content_upper"> 
        <?php if($feature_image_enable == true || $post_featured_image == true) : ?>
            <?php if(has_post_thumbnail()) : ?>
                <div class="single_feature_image <?php if($feature_image_fit == true): ?>img_obj_fit_center<?php endif; ?>">
                    <?php do_action('coreit_get_post_feature_image'); ?>
                    <?php if($date_enable == true): ?>
                        <div class=" meta">
                        <?php do_action('coreit_theme_blog_time_two'); ?>
                        </div>
                    <?php endif; ?> 
                </div> 
            <?php endif; ?>
        <?php endif; ?>  
        <?php if($category_enable == true): ?>
        <?php do_action('coreit_theme_single_cat'); ?>
        <?php endif; ?> 
      </div> 
    <div class="post_single_content">
        <?php the_content(); ?>
        <div class="clearfix"></div>
        <?php wp_link_pages(); ?>
    </div> 
    <?php do_action('coreit_theme_blog_tags_and_cat');?> 
    <?php if($share_disable == true): ?>
        <?php do_action('coreit_theme_share'); ?>
    <?php endif;?>  
    <?php if ($author_detail_disable == true) :
        do_action('coreit_theme_authour_details');
    endif; ?> 
    <?php if ($next_prev_enable == true) : ?>
        <?php do_action('coreit_custom_pagination_width_img'); ?>
    <?php endif; ?> 
    </div> 
    <?php if($relatedpost_enable == true) :
         	do_action('coreit_get_related_post');
    endif; ?>
    <div class="single_content_lower">
        <?php
          // If comments are open or we have at least one comment, load up the comment template
          if (comments_open() || get_comments_number()) :
              comments_template();
          endif;
        ?>
    </div> 
</section>
<?php