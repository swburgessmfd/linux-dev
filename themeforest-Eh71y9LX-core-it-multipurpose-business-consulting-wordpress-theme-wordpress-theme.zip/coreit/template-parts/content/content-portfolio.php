<?php
/*
** ============================== 
** coreit Content portfolio
** ==============================
*/ 
$portfolio_share_disable =   coreit_get_option('portfolio_share_disable' , true); 
$sing_portfolioimage_fit_enable  =  coreit_get_option('sing_portfolioimage_fit_enable' , false); 
$portfolio_next_prev_enable =  coreit_get_option('portfolio_next_prev_enable' , true); 
$portfolio_feature_image_enable =   coreit_get_option('portfolio_feature_image_enable' , false); 
$portfolio_relatedpost_enable =   coreit_get_option('portfolio_relatedpost_enable' , true); 
$portfolio_layouts = coreit_get_option("portfolio_single_layouts", "right-sidebar");
$comment_class = "";
if (comments_open()){
    $comment_class = "has_comment";
}
$post_id = get_the_ID(); // Get the current post ID
$portfolio_info = get_post_meta($post_id, 'portfolio_info', true);
?>
<?php if(is_active_sidebar('portfolio-sidebar') && $portfolio_layouts === "no-sidebar"): ?>
    <div class="row">
<div class="col-lg-4 col-md-4 col-sm-12">
<div class="portfolio_info mb_30">
	<div class="font-24"><?php echo esc_html($portfolio_info); ?></div>
	<?php do_action('coreit_portfolio_projects'); ?> 
</div>	
<?php if($portfolio_share_disable == true): ?>
          <?php do_action('coreit_theme_share'); ?>
        <?php endif;?>  
</div>	
<div class="col-lg-8 col-md-8 col-sm-12">
<?php endif; ?>
<div id="post-<?php esc_attr(the_ID()); ?>" <?php esc_attr(post_class($comment_class)); ?>> 
    <?php if($portfolio_feature_image_enable == true): ?>
        <?php if(has_post_thumbnail()) : ?>
            <div class="single_feature_image mb_30 <?php if($sing_portfolioimage_fit_enable == true): ?>img_obj_fit_center<?php endif; ?>">
                <?php do_action('coreit_portfolio_post_thumbnail'); ?>
            </div>
        <?php endif; ?>
    <?php endif; ?> 
    <?php the_content(); ?>  
    <?php if ($portfolio_next_prev_enable == true) : ?>
        <?php do_action('coreit_custom_pagination_width_img'); ?>
    <?php endif; ?> 
    <?php if($portfolio_relatedpost_enable == true) :
         	do_action('coreit_get_related_post');
    endif; ?>
     <div class="single_content_lower">
        <?php
          // If comments are open or we have at least one comment, load up the comment template
          if (comments_open() || get_comments_number()) :
              comments_template();
          endif;
        ?>
    </div>  
</div>
<?php if(!is_active_sidebar('portfolio-sidebar') && $portfolio_layouts == "no-sidebar"): ?>
</div>
</div>
<?php endif; ?>