<?php
/*
** ============================== 
** coreit Content team
** ==============================
*/ 
$team_share_disable =   coreit_get_option('team_share_disable' , true); 
$sing_teamimage_fit_enable  =  coreit_get_option('sing_teamimage_fit_enable' , true); 
$team_next_prev_enable =  coreit_get_option('team_next_prev_enable' , true);  
$team_relatedpost_enable =   coreit_get_option('team_relatedpost_enable' , true); 
$comment_class = "";
if (comments_open()){
    $comment_class = "has_comment";
}
?>
<section id="post-<?php esc_attr(the_ID()); ?>" <?php esc_attr(post_class($comment_class)); ?>>
    <div class="team_single_details_outer  content-steam"> 
        <div class="single_content_upper">
            <div class="post_single_content">
                <?php the_content(); ?>
                <div class="clearfix"></div>
                <?php wp_link_pages(); ?>
            </div>     
            <?php if($team_share_disable == true): ?>
            <?php do_action('coreit_theme_share'); ?>
            <?php endif;?>  
        </div> 
    <?php if ($team_next_prev_enable == true) : ?>
        <?php do_action('coreit_custom_pagination_width_img'); ?>
    <?php endif; ?> 
    </div> 
    <?php if($team_relatedpost_enable == true) :
         	do_action('coreit_get_related_post');
    endif; ?>
    <div class="single_content_lower">
        <?php
          // If comments are open or we have at least one comment, load up the comment template
          if (comments_open() || get_comments_number()) :
              comments_template();
          endif;
        ?>
    </div> 
</section>