<?php
/*
** ============================== 
** coreit Content Search
** ==============================
*/   
?> 
<?php
/*
** ============================== 
** coreit Content Blog
** ==============================
*/  
$column = coreit_get_option('blog_columned' , 'col-xs-12 list-view'); 
$blog_excerpt_enable = coreit_get_option('blog_excerpt_enable' , true);
$blog_excerpt_count = coreit_get_option('blog_excerpt_counts' , 15);
$blog_date_enable = coreit_get_option('blog_date_enable' , true);  
?> 
<article <?php post_class($column); ?> id="post-<?php esc_attr(the_ID()); ?>"> 
  <div class="cardNews style_one d_flex <?php if(has_post_thumbnail()): ?> has_images <?php else: ?> no_images<?php endif; ?>">
        <?php if(has_post_thumbnail()): ?> 
            <div class="image-box">
            <a href="<?php echo esc_url(get_permalink()); ?>" class="imgbx img_obj_fit_center trans">
                <?php the_post_thumbnail('coreit-blog-image-570-570 trans'); ?>  
            </a> 
            <div class="d-flex meta">
                <?php if($blog_date_enable == true ): ?> 
                        <?php do_action('coreit_theme_blog_time_two'); ?>  
                <?php endif; ?> 
                </div>
            </div>
        <?php endif; ?>
    <div class="cardInfo">  
    
        <div class="all_unset mb_15 trim-2"> <a href="<?php echo esc_url(get_permalink()); ?>" rel="bookmark" class="font-26"><?php the_title(); ?></a></div>
        <?php if($blog_excerpt_enable == true): 
            $the_excerpt = wp_trim_words(get_the_excerpt(), $blog_excerpt_count); 
            if(!empty($the_excerpt)):
            ?>
            <p class="des_cription mb_15"><?php echo esc_html($the_excerpt); ?></p>
        <?php endif; ?>
        <?php endif; ?>   
        <a class="read-more-two" href="<?php echo esc_url(get_permalink()); ?>"> 
              
            <?php echo esc_html__('Read More' , 'coreit'); ?>
        </a> 
    </div>
  </div>
</article>
  
  