<?php
/*
** ============================== 
** coreit Content Blog
** ==============================
*/  
$blog_cat_enable = coreit_get_option('blog_cat_enable' , true);
$blog_excerpt_enable = coreit_get_option('blog_excerpt_enable' , true);
$blog_excerpt_count = coreit_get_option('blog_excerpt_counts' , 15);
$blog_date_enable = coreit_get_option('blog_date_enable' , true); 
$blog_comment_enable = coreit_get_option('blog_comment_enable',true);
$blog_authour_enable = coreit_get_option('blog_authour_enable',true);
$blog_style = coreit_get_option('blog_style', 'style_one'); 
$the_excerpt = wp_trim_words(get_the_excerpt(), $blog_excerpt_count); 
// Image Option start
$imgobj_firena = coreit_get_option('blog_image_fit_enable', true) ? 'img_obj_fit_center' : '';
$width  = coreit_get_option('blog_image_width', '700');
$height = coreit_get_option('blog_image_height', '500');
$thumbnail_size = (!empty($width) || !empty($height)) ? [$width ?: '', $height ?: ''] : ''; 
// Get blog style from URL or fallback to theme option
$blog_style = isset($_GET['bstyle']) ? esc_html($_GET['bstyle']) : coreit_get_option('blog_style', 'style_one');
// Get blog column from URL or fallback to theme option
$blog_columns = isset($_GET['bcolumn']) ? esc_html($_GET['bcolumn']) : coreit_get_option('blog_columned', 'one_column');
// Assign the correct Bootstrap column class
if ($blog_columns == "two_column") {
    $column = "col-lg-6 col-sm-6";
} elseif ($blog_columns == "three_column") {
    $column = "col-lg-4 col-md-4 col-sm-6";
} elseif ($blog_columns == "four_column") {
    $column = "col-lg-3 col-md-4 col-sm-6";
} else {
    $column = "col-lg-12"; // Default for one_column or invalid values
}
// Apply "list-view" class only when both conditions match
$exclass = ($blog_style == "style_one" && $blog_columns == "one_column") ? "list-view" : "";
?>
<article <?php post_class([$column, $exclass]); ?> id="post-<?php the_ID(); ?>">
    <?php if($blog_style  == "style_two"): ?>
        <div class="cardNews style_two  <?php if(has_post_thumbnail()): ?> has_images <?php else: ?> no_images<?php endif; ?>">
                        <?php if($blog_cat_enable): ?>
                            <div class="catbox">
                                <?php do_action('coreit_theme_blog_category'); ?> 
                            </div>
                        <?php endif; ?> 
                        <?php if(has_post_thumbnail()): ?> 
                            <div class="image-box">
                                <?php if($blog_date_enable): ?>
                                    <?php do_action('coreit_theme_blog_time_two'); ?>
                                <?php endif; ?> 
                                <a href="<?php echo esc_url(get_permalink()); ?>" class="imgbx <?php echo esc_attr($imgobj_firena); ?> trans">
                                    <?php the_post_thumbnail($thumbnail_size, array('class' => 'trans')); ?>
                                </a>  
                                <div class="cardInfo trans">   
                                    <div class="all_unset trans">
                                        <a href="<?php echo esc_url(get_permalink()); ?>" rel="bookmark" class="font-28 trim-2 trans trim-2"><?php the_title(); ?></a>
                                    </div>
                                    <div class="desbtn trans">
                                        <?php if($blog_excerpt_enable && !empty($the_excerpt)): ?>
                                            <p class="des_cription trans mb_15"><?php echo esc_html($the_excerpt); ?></p>
                                        <?php endif; ?>
                                        <a class="theme_btn trans one" href="<?php echo esc_url(get_permalink()); ?>"> 
                                            <i class="coreits-clover"></i>
                                            <?php echo esc_html__('Read More' , 'coreit'); ?>
                                        </a> 
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="d-flex meta">
                            <?php if($blog_authour_enable || $blog_comment_enable): ?>
                                <?php if($blog_authour_enable): ?> 
                                    <?php do_action('coreit_get_display_author_name_link'); ?>
                                <?php endif; ?> 
                                <?php if($blog_comment_enable): ?> 
                                    <div class="meta_com"> 
                                        <?php do_action('coreit_theme_blog_comments'); ?>   
                                    </div>
                                <?php endif; ?> 
                            <?php endif; ?> 
                        </div>
                    </div>
    
    <?php elseif($blog_style  == "style_three"): ?>
        <div class="cardNews style_four  <?php if(has_post_thumbnail()): ?> has_images <?php else: ?> no_images<?php endif; ?>">
                     <?php if(has_post_thumbnail()): ?> 
                         <div class="image-box"> 
                             <a href="<?php echo esc_url(get_permalink()); ?>" class="imgbx <?php echo esc_attr($imgobj_firena); ?> trans">
                                 <?php the_post_thumbnail($thumbnail_size, array('class' => 'trans')); ?>
                             </a> 
                             <?php if($blog_cat_enable): ?> 
                             <?php do_action('coreit_theme_blog_category'); ?> 
                         <?php endif; ?>  
                         </div>
                     <?php endif; ?> 
                     <div class="cardInfo trans">    
                     <div class="d-flex meta">
                                    <?php if($blog_date_enable || $blog_comment_enable): ?>
                                        <?php if($blog_date_enable): ?>
                                            <?php do_action('coreit_theme_blog_time'); ?>
                                        <?php endif; ?> 
                                        <?php if($blog_comment_enable): ?>
                                            <?php do_action('coreit_theme_blog_comments'); ?> 
                                        <?php endif; ?> 
                                    <?php endif; ?> 
                                </div>
                         <a href="<?php echo esc_url(get_permalink()); ?>" rel="bookmark" class="font-28 trim-2 d-block mb_15 trans trim-2"><?php the_title(); ?></a>      
                         <?php if($blog_excerpt_enable == true): ?>
                            <?php if(!empty($the_excerpt)):  ?>
                                <p class="des_cription mb_15"><?php echo esc_html($the_excerpt); ?></p>
                            <?php endif; ?>
                        <?php endif; ?>  
                            <a class="read-more-two" href="<?php echo esc_url(get_permalink()); ?>"> 
                                <i class="trimprim-clover"></i>
                                <?php echo esc_html__('Read More' , 'coreit'); ?>
                            </a> 
                     </div>
                 </div>  
    <?php elseif($blog_style  == "style_four"): ?>
         
        <div class="cardNews  style_six mb_30  <?php if(has_post_thumbnail()): ?> has_images <?php else: ?> no_images<?php endif; ?>">
                        <?php if(has_post_thumbnail()): ?> 
                            <div class="image-box">
                                <a href="<?php echo esc_url(get_permalink()); ?>" class="imgbx <?php echo esc_attr($imgobj_firena); ?> trans">
                                    <?php the_post_thumbnail($thumbnail_size, array('class' => 'trans')); ?>
                                </a> 
                              
                                <?php if($blog_date_enable): ?>
                                    <div class="date">
                                        <?php do_action('coreit_theme_blog_time_two'); ?>
                                </div>
                                    <?php endif; ?> 
                                   
                                 
                              
                            </div>
                        <?php endif; ?>
                        <div class="cardInfo">  
                        <?php if($blog_cat_enable): ?>
                                            <?php do_action('coreit_theme_blog_category'); ?> 
                                        <?php endif; ?> 
                            <?php if($blog_comment_enable): ?> 
                                <div class="meta_com"> 
                                <?php if($blog_comment_enable): ?>  
                                            <?php do_action('coreit_theme_blog_comments'); ?>    
                                    <?php endif; ?> 
                                    <div class="post-views"><i class="coreits-enable"></i><?php echo coreit_get_post_views(get_the_ID()); ?></div>
                                 
                                    <?php coreit_display_like_button(get_the_ID()); ?>  
                                </div>
                            <?php endif; ?> 
                            <div class="all_unset mb_10">
                                <a href="<?php echo esc_url(get_permalink()); ?>" rel="bookmark" class="font-28 trim-2"><?php the_title(); ?></a>
                            </div>
                            <?php if($blog_excerpt_enable && !empty($the_excerpt)): ?>
                                <p class="des_cription mb_0"><?php echo esc_html($the_excerpt); ?></p>
                            <?php endif; ?>   
                            <?php if($blog_authour_enable): ?> 
                                    <?php do_action('coreit_get_display_display_author'); ?>
                                <?php endif; ?> 
                        </div>
                    </div>
    <?php elseif($blog_style  == "style_five"): ?>
        <div class="cardNews  style_seven  <?php if(has_post_thumbnail()): ?> has_images <?php else: ?> no_images<?php endif; ?>">
                        <?php if($blog_cat_enable): ?>
                                            <?php do_action('coreit_theme_blog_category'); ?> 
                                        <?php endif; ?> 
                        <div class="inner_news">
                        <?php if(has_post_thumbnail()): ?> 
                            <div class="image-box trans">
                                <a href="<?php echo esc_url(get_permalink()); ?>" class="imgbx <?php echo esc_attr($imgobj_firena); ?> trans">
                                    <?php the_post_thumbnail($thumbnail_size, array('class' => 'trans')); ?>
                                </a> 
                                
                            </div>
                        <?php endif; ?>
                        <div class="cardInfo">  
                        <?php if($blog_date_enable): ?>
                            <div class="meta_com trans">  
                                    <div class="date">
                                        <?php do_action('coreit_theme_blog_time_two'); ?>
                                    </div>
                                    <div class="post-views"><i class="coreits-enable"></i><?php echo coreit_get_post_views(get_the_ID()); ?></div>
                                 
                                    </div>
                               <?php endif; ?>  
                   
                            <div class="all_unset">
                                <a href="<?php echo esc_url(get_permalink()); ?>" rel="bookmark" class="font-28 trim-2"><?php the_title(); ?></a>
                            </div>
                            <?php if($blog_excerpt_enable && !empty($the_excerpt)): ?>
                                <p class="des_cription mb_0 mt_10"><?php echo esc_html($the_excerpt); ?></p>
                            <?php endif; ?>     
                            <?php if($blog_authour_enable): ?> 
                                    <?php do_action('coreit_get_display_display_author'); ?>
                            <?php endif; ?> 
                            <div class="bottom">
                            <a class="link_btn_two" href="<?php echo esc_url(get_permalink()); ?>"> 
                               
                                <?php echo esc_html__('Read More' , 'coreit'); ?>
                            </a> 
                            <?php coreit_display_like_button(get_the_ID()); ?>   
                            </div>
                        </div>
                        </div>
                    </div>  
    <?php else: ?>
        <div class="cardNews style_one d_flex <?php if(has_post_thumbnail()): ?> has_images <?php else: ?> no_images<?php endif; ?>">
                <?php if(has_post_thumbnail()): ?> 
                    <div class="image-box">
                    <a href="<?php echo esc_url(get_permalink()); ?>" class="imgbx img_obj_fit_center trans">
                        <?php the_post_thumbnail('coreit-blog-image-570-570 trans'); ?>  
                    </a> 
                    <div class="d-flex meta">
                        <?php if($blog_date_enable == true || $blog_cat_enable == true): ?>
                            <?php if($blog_date_enable == true): ?>
                                <?php do_action('coreit_theme_blog_time_two'); ?>
                            <?php endif; ?> 
                            <?php if($blog_cat_enable == true): ?>
                                <?php do_action('coreit_theme_blog_category'); ?> 
                            <?php endif; ?> 
                        <?php endif; ?> 
                        </div>
                    </div>
                <?php endif; ?>
            <div class="cardInfo">  
                <?php if($blog_comment_enable == true): ?> 
                <div class="meta_com"> <?php do_action('coreit_theme_blog_comments'); ?>   </div>
                <?php endif; ?> 
                <div class="all_unset mb_15 trim-2"> <a href="<?php echo esc_url(get_permalink()); ?>" rel="bookmark" class="font-26"><?php the_title(); ?></a></div>
                <?php if($blog_excerpt_enable == true): ?>
                    <?php if(!empty($the_excerpt)):  ?>
                        <p class="des_cription mb_15"><?php echo esc_html($the_excerpt); ?></p>
                    <?php endif; ?>
                <?php endif; ?>   
                <a class="read-more-two" href="<?php echo esc_url(get_permalink()); ?>"> 
                        
                    <?php echo esc_html__('Read More' , 'coreit'); ?>
                </a> 
            </div>
        </div> 
    <?php endif; ?>
</article>
  