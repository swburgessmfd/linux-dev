<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package coreit
 */ 
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php wp_head(); ?>  
</head>
<body <?php body_class(); ?>>
	<?php
if(!function_exists('wp_body_open')) {
    function wp_body_open() {
        do_action( 'wp_body_open' );
	}
} 
$side_menu_enable = coreit_get_option('side_menu_enable');
$mainidclass = "";
if(is_post_type_archive('product') || is_tax('product_cat') || is_tax('product_tag') || is_tax('brand')) {
	$mainidclass = "coreit_shop";
}else{
	$mainidclass = "site-content";
}
?>
<div id="page" class="page_wapper hfeed site">
<div class="top_page_wapper">
<?php //page_wapper?> 
<?php  //preloader?>
	<?php 
	$backtoenable = coreit_get_option('backtoenable' , false);
	if($backtoenable == true) { do_action('coreit_get_preloaders');} ?>  
 
<?php //preloader?>
	<?php // ================= HEADER =================== ?>
	<?php do_action('coreit_get_header'); ?>   
	<?php // ================= HEADER END =================== ?>
	<?php // ================= SIDEMENU =================== ?> 
	<?php do_action('coreit_get_sidemenu'); ?>   
	<?php // ================= SIDEMENU END =================== ?>
	<?php //page header ?> 
		<?php // ================= PAGE HEADER =================== ?>
		<div class="menu_overlay trans"></div> 
		<?php do_action('coreit_default_page_header'); ?>
		<?php // ================= PAGE HEADER END =================== ?>
			<?php //content ?>
			<div id="wrapper_full" class="content_all_warpper"> 
			<div id="<?php echo esc_attr($mainidclass); ?>" class="<?php echo esc_attr($mainidclass); ?> <?php echo get_post_meta(get_the_ID() , 'blog_single_page_header' , true); ?>">
				<?php $container = 'auto-container auto_container';
	                if( is_page_template( 'template-homepage.php' ) || is_page_template( 'template-empty.php' ) || is_page_template( 'template-fullwidth.php' ) || is_page_template( 'template-boxed.php' ) || is_singular('header')  || is_singular('footer')  || is_singular('mega_menu') || is_singular('coreitblocks') || is_singular('coreitsliders')  || is_404() ):
						$container = 'no-container';
					endif;
		        ?>
				<div class="<?php echo esc_attr($container); ?>">
				<?php   
                    $layout_row = '';
                    if (class_exists('Mainthemefucntion')) {
                        $layout_row = Mainthemefucntion::coreit_get_layout();
                    }
					$row = 'row';
					if( is_page_template( 'template-homepage.php' ) || is_page_template( 'template-empty.php' ) || is_page_template( 'template-fullwidth.php' ) || is_page_template( 'template-boxed.php' ) || is_singular('header')  || is_singular('footer')  || is_singular('mega_menu') || is_singular('coreitblocks') || is_singular('coreitsliders')  || is_404()  || $layout_row == 'no-sidebar'):
						$row = 'no-row';
					else:
						$row = 'row default_row';
					endif;
				?>
				<div class="<?php echo esc_attr( $row ) ?>">   