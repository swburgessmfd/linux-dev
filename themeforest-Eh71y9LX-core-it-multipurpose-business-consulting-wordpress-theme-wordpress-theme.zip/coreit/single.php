<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package coreit
*/ 
get_header(); 
if(is_singular('header') || is_singular('footer') || is_singular('mega_menu')  || is_singular('coreitblocks') || is_singular('coreitsliders')):
?>
<div class="content-area"> 
	<?php while ( have_posts() ) : the_post(); ?>
		<?php get_template_part( 'template-parts/content/content', 'blocks' ); ?>
	<?php endwhile; // end of the loop. ?>
</div><!-- #primary --> 
<?php else: ?>
<div id="primary" class="content-area <?php coreit_column_for_blog(); ?>">
		<?php while ( have_posts() ) : the_post(); ?>
		    <?php get_template_part( 'template-parts/content/content', 'single' ); ?>
		<?php endwhile; // end of the loop. ?>
</div><!-- #primary -->
<?php get_sidebar(); ?>
<?php endif; ?>
<?php get_footer(); ?>
