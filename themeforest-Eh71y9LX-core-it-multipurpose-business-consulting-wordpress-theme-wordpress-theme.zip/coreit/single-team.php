<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package coreit
*/ 
get_header(); 
?>
<div id="primary" class="content-area <?php coreit_column_for_team(); ?>">
		<?php while ( have_posts() ) : the_post(); ?>
		    <?php get_template_part( 'template-parts/content/content', 'team' ); ?>
		<?php endwhile; // end of the loop. ?>
</div><!-- #primary -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
 