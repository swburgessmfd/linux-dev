(function($) {
	("use strict");
	$(window).on("load", function () {
        $("#preloader-active").delay(1000).fadeOut("slow");
    });
	if($('.loader-wrap').length){
        $('.loader-wrap').delay(1000).fadeOut("slow");  
    } 
	$(document).ready(function() {
        $('.cardService.one').hover(function() {
            var boxInfoHeight = $(this).find('.box-inner-info')[0].scrollHeight; // Get the scroll height
            $(this).find('.box-inner-info').css('height', boxInfoHeight + 'px');
        }, function() {
            $(this).find('.box-inner-info').css('height', '0'); // Set height to 0 on hover out
        });
    }); 
	// Page loading 
	/*---====================---header drop down button---======================---*/
	if ($('.navbar_nav li.dropdown ul').length) {
		$('.navbar_nav li.dropdown > a').append('<div class="dropdown-btn trans"><span class="coreits-down1"></span></div>');
	}
	if ($('.navbar_nav li.mega_menu  ul').length) {
		$('.navbar_nav li.mega_menu >  a').append('<div class="dropdown-btn trans"><span class="coreits-down1"></span></div>');
	}
	$(document).ready(function(){
        // Adjust submenu position based on parent li height
        $('.navbar_nav > li:not(.mega_menu)').hover(function(){
            var submenu = $(this).find('.navbar_nav > li > .sub-menu');
            var liHeight = $(this).outerHeight(); // Get height of parent li including padding and borders
            submenu.addClass('active').css('top', liHeight);
        }, function(){
            $(this).find('.navbar_nav > li > .sub-menu').removeClass('active');
        });
    });
	/*---====================---back-to-top---======================---*/
if ($('.prgoress_indicator path').length) {
    const progressPath = document.querySelector('.prgoress_indicator path');
    const pathLength = progressPath.getTotalLength();
    
    // Initialize path
    progressPath.style.transition = progressPath.style.WebkitTransition = 'none';
    progressPath.style.strokeDasharray = pathLength + ' ' + pathLength;
    progressPath.style.strokeDashoffset = pathLength;
    progressPath.getBoundingClientRect();
    progressPath.style.transition = progressPath.style.WebkitTransition = 'stroke-dashoffset 10ms linear';
    
    const updateProgress = function() {
        const scroll = $(window).scrollTop();
        const height = $(document).height() - $(window).height();
        const progress = pathLength - (scroll * pathLength / height);
        progressPath.style.strokeDashoffset = progress;
    };

    updateProgress();
    $(window).on('scroll', updateProgress);

    const offset = 250;
    
    $(window).on('scroll', function() {
        if ($(this).scrollTop() > offset) {
            $('.prgoress_indicator').addClass('active-progress');
        } else {
            $('.prgoress_indicator').removeClass('active-progress');
        }
    });

    // Smooth scroll to top
    $('.prgoress_indicator').on('click', function(e) {
        e.preventDefault();
        window.scrollTo({
            top: 0,
            behavior: 'smooth'  // Changed to 'smooth' for animated scrolling
        });
        return false;
    });
}
	/*---====================---mobile navbar append---======================---*/
	if ($('.mobile_menu_box').length) {
		//Menu Toggle Btn
		$('.navbar_togglers').on('click', function() {
			$('body').toggleClass('mobile_menu_box-visible');
		});
		//Menu Toggle Btn
		$('.mobile_menu_box .menu-backdrop,.mobile_menu_box .close-btn').on('click', function() {
			$('body').removeClass('mobile_menu_box-visible');
		});
	}
	if ($('.luxsearch').length) {
		//Menu Toggle Btn
		$('.enableluxsearch').on('click', function() {
			$('.search_sidebar').toggleClass('search_sidebar-visible');
		});
		//Menu Toggle Btn
		$('.search_sidebar .close-btn , .search_sidebar .menu-backdrop').on('click', function() {
			$('.search_sidebar').removeClass('search_sidebar-visible');
		});
	}
	/*---====================---header drop down toggle---======================---*/
	//Mobile Nav Hide Show
	if ($('.mobile_menu_box').length) {
		var mobileMenuContent = $('.navbar_nav').html();
		$('.mobile_menu_box .navbar_nav').append(mobileMenuContent);
	}
	var $offCanvasNav = $(".mobile_menu_box"),
		$offCanvasNavSubMenu = $offCanvasNav.find(".sub-menu");
	/*Add Toggle Button With Off Canvas Sub Menu*/
	$offCanvasNavSubMenu.parent().prepend('<span class="dropdown-btn"><i class="coreits-down-arrow"></i></span>');
	/*Close Off Canvas Sub Menu*/
	$offCanvasNavSubMenu.slideUp();
	/*Category Sub Menu Toggle*/
	$offCanvasNav.on("click", "li a, li .dropdown-btn", function(e) {
		var $this = $(this);
		if (
			$this
			.parent()
			.attr("class")
			.match(/\b(menu-item-has-children|has-children|has-sub-menu|sub-menu|mega_menu)\b/) &&
			($this.attr("href") === "#" || $this.hasClass("dropdown-btn"))
		) {
			e.preventDefault();
			if ($this.siblings("ul:visible").length) {
				$this.parent("li").removeClass("drop-active");
				$this.siblings("ul").slideUp();
			} else {
				$this.parent("li").addClass("drop-active");
				$this.closest("li").siblings("li").removeClass("drop-active").find("li").removeClass("drop-active");
				$this.closest("li").siblings("li").find("ul:visible").slideUp();
				$this.siblings("ul").slideDown();
			}
		}
	});
	$(document).ready(function() {
		function handleMiniCartClick() {
			console.log("Mini cart icon clicked");
			$('body').addClass('open_cart');
		}
		function handleCloseCartClick() {
			console.log("Close cart button clicked");
			$('body').removeClass('open_cart');
		}
		// Shop Page - Mini Cart Icon
		$(document).on('click', '.micoreit-cart-icon', handleMiniCartClick);
		// Shop Page and Product Single Page - Close Cart Button
		$(document).on('click', '.cart_box .box-cart-close , .cart_box .overlay_box', handleCloseCartClick);
	});
	$(document).ready(function() {
		var duration = 1000; // Set the initial duration (e.g., 3 seconds)
		function hideSkeletonLoading() {
			$(".sketch-loading").hide();
		}
		function showSkeletonLoading() {
			$(".sketch-loading").show();
		}
		function resetTimer() {
			clearTimeout(timer);
			timer = setTimeout(hideSkeletonLoading, duration);
		}
		var timer = setTimeout(hideSkeletonLoading, duration);
		$(".load_more_jobs , .job_types li label").click(function() {
			showSkeletonLoading();
			resetTimer();
			// Add your additional code here for loading more content
		});
		$(".woo_pagination.loadmoreproduct .woocommerce-pagination a").click(function() {
			showSkeletonLoading();
			resetTimer();
			// Add your additional code here for loading more content
		});
	});
	 /*---====================---Year Update---======================---*/
	function coreit_year_update(){
		$(document).ready(function() {
			// Function to update the year
			function updateYear() {
				$('.trimyear').text(new Date().getFullYear());
			}
			// Initial update
			updateYear();
			// Update the year every second
			setInterval(updateYear, 1000);
		});
	}
	 /*---====================---faqs---======================---*/
	 function coreit_faqsall() {
		if ($('.accordion_box').length) {
			$(".accordion_box").off('click').on('click', '.question', function () {
				console.log('Accordion question clicked');
				var outerBox = $(this).closest('.accordion_box');
				var target = $(this).closest('.accordion');
				// Toggle the active class on the clicked question
				$(this).toggleClass('active');
				// Close other open accordions except the one being clicked
				outerBox.find('.accordion').not(target).removeClass('active-block');
				outerBox.find('.accordion .question, .accordion .icon_fq').not(this).removeClass('active');
				// Slide up only the content of other open accordions
				outerBox.find('.accordion').not(target).children('.accordion-content').slideUp(300);
				// Toggle the accordion content of the clicked one
				var accordionContent = $(this).next('.accordion-content');
				if (accordionContent.is(':visible')) {
					accordionContent.slideUp(300);
				} else {
					target.addClass('active-block');
					accordionContent.slideDown(300);
				}
			});
		}
	} 
	 /*---====================---coreit Swiper Active---======================---*/ 
	 function coreit_theme_swiper_carousel() {  
		// Check if we're in Elementor editor
		if (window.elementorFrontend && elementorFrontend.isEditMode()) {
			// Delay initialization in editor
			setTimeout(function() {
				initSwipers();
			}, 100);
		} else {
			document.addEventListener('DOMContentLoaded', function() {
				initSwipers();
			});
		}
		
		function initSwipers() {
			// Initialize thumb galleries first
			const thumbsElements = document.querySelectorAll('.swiper_thumbs');
			const thumbsInstances = {};
			
			// Initialize all thumb swipers first
			thumbsElements.forEach(function(thumbElement) {
				const thumbId = thumbElement.id;
				const mainId = thumbElement.getAttribute('data-main-id');
				if (!thumbId || !mainId) return;
				
				const thumbOptions = JSON.parse(thumbElement.getAttribute('data-swiper') || '{}');
				const thumbSwiper = new Swiper(thumbElement, {
					...thumbOptions,
					watchSlidesProgress: true,
					on: {
						init: function() {
							this.update();
						}
					}
				});
				
				// Store the thumb swiper instance for later use
				thumbsInstances[mainId] = thumbSwiper;
			});
			
			// Initialize main swipers with thumbs if needed
			const swiperElements = document.querySelectorAll('.swiper_container');
			swiperElements.forEach(function(swiperElement) {
				// Destroy existing Swiper instances if any
				if (swiperElement.swiper) {
					swiperElement.swiper.destroy();
				}
				
				// Get main swiper options and ID
				const swiperOptions = JSON.parse(swiperElement.getAttribute('data-swiper') || '{}');
				const mainId = swiperElement.id;
				
				// Check if this swiper has a corresponding thumb swiper
				if (thumbsInstances[mainId]) {
					// Connect to thumbs swiper
					swiperOptions.thumbs = {
						swiper: thumbsInstances[mainId]
					};
				}
				
				// Initialize the main swiper
				const mySwiper = new Swiper(swiperElement, {
					...swiperOptions,
					on: {
						init: function() {
							this.update();
						}
					}
				});
				
				// Autoplay controls
				if (swiperOptions.autoplay) {
					swiperElement.addEventListener('mouseenter', function() {
						mySwiper.autoplay.stop();
					});
					
					swiperElement.addEventListener('mouseleave', function() {
						mySwiper.autoplay.start();
					});
				}
			});
		}
	}
	coreit_theme_swiper_carousel();
	
	/*---====================---Counter---======================---*/
	   function coreit_funfact() {
        $(window).on('scroll', function() {
            $('.count-text').each(function() {
                if (coreit_isElementInViewport($(this)) && $(this).data('counted') !== 'true') {
                    $(this)
                        .data('counted', 'true')
                        .prop("Counter", 0)
                        .animate({
                            Counter: $(this).text()
                        }, {
                            duration: 2000,
                            easing: "swing",
                            step: function(now) {
                                now = Number(Math.ceil(now)).toLocaleString('en');
                                $(this).text(now);
                            },
                        });
                }
            });
        });
    }
	  // Function to check if an element is in the viewport
	  function coreit_isElementInViewport(el) {
        var rect = el[0].getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
	/*---====================---Counter---======================---*/
    /*---====================---coreit Tab---======================---*/ 
	function coreit_tab() {
		if ($('.coreit_tab').length) {
			$('.coreit_tab').each(function () {
				var $tabContainer = $(this);
				var widgetId = $tabContainer.data('widget-id');
				var hoverEnabled = $tabContainer.hasClass('onhover');
				var eventHandler = hoverEnabled ? 'mouseover' : 'click';
	
				function setActiveTab(tabId) {
					var $target = $tabContainer.find(tabId);
					$tabContainer.find('.showcase_tabs_btns .s_tab_btn , .price_btn_s .s_tab_btn').removeClass('active');
					$tabContainer.find('[data-tab="' + tabId + '"]').addClass('active');
					$tabContainer.find('.s_tabs_content .s_tab').removeClass('active-tab show');
					$target.addClass('active-tab show');
				}
	
				// Check for stored active tab or default to the first tab
				var activeTab = localStorage.getItem('activeTab-' + widgetId) || $tabContainer.find('.showcase_tabs_btns .s_tab_btn:first, .price_btn_s .s_tab_btn:first').attr('data-tab');
				setActiveTab(activeTab);
	
				$tabContainer.find('.showcase_tabs_btns .s_tab_btn , .price_btn_s .s_tab_btn').on(eventHandler, function (e) {
					e.preventDefault();
					var tabId = $(this).attr('data-tab');
					setActiveTab(tabId);
					localStorage.setItem('activeTab-' + widgetId, tabId);
				});
			});
		}
	}
	
	function coreit_price_tab() {
		jQuery(document).ready(function($) {
			function initializeTabs(containerClass, contentClass) {
				var $container = $(containerClass);
				var $tabs = $container.find('.price_box_tab');
				var $contents = $('.price_box_right_content').find(contentClass);
				var storageKey = 'activeTabIndex_' + containerClass.replace('.', '');
	
				function setActiveTab(index) {
					$tabs.removeClass('active');
					$contents.removeClass('active');
					$tabs.eq(index).addClass('active');
					$contents.eq(index).addClass('active');
					localStorage.setItem(storageKey, index);
				}
	
				// Get the stored index or default to 0, and ensure it's within bounds
				var activeIndex = parseInt(localStorage.getItem(storageKey) || '0');
				activeIndex = isNaN(activeIndex) || activeIndex < 0 || activeIndex >= $tabs.length ? 0 : activeIndex;
	
				// Set initial active tab
				setActiveTab(activeIndex);
	
				// Click event handler
				$tabs.on('click', function() {
					var index = $(this).index();
					setActiveTab(index);
				});
			}
	
			// Initialize tabs for both containers
			initializeTabs('.price_box_left_content.one', '.price_box_tab_content.style_one');
			initializeTabs('.price_box_left_content.two', '.price_box_tab_content.style_two');
		});
	}
    /*---====================---coreit Tab---======================---*/
  	/*---====================---Load More Posts---======================---*/ 
	function coreit_post_ajax() {
		$('.ajax_posts_enabled').on('click', '.pagination-area .next', function(e) {
			e.preventDefault();
			if ($(this).data('requestRunning')) {
				return;
			}
			$(this).data('requestRunning', true);
			var $ser_post_list = $('.ajax_container'),
				$paginationser = $(this).parents('.pagination-area'),
				$parent = $(this).parent();
			// Add the loader
			$ser_post_list.append('<div class="loader"><span class="loader-inner"></span></div>');
			$parent.addClass('loader');
			$.get($(this).attr('href'), function(response) {
				var $contentser = $(response).find('.ajax_container').children('.post-ajax-wrapper'),
					ser_pagination = $(response).find('.pagination-area').html();
				$paginationser.html(ser_pagination);
				// Add a fade-in transition to the new posts
				$contentser.css('opacity', 0);
				$ser_post_list.append($contentser);
				$contentser.imagesLoaded(function() {
					$contentser.animate({ opacity: 1 }, 500); // Fade-in duration in milliseconds
					$paginationser.find('.next').data('requestRunning', false);
					$parent.removeClass('loader');
					$('.loader').remove(); // Remove the loader
				});
			});
		});
	}
	/*---====================---Load More portfolio---======================---*/ 
	function coreit_portfolio_ajax() {
		$('.ajax_portfolios_enabled').on('click', '.pagination-area .next', function(e) {
			e.preventDefault();
			if ($(this).data('requestRunning')) {
				return;
			}
			$(this).data('requestRunning', true);
			var $ser_post_list = $('.portfolio_container'),
				$paginationser = $(this).parents('.pagination-area'),
				$parent = $(this).parent();
			// Add the loader
			$ser_post_list.append('<div class="loader"><span class="loader-inner"></span></div>');
			$parent.addClass('loader');
			$.get($(this).attr('href'), function(response) {
				var $contentser = $(response).find('.portfolio_container').children('.portfolio-wrapper'),
					ser_pagination = $(response).find('.pagination-area').html();
				$paginationser.html(ser_pagination);
				// Add a fade-in transition to the new posts
				$contentser.css('opacity', 0);
				$ser_post_list.append($contentser);
				$contentser.imagesLoaded(function() {
					$contentser.animate({ opacity: 1 }, 500); // Fade-in duration in milliseconds
					$paginationser.find('.next').data('requestRunning', false);
					$parent.removeClass('loader');
					$('.loader').remove(); // Remove the loader
				});
			});
		});
	}
	/*---====================---Load More Service---======================---*/ 
	function coreit_service_ajax() {
		$('.ajax_services_enabled').on('click', '.pagination-area .next', function(e) {
			e.preventDefault();
			if ($(this).data('requestRunning')) {
				return;
			}
			$(this).data('requestRunning', true);
			var $ser_post_list = $('.service_container'),
				$paginationser = $(this).parents('.pagination-area'),
				$parent = $(this).parent();
			// Add the loader
			$ser_post_list.append('<div class="loader"><span class="loader-inner"></span></div>');
			$parent.addClass('loader');
			$.get($(this).attr('href'), function(response) {
				var $contentser = $(response).find('.service_container').children('.service-wrapper'),
					ser_pagination = $(response).find('.pagination-area').html();
				$paginationser.html(ser_pagination);
				// Add a fade-in transition to the new posts
				$contentser.css('opacity', 0);
				$ser_post_list.append($contentser);
				$contentser.imagesLoaded(function() {
					$contentser.animate({ opacity: 1 }, 500); // Fade-in duration in milliseconds
					$paginationser.find('.next').data('requestRunning', false);
					$parent.removeClass('loader');
					$('.loader').remove(); // Remove the loader
				});
			});
		});
	}
	/*---====================---Load More team---======================---*/ 
	function coreit_team_ajax() {
		$('.ajax_teams_enabled').on('click', '.pagination-area .next', function(e) {
			e.preventDefault();
			if ($(this).data('requestRunning')) {
				return;
			}
			$(this).data('requestRunning', true);
			var $ser_post_list = $('.team_container'),
				$paginationser = $(this).parents('.pagination-area'),
				$parent = $(this).parent();
			// Add the loader
			$ser_post_list.append('<div class="loader"><span class="loader-inner"></span></div>');
			$parent.addClass('loader');
			$.get($(this).attr('href'), function(response) {
				var $contentser = $(response).find('.team_container').children('.team-wrapper'),
					ser_pagination = $(response).find('.pagination-area').html();
				$paginationser.html(ser_pagination);
				// Add a fade-in transition to the new posts
				$contentser.css('opacity', 0);
				$ser_post_list.append($contentser);
				$contentser.imagesLoaded(function() {
					$contentser.animate({ opacity: 1 }, 500); // Fade-in duration in milliseconds
					$paginationser.find('.next').data('requestRunning', false);
					$parent.removeClass('loader');
					$('.loader').remove(); // Remove the loader
				});
			});
		});
	}	
    /*---====================---Load More Posts---======================---*/ 
	   /*---====================---back-to-top---======================---*/
	   if ($('.prgoress_indicator path').length) {
		var progressPath = document.querySelector('.prgoress_indicator path');
		var pathLength = progressPath.getTotalLength();
		progressPath.style.transition = progressPath.style.WebkitTransition = 'none';
		progressPath.style.strokeDasharray = pathLength + ' ' + pathLength;
		progressPath.style.strokeDashoffset = pathLength;
		progressPath.getBoundingClientRect();
		progressPath.style.transition = progressPath.style.WebkitTransition = 'stroke-dashoffset 10ms linear';
	
		var updateProgress = function() {
			var scroll = $(window).scrollTop();
			var height = $(document).height() - $(window).height();
			var progress = pathLength - (scroll * pathLength / height);
			progressPath.style.strokeDashoffset = progress;
		};
	
		updateProgress();
		$(window).on('scroll', updateProgress);
	
		var offset = 250;
		var duration = 550;
		jQuery(window).on('scroll', function() {
			if (jQuery(this).scrollTop() > offset) {
				jQuery('.prgoress_indicator').addClass('active-progress');
			} else {
				jQuery('.prgoress_indicator').removeClass('active-progress');
			}
		});
	
		jQuery('.prgoress_indicator').on('click', function(event) {
			event.preventDefault();
			jQuery('html, body').animate({
				scrollTop: 0
			}, duration);
			return false;
		});
	}
	
    /*---====================---back-to-top---======================---*/
	  /*---====================---Sticky Menu---======================---*/
	  var header = $('.sticky_header_area');
	  var win = $(window);
	  win.on('scroll', function() {
		  var scroll = win.scrollTop();
		  if (scroll < 200) {
			  header.removeClass('fixed-header');
		  } else {
			  header.addClass('fixed-header');
		  }
	  });
	  // Add smooth transition effect for sticky header
	  $('.sticky_header_area').css({
		  'transition': 'all 0.43s ease-in-out', // Adjust the duration and timing function as needed
	  });
	  /*---====================---Sticky Menu---======================---*/
	  /*---====================---Sticky Menu---======================---*/
	  function initializecoreitModals() {
		var $modal = $(".modal");
		var $triggers = $(".trigger");
		var $closeButton = $(".close-button");
		function openModal() {
			$modal.addClass("show-modal");
		}
		function closeModal() {
			$modal.removeClass("show-modal");
		}
		function windowOnClick(event) {
			if ($(event.target).is($modal)) {
				closeModal();
			}
		}
		$triggers.off("click").on("click", openModal);
		$closeButton.off("click").on("click", closeModal);
		$(window).off("click").on("click", windowOnClick);
	}	
	  /*---====================---Sticky Menu---======================---*/ 
	  jQuery(document).ready(function($) {
		if (typeof $.fn.magnificPopup === 'undefined') {
			console.log('Magnific Popup is not loaded');
		} else {
			console.log('Magnific Popup is loaded');
		}
		
		$('.video_box_youtube').magnificPopup({
			type: 'iframe',
			midClick: true,
			removalDelay: 300,
			mainClass: 'mfp-fade',
			closeOnBgClick: true,
			showCloseBtn: true, 
		});
	
		$('.video_box').on('click', function() {
			$.magnificPopup.open({
				items: {
					src: '#only-video-popup-' + $(this).closest('.elementor-element').data('id')
				}, 
				preloader: true,
				type: 'inline',
				midClick: true,
				removalDelay: 300,
				mainClass: 'mfp-fade',
				closeOnBgClick: false,
				showCloseBtn: false,
				callbacks: {
					open: function() {
						var $popupContent = this.content;
						$popupContent.find('.popup-close-btn').on('click', function() {
							$.magnificPopup.close();
						});
					}
				} 
			});
		});
	});
	
	/*---====================---Before After Gammery---======================---*/ 
	function coreit_before_after_gallery_popup() {
        $('.before-after-popup-btn').on('click', function(e) {
            e.preventDefault();
            var $galleryPopup = $(this).siblings('.before_after_gallery_box').find('.before-after-popup');
            if ($galleryPopup.length) {
                $galleryPopup.magnificPopup({
                    delegate: 'a',
                    type: 'image',
                    gallery: {
                        enabled: true
                    },
                    mainClass: 'mfp-fade'
                }).magnificPopup('open');
            }
        });
    }
/*---====================---Before After Gammery---======================---*/  
	 /*---====================---Portfolio Filter---======================---*/ 
	 function coreit_grid_filter_layout() {
		if ($('.project_container').length) {
			$('.project_container').isotope({
				layoutMode: 'masonry',
				itemSelector: '.project-wrapper',
				transitionDuration: '1s',
			});
		}
		if ($('.project_filter').length) {
			$('.project_filter').each(function() {
				var $filter = $(this);
				var $container = $filter.closest('.portfolio_post_section').find('.project_container');
				// filter items on button click
				$filter.on('click', 'li', function() {
					var filterValue = $(this).attr('data-filter');
					$container.isotope({ filter: filterValue });
					$filter.find('li').removeClass('current');
					$(this).addClass('current');
				});
				// Set first filter button as active by default, or use the one with 'current' class
				var $currentFilter = $filter.find('li.current');
				if ($currentFilter.length === 0) {
					$currentFilter = $filter.find('li:first-child');
				}
				$currentFilter.addClass('current');
				var currentFilterValue = $currentFilter.attr('data-filter');
				$container.isotope({ filter: currentFilterValue });
			});
		}
	}

	function coreit_progressbar() {
		const progressBars = $(".progressbar");

progressBars.each(function () {
    const $bar = $(this);
    const $circle = $bar.find(".progress_did");
    const $text = $bar.find(".progress-text");
    const percentage = $bar.data("percentage");
    const radius = 45; // Circle radius
    const circumference = 2 * Math.PI * radius;

    // Calculate stroke offset
    const offset = circumference - (circumference * percentage) / 100;

    // Apply stroke offset
    $circle.css("stroke-dashoffset", offset);

    // Calculate the position of the text
    const angle = (360 * percentage) / 100 - 90; // -90 to start from top
    const radians = (angle * Math.PI) / 180;

    // Calculate position with fine-tuned offsets
    const x = radius * Math.cos(radians) + 50; // Centered at 50, 50
    const y = radius * Math.sin(radians) + 50;
    
    // Fine-tune offsets for alignment
    const xOffset = -5; // Slightly more left
    const yOffset = -3; // Slightly more up

    // Update text position
    $text.css({
        left: `calc(${x}% + ${xOffset}px)`,
        top: `calc(${y}% + ${yOffset}px)`
    });

    // Adjust margin-left for progress-text if percentage is above 95%
	if (percentage > 95) {
        $text.css({
            "margin-left": "-20px",
            "padding-top": "10px"
        });
    }
});

	}
	

	

    /*---====================---Mouse Mover---======================---*/ 
	(function () {
		const links = document.querySelectorAll('.hover-me');
		const cursor = document.querySelector('.poniter-me');
		const animateit = function (e) {
			const hoverAnim = this.querySelector('.hover-anim');
			const { offsetX: x, offsetY: y } = e;
			const { offsetWidth: width, offsetHeight: height } = this;
			const move = 25;
			const xMove = (x / width) * (move * 2) - move;
			const yMove = (y / height) * (move * 2) - move;
			hoverAnim.style.transform = `translate(${xMove}px, ${yMove}px)`;
			if (e.type === 'mouseleave') {
				hoverAnim.style.transform = '';
			}
		};
		const editCursor = e => {
			cursor.style.left = `${e.clientX}px`;
			cursor.style.top = `${e.clientY}px`;
		};
		links.forEach(link => {
			link.addEventListener('mousemove', animateit);
			link.addEventListener('mouseleave', animateit);
		});
		window.addEventListener('mousemove', editCursor);
		document.querySelectorAll('a , button , .next , .luxsearch , .prev , #category_filter li , .btn , input[type=submit] , .theme_btn , .option-panel-toggle , .button , .pointer-mode').forEach(el => {
			el.addEventListener('mouseover', () => {
				const color = getComputedStyle(el).color; // Get the color of the hovered element
				cursor.style.backgroundColor = color; // Apply the color to the cursor
				cursor.classList.add('poniter-me-active');
			});
			el.addEventListener('mouseout', () => {
				cursor.classList.remove('poniter-me-active');
				cursor.style.backgroundColor = ''; // Reset the cursor color when the mouse leaves
			});
		});
		document.querySelectorAll('.hover-me').forEach(element => {
			element.addEventListener('mouseover', () => {
				element.classList.remove('play');
			});
		});
	})();
	/*---====================---progress casestudy---======================---*/ 
	function initializeProgress() {
		const containers = document.querySelectorAll('.case-progress');
		
		containers.forEach(container => {
			const percentage = container.dataset.percentage;
			const circle = container.querySelector('.progress-circle');
			const text = container.querySelector('.progress-text');
			
			// Update text
			text.textContent = percentage + '%';
			
			// Calculate stroke-dashoffset
			const circumference = 2 * Math.PI * 18;  // Adjusted radius
			const offset = circumference - (percentage / 100) * circumference;
			circle.style.strokeDashoffset = offset;
		});
	}

	// Initialize on load
	initializeProgress();

	// Function to update percentage
	function updatePercentage(newPercentage) {
		const container = document.querySelector('.case-progress');
		container.dataset.percentage = newPercentage;
		initializeProgress();
	}
	// 

	function coreit_textimonial_swiper_slider(){
		const swiper = new Swiper('.text-swiper-container', {
			effect: 'fade', // Use fade transition
			loop: true, // Enable looping of slides
			autoplay: {
			  delay: 3000, // Set autoplay delay (in ms)
			}, 
			navigation: {
			  nextEl: '.testidiff-button-next',
			  prevEl: '.testidiff-button-prev',
			},
		  });
		  
	}
	function coreit_hover_list(){
	$('.l_box').on('mouseenter', function () {
		$('.l_box').removeClass('active');
		$(this).addClass('active');
	});
}
	// Animated Image
	function animatedwidget() {
		jQuery(document).ready(function($) {
			$('.animated-image-widget').each(function() {
				const animationType = $(this).data('animation-type');
				const animationSpeed = $(this).data('animation-speed');
				const animationIteration = $(this).data('animation-iteration');
				$(this).find('img').addClass(animationType)
					.css({
						'animation-duration': animationSpeed + 'ms',
						'--animation-iteration': animationIteration
					});
			});
		});
	}
	// progress bar
	function progressbartwo() {
		jQuery(document).ready(function($) {
			$('.progress-v2').each(function() {
				var progressBar = $(this);
				var percentage = parseInt(progressBar.data('percentage'), 10);
				var percentageDisplay = progressBar.closest('.progress-bar-widget').find('.progress-percentage');
		
				// Animate the progress bar
				setTimeout(function() {
					progressBar.css('width', percentage + '%');
					var start = 0;
					var interval = setInterval(function() {
						if (start >= percentage) {
							clearInterval(interval);
						} else {
							start++;
							percentageDisplay.text(start + '%');
						}
					}, 15); // Adjust speed of animation
				}, 500);
			});
		});
	}
	// hover slider
	var initHoverSlider = function() {
        $('.hoverslidercstudy-name').on('mouseenter', function() {
            var index = $(this).index() + 1;
            $('.hoverslidercstudy-name.active').removeClass('active');
            $('.hoverslidercstudy-images li.show').removeClass("show");
            $('.hoverslidercstudy-images li:nth-child(' + index + ')').addClass("show");
            $(this).addClass('active');
        });

        // Trigger the first item by default
        $('.hoverslidercstudy-name:nth-child(1)').trigger('mouseenter');
    };

	/*---====================---Elementor---======================---*/ 
    $(window).on('elementor/frontend/init', function() { 
			// Carousels
            elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-slider-builder.default', coreit_theme_swiper_carousel);  
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-before-after-widget.default', coreit_theme_swiper_carousel);  
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-before-after-widget-v2.default', coreit_theme_swiper_carousel);  
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-before-after-widget.default', coreit_before_after_gallery_popup);  
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-slider-1.default', coreit_theme_swiper_carousel);
			//  scroll text
		 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-client-carousel-widget.default', coreit_theme_swiper_carousel); 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-tab-with-content-v1.default', coreit_theme_swiper_carousel); 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-image-carousel-widget.default', coreit_theme_swiper_carousel); 
			// Content
            elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-contact-form-v1.default', coreit_tab);  
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-fun-facts-box.default', coreit_funfact);   
			// Service Post
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-service-carousel-v1.default', coreit_theme_swiper_carousel);
			elementorFrontend.hooks.addAction('frontend/element_ready/coreit-service-carousel-v2.default', coreit_theme_swiper_carousel);
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-service-grid-v1.default', coreit_service_ajax);
			elementorFrontend.hooks.addAction('frontend/element_ready/steelthemes-service-grid-v2.default', coreit_service_ajax);
			// Blog Post
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-blog-carousel-v1.default', coreit_theme_swiper_carousel);
			elementorFrontend.hooks.addAction('frontend/element_ready/steelthemes-blog-carousel-v2.default', coreit_theme_swiper_carousel);
 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-blog-grid-v1.default', coreit_post_ajax);
            // portfolio Post
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-portfolio-tab-v2.default', coreit_tab);
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-Form-v1 .default', coreit_tab);
			 
            elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-portfolio-carousel-v1.default', coreit_theme_swiper_carousel);
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-portfolio-grid-v1.default', coreit_portfolio_ajax);
			// team carousel
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-team-carousel-v1.default', coreit_theme_swiper_carousel);
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-faqs-v1.default', coreit_faqsall);
			// Image Carousel 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-team-grid-v1.default', coreit_team_ajax);
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-contact-form-v1.default', initializecoreitModals);
			// price tan
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-price-tab-v2.default', coreit_tab); 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-price-tab-v3.default', coreit_tab); 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-price-tab-v2.default', coreit_price_tab); 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-price-tab-v3.default', coreit_price_tab); 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-testimonial-carousel-v1.default', coreit_theme_swiper_carousel);
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-testimonial-carousel-v2.default', coreit_theme_swiper_carousel);
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-testimonial-carousel-v3.default', coreit_theme_swiper_carousel);
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-deals-v1.default', coreit_theme_swiper_carousel); 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-frequently-bought-together.default', coreit_theme_swiper_carousel); 
			
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-product-deals-v1.default', coreit_theme_swiper_carousel); 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-product-carousel-v1.default', coreit_theme_swiper_carousel);
			// portfolio
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-portfolio-post-v1.default', coreit_grid_filter_layout);
			//  progressbar 
			elementorFrontend.hooks.addAction('frontend/element_ready/trimprim-progress-bar-v1.default', coreit_progressbar);

			// case stuy
			elementorFrontend.hooks.addAction('frontend/element_ready/steelthemes-case-studies.default', initializeProgress);
			elementorFrontend.hooks.addAction('frontend/element_ready/steelthemes-case-studies-v2.default', coreit_theme_swiper_carousel);
			//  testimonial 
				elementorFrontend.hooks.addAction('frontend/element_ready/steelthemes-testimonial-carousel-v2.default', coreit_textimonial_swiper_slider);
			//	Hover List
			elementorFrontend.hooks.addAction('frontend/element_ready/steelthemes-list-v1.default', coreit_hover_list);
			//	Animated Widget
			elementorFrontend.hooks.addAction('frontend/element_ready/animated_image.default', animatedwidget);
			//	Progress nbar
			elementorFrontend.hooks.addAction('frontend/element_ready/Progress_bar_v2.default', progressbartwo);
			// timeline 
			elementorFrontend.hooks.addAction('frontend/element_ready/coreit-timeline-v1.default', coreit_theme_swiper_carousel);
						// Hover Slider
			elementorFrontend.hooks.addAction('frontend/element_ready/hoversliders_study.default', initHoverSlider);

			
			
    });
	/*---====================---Sidebar show hide ** Start---======================---*/ 
	  function coreit_sidebar() {
        $(document).ready(function(){
            // Check if the sidebar state is stored in localStorage
            var isSidebarHidden = localStorage.getItem('sidebarHidden'); 
            // If the sidebar state is stored and is true, hide the sidebar
            if (isSidebarHidden && isSidebarHidden === 'true') {
                $("body.showing-sidebar").addClass("sidebar-hidden");
            } 
            $(".coreit_filter_btn").click(function(){
                // Toggle the sidebar state
                $("body.showing-sidebar").toggleClass("sidebar-hidden");  
                // Store the current sidebar state in localStorage
                var isHidden = $("body").hasClass("sidebar-hidden");
                localStorage.setItem('sidebarHidden', isHidden);
            });
        }); 
    }
	/*---====================---Progressbar---======================---*/ 
	function coreit_progress_bar() {
		var progressBars = document.querySelectorAll('.sold-done');
		progressBars.forEach(function(bar) {
			var percent = parseFloat(bar.getAttribute('data-done'));
			bar.style.width = percent + '%';
			bar.style.opacity = 1;
		});
    }
	/*---====================---Megamenu---======================---*/
	function coreit_adjustMegaMenu() {
		// Only run the function if the window width is at least 1200px
		if (window.innerWidth >= 1200) {
			const navbarNav = document.querySelector('.navbar_nav');
			const megaMenuItems = document.querySelectorAll('.navbar_nav > li.mega_menu , .navbar_nav > li.flex_menu_activate.menu_fullwidth');
			
			megaMenuItems.forEach(item => {
				const subMenu = item.querySelector('.sub-menu');
				if (subMenu) {
					const itemRect = item.getBoundingClientRect();
					// Set the sub-menu position and width
					subMenu.style.left = `-${itemRect.left}px`;
					subMenu.style.width = `${window.innerWidth}px`;
					subMenu.style.maxWidth = `${window.innerWidth}px`;
					
					// Add class that applies display: flex !important
					subMenu.classList.add('submenu-visible');
				}
			});
		} else {
			// Reset styles for screens smaller than 1200px
			const subMenus = document.querySelectorAll('.navbar_nav .sub-menu');
			subMenus.forEach(subMenu => {
				subMenu.style.left = '';
				subMenu.style.width = '';
				subMenu.style.maxWidth = '';
				subMenu.classList.remove('submenu-visible');
			});
		}
	}
	
	// Run on page load (DOMContentLoaded) and window resize
	window.addEventListener('DOMContentLoaded', function() {
		setTimeout(coreit_adjustMegaMenu, 500);  // Delay to ensure all elements are ready
	});
	window.addEventListener('resize', coreit_adjustMegaMenu);

	
	/*---====================---jQuery Ready---======================---*/ 
    jQuery(document).on('ready', function () { 
        coreit_tab(); 
		coreit_progress_bar(); 
		coreit_post_ajax();
		coreit_portfolio_ajax(); 
		initializecoreitModals();
		coreit_team_ajax(); 
		coreit_faqsall();
		coreit_year_update();  
		coreit_before_after_gallery_popup();  
		coreit_sidebar();
		coreit_grid_filter_layout(); 
		coreit_progressbar();
		coreit_textimonial_swiper_slider();
		progressbartwo();
		initHoverSlider();
    }); 
	$(document.body).trigger('wc_fragment_refresh'); 
})(jQuery);
