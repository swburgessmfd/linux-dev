(function($) {
	"use strict";
	
	// Check if we're in Elementor editor
	const isElementorEditor = function() {
		return window.elementorFrontend && elementorFrontend.isEditMode();
	};
	
	// Utility function to check if element exists
	const elementExists = function(selector) {
		return $(selector).length > 0;
	};
	
	// Debounce function to limit execution frequency
	const debounce = function(func, wait) {
		let timeout;
		return function() {
			const context = this;
			const args = arguments;
			clearTimeout(timeout);
			timeout = setTimeout(function() {
				func.apply(context, args);
			}, wait);
		};
	};
	
	// ----- PRELOADER & PAGE LOADING -----
	function initPreloader() {
		$(window).on("load", function() {
			$("#preloader-active").delay(1000).fadeOut("slow");
		});
		
		if (elementExists('.loader-wrap')) {
			$('.loader-wrap').delay(1000).fadeOut("slow");
		}
	}
	
	// ----- CARD SERVICE HOVER EFFECT -----
	function initCardService() {
		if (!elementExists('.cardService.one')) return;
		
		$('.cardService.one').hover(function() {
			var boxInfoHeight = $(this).find('.box-inner-info')[0].scrollHeight;
			$(this).find('.box-inner-info').css('height', boxInfoHeight + 'px');
		}, function() {
			$(this).find('.box-inner-info').css('height', '0');
		});
	}
	
	// ----- HEADER DROPDOWN BUTTONS -----
	function initHeaderDropdown() {
		// Add dropdown buttons to navbar items
		if (elementExists('.navbar_nav li.dropdown ul')) {
			$('.navbar_nav li.dropdown > a').append('<div class="dropdown-btn trans"><span class="coreits-down1"></span></div>');
		}
		
		if (elementExists('.navbar_nav li.mega_menu ul')) {
			$('.navbar_nav li.mega_menu > a').append('<div class="dropdown-btn trans"><span class="coreits-down1"></span></div>');
		}
		
		// Adjust submenu position
		if (elementExists('.navbar_nav > li:not(.mega_menu)')) {
			$('.navbar_nav > li:not(.mega_menu)').hover(function() {
				var submenu = $(this).find('.navbar_nav > li > .sub-menu');
				var liHeight = $(this).outerHeight();
				submenu.addClass('active').css('top', liHeight);
			}, function() {
				$(this).find('.navbar_nav > li > .sub-menu').removeClass('active');
			});
		}
	}
	
	// ----- PROGRESS INDICATOR (BACK TO TOP) -----
	function initProgressIndicator() {
		if (!elementExists('.prgoress_indicator path')) return;
		
		const progressPath = document.querySelector('.prgoress_indicator path');
		const pathLength = progressPath.getTotalLength();
		
		// Initialize path
		progressPath.style.transition = progressPath.style.WebkitTransition = 'none';
		progressPath.style.strokeDasharray = pathLength + ' ' + pathLength;
		progressPath.style.strokeDashoffset = pathLength;
		progressPath.getBoundingClientRect();
		progressPath.style.transition = progressPath.style.WebkitTransition = 'stroke-dashoffset 10ms linear';
		
		const updateProgress = debounce(function() {
			const scroll = $(window).scrollTop();
			const height = $(document).height() - $(window).height();
			const progress = pathLength - (scroll * pathLength / height);
			progressPath.style.strokeDashoffset = progress;
		}, 10);
	
		updateProgress();
		$(window).on('scroll', updateProgress);
	
		const offset = 250;
		
		$(window).on('scroll', function() {
			if ($(this).scrollTop() > offset) {
				$('.prgoress_indicator').addClass('active-progress');
			} else {
				$('.prgoress_indicator').removeClass('active-progress');
			}
		});
	
		// Smooth scroll to top
		$('.prgoress_indicator').on('click', function(e) {
			e.preventDefault();
			window.scrollTo({
				top: 0,
				behavior: 'smooth'
			});
			return false;
		});
	}
	
	// ----- MOBILE MENU -----
	function initMobileMenu() {
		if (!elementExists('.mobile_menu_box')) return;
		
		// Toggle mobile menu
		$('.navbar_togglers').on('click', function() {
			$('body').toggleClass('mobile_menu_box-visible');
		});
		
		// Close mobile menu
		$('.mobile_menu_box .menu-backdrop, .mobile_menu_box .close-btn').on('click', function() {
			$('body').removeClass('mobile_menu_box-visible');
		});
		
		// Copy navigation to mobile menu
		if (elementExists('.navbar_nav')) {
			var mobileMenuContent = $('.navbar_nav').html();
			$('.mobile_menu_box .navbar_nav').append(mobileMenuContent);
		}
		
		// Mobile dropdown handling
		var $offCanvasNav = $(".mobile_menu_box"),
			$offCanvasNavSubMenu = $offCanvasNav.find(".sub-menu");
		
		// Add toggle button to submenus
		$offCanvasNavSubMenu.parent().prepend('<span class="dropdown-btn"><i class="coreits-down-arrow"></i></span>');
		
		// Close submenus initially
		$offCanvasNavSubMenu.slideUp();
		
		// Toggle submenus
		$offCanvasNav.on("click", "li a, li .dropdown-btn", function(e) {
			var $this = $(this);
			if (
				$this.parent().attr("class") && $this.parent().attr("class").match(/\b(menu-item-has-children|has-children|has-sub-menu|sub-menu|mega_menu)\b/) &&
				($this.attr("href") === "#" || $this.hasClass("dropdown-btn"))
			) {
				e.preventDefault();
				if ($this.siblings("ul:visible").length) {
					$this.parent("li").removeClass("drop-active");
					$this.siblings("ul").slideUp();
				} else {
					$this.parent("li").addClass("drop-active");
					$this.closest("li").siblings("li").removeClass("drop-active").find("li").removeClass("drop-active");
					$this.closest("li").siblings("li").find("ul:visible").slideUp();
					$this.siblings("ul").slideDown();
				}
			}
		});
	}
	
	// ----- SEARCH SIDEBAR -----
	function initSearchSidebar() {
		if (!elementExists('.luxsearch')) return;
		
		$('.enableluxsearch').on('click', function() {
			$('.search_sidebar').toggleClass('search_sidebar-visible');
		});
		
		$('.search_sidebar .close-btn, .search_sidebar .menu-backdrop').on('click', function() {
			$('.search_sidebar').removeClass('search_sidebar-visible');
		});
	}
	
	// ----- CART HANDLING -----
	function initCartHandling() {
		// Mini cart icon click
		$(document).on('click', '.micoreit-cart-icon', function() {
			$('body').addClass('open_cart');
		});
		
		// Close cart button click
		$(document).on('click', '.cart_box .box-cart-close, .cart_box .overlay_box', function() {
			$('body').removeClass('open_cart');
		});
	}
	
	// ----- LOADING SKELETON -----
	function initSkeletonLoading() {
		var duration = 1000;
		var timer;
		
		function hideSkeletonLoading() {
			$(".sketch-loading").hide();
		}
		
		function showSkeletonLoading() {
			$(".sketch-loading").show();
		}
		
		function resetTimer() {
			clearTimeout(timer);
			timer = setTimeout(hideSkeletonLoading, duration);
		}
		
		timer = setTimeout(hideSkeletonLoading, duration);
		
		$(".load_more_jobs, .job_types li label").click(function() {
			showSkeletonLoading();
			resetTimer();
		});
		
		$(".woo_pagination.loadmoreproduct .woocommerce-pagination a").click(function() {
			showSkeletonLoading();
			resetTimer();
		});
	}
	
	// ----- YEAR UPDATE -----
	function coreit_year_update() {
		function updateYear() {
			$('.trimyear').text(new Date().getFullYear());
		}
		
		updateYear();
		setInterval(updateYear, 1000);
	}
	
	// ----- FAQS ACCORDION -----
	function coreit_faqsall() {
		if (!elementExists('.accordion_box')) return;
		
		$(".accordion_box").off('click').on('click', '.question', function() {
			var outerBox = $(this).closest('.accordion_box');
			var target = $(this).closest('.accordion');
			
			// Toggle active class
			$(this).toggleClass('active');
			
			// Close other accordions
			outerBox.find('.accordion').not(target).removeClass('active-block');
			outerBox.find('.accordion .question, .accordion .icon_fq').not(this).removeClass('active');
			outerBox.find('.accordion').not(target).children('.accordion-content').slideUp(300);
			
			// Toggle current accordion
			var accordionContent = $(this).next('.accordion-content');
			if (accordionContent.is(':visible')) {
				accordionContent.slideUp(300);
			} else {
				target.addClass('active-block');
				accordionContent.slideDown(300);
			}
		});
	}
	
	// ----- SWIPER CAROUSEL INITIALIZATION -----
	function coreit_theme_swiper_carousel() {
		// We need to wait a bit longer in editor mode to ensure the elements are fully rendered
		if (isElementorEditor()) {
			setTimeout(function() {
				initSwipers();
			}, 50); // Increased delay in editor mode
		} else {
			if (document.readyState === 'loading') {
				document.addEventListener('DOMContentLoaded', initSwipers);
			} else {
				initSwipers();
			}
		}
		
		function initSwipers() {
			// Skip if Swiper is not loaded
			if (typeof Swiper === 'undefined') {
				console.log('Swiper not loaded yet, retrying...');
				// Try again after a delay
				setTimeout(initSwipers, 200);
				return;
			}
			
			// Initialize thumb galleries first
			const thumbsElements = document.querySelectorAll('.swiper_thumbs');
			const thumbsInstances = {};
			
			// Initialize all thumb swipers first
			thumbsElements.forEach(function(thumbElement) {
				const thumbId = thumbElement.id;
				const mainId = thumbElement.getAttribute('data-main-id');
				if (!thumbId || !mainId) return;
				
				try {
					const thumbOptions = JSON.parse(thumbElement.getAttribute('data-swiper') || '{}');
					const thumbSwiper = new Swiper(thumbElement, {
						...thumbOptions,
						watchSlidesProgress: true,
						on: {
							init: function() {
								this.update();
							}
						}
					});
					
					// Store the thumb swiper instance for later use
					thumbsInstances[mainId] = thumbSwiper;
				} catch (error) {
					console.error('Error initializing thumb swiper:', error);
				}
			});
			
			// Initialize main swipers with thumbs if needed
			const swiperElements = document.querySelectorAll('.swiper_container');
			swiperElements.forEach(function(swiperElement) {
				try {
					// Destroy existing Swiper instances if any
					if (swiperElement.swiper) {
						swiperElement.swiper.destroy();
					}
					
					// Get main swiper options and ID
					let swiperOptions = {};
					try {
						swiperOptions = JSON.parse(swiperElement.getAttribute('data-swiper') || '{}');
					} catch (e) {
						console.error('Invalid swiper options JSON:', e);
					}
					
					const mainId = swiperElement.id;
					
					// Check if this swiper has a corresponding thumb swiper
					if (thumbsInstances[mainId]) {
						// Connect to thumbs swiper
						swiperOptions.thumbs = {
							swiper: thumbsInstances[mainId]
						};
					}
					
					// Initialize the main swiper
					const mySwiper = new Swiper(swiperElement, {
						...swiperOptions,
						on: {
							init: function() {
								this.update();
							}
						}
					});
					
					// Force an update after initialization
					setTimeout(() => {
						if (mySwiper && typeof mySwiper.update === 'function') {
							mySwiper.update();
						}
					}, 100);
					
					// Autoplay controls
					if (swiperOptions.autoplay) {
						swiperElement.addEventListener('mouseenter', function() {
							if (mySwiper && mySwiper.autoplay) {
								mySwiper.autoplay.stop();
							}
						});
						
						swiperElement.addEventListener('mouseleave', function() {
							if (mySwiper && mySwiper.autoplay) {
								mySwiper.autoplay.start();
							}
						});
					}
				} catch (error) {
					console.error('Error initializing swiper:', error);
				}
			});
		}
	}
	
	// ----- COUNTER ANIMATION -----
	function coreit_funfact() {
		const handleCounter = debounce(function() {
			$('.count-text').each(function() {
				if (coreit_isElementInViewport($(this)) && $(this).data('counted') !== 'true') {
					$(this)
						.data('counted', 'true')
						.prop("Counter", 0)
						.animate({
							Counter: $(this).text()
						}, {
							duration: 2000,
							easing: "swing",
							step: function(now) {
								now = Number(Math.ceil(now)).toLocaleString('en');
								$(this).text(now);
							},
						});
				}
			});
		}, 50);
		
		$(window).on('scroll', handleCounter);
		// Initial check
		setTimeout(handleCounter, 100);
	}
	
	// Helper function to check if element is in viewport
	function coreit_isElementInViewport(el) {
		if (!el.length) return false;
		
		var rect = el[0].getBoundingClientRect();
		return (
			rect.top >= 0 &&
			rect.left >= 0 &&
			rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
			rect.right <= (window.innerWidth || document.documentElement.clientWidth)
		);
	}
	
	// ----- TABS -----
	function coreit_tab() {
		if (!elementExists('.coreit_tab')) return;
		
		$('.coreit_tab').each(function() {
			var $tabContainer = $(this);
			var widgetId = $tabContainer.data('widget-id');
			var hoverEnabled = $tabContainer.hasClass('onhover');
			var eventHandler = hoverEnabled ? 'mouseover' : 'click';
	
			function setActiveTab(tabId) {
				var $target = $tabContainer.find(tabId);
				$tabContainer.find('.showcase_tabs_btns .s_tab_btn, .price_btn_s .s_tab_btn').removeClass('active');
				$tabContainer.find('[data-tab="' + tabId + '"]').addClass('active');
				$tabContainer.find('.s_tabs_content .s_tab').removeClass('active-tab show');
				$target.addClass('active-tab show');
			}
	
			// Check for stored active tab or default to the first tab
			var activeTab = localStorage.getItem('activeTab-' + widgetId) || $tabContainer.find('.showcase_tabs_btns .s_tab_btn:first, .price_btn_s .s_tab_btn:first').attr('data-tab');
			setActiveTab(activeTab);
	
			$tabContainer.find('.showcase_tabs_btns .s_tab_btn, .price_btn_s .s_tab_btn').on(eventHandler, function(e) {
				e.preventDefault();
				var tabId = $(this).attr('data-tab');
				setActiveTab(tabId);
				localStorage.setItem('activeTab-' + widgetId, tabId);
			});
		});
	}
	
	// ----- PRICE TABS -----
	function coreit_price_tab() {
		function initializeTabs(containerClass, contentClass) {
			var $container = $(containerClass);
			if (!$container.length) return;
			
			var $tabs = $container.find('.price_box_tab');
			var $contents = $('.price_box_right_content').find(contentClass);
			var storageKey = 'activeTabIndex_' + containerClass.replace('.', '');
	
			function setActiveTab(index) {
				$tabs.removeClass('active');
				$contents.removeClass('active');
				$tabs.eq(index).addClass('active');
				$contents.eq(index).addClass('active');
				localStorage.setItem(storageKey, index);
			}
	
			// Get the stored index or default to 0
			var activeIndex = parseInt(localStorage.getItem(storageKey) || '0');
			activeIndex = isNaN(activeIndex) || activeIndex < 0 || activeIndex >= $tabs.length ? 0 : activeIndex;
	
			// Set initial active tab
			setActiveTab(activeIndex);
	
			// Click event handler
			$tabs.on('click', function() {
				var index = $(this).index();
				setActiveTab(index);
			});
		}
	
		// Initialize tabs for both containers
		initializeTabs('.price_box_left_content.one', '.price_box_tab_content.style_one');
		initializeTabs('.price_box_left_content.two', '.price_box_tab_content.style_two');
	}
	
	// ----- AJAX POSTS LOADING -----
	function coreit_post_ajax() {
		if (!elementExists('.ajax_posts_enabled')) return;
		
		$('.ajax_posts_enabled').on('click', '.pagination-area .next', function(e) {
			e.preventDefault();
			if ($(this).data('requestRunning')) {
				return;
			}
			$(this).data('requestRunning', true);
			var $ser_post_list = $('.ajax_container'),
				$paginationser = $(this).parents('.pagination-area'),
				$parent = $(this).parent();
			
			// Add the loader
			$ser_post_list.append('<div class="loader"><span class="loader-inner"></span></div>');
			$parent.addClass('loader');
			
			$.get($(this).attr('href'), function(response) {
				var $contentser = $(response).find('.ajax_container').children('.post-ajax-wrapper'),
					ser_pagination = $(response).find('.pagination-area').html();
				$paginationser.html(ser_pagination);
				
				// Add a fade-in transition to the new posts
				$contentser.css('opacity', 0);
				$ser_post_list.append($contentser);
				
				$contentser.imagesLoaded(function() {
					$contentser.animate({ opacity: 1 }, 500);
					$paginationser.find('.next').data('requestRunning', false);
					$parent.removeClass('loader');
					$('.loader').remove();
				});
			});
		});
	}
	
	// ----- AJAX PORTFOLIO LOADING -----
	function coreit_portfolio_ajax() {
		if (!elementExists('.ajax_portfolios_enabled')) return;
		
		$('.ajax_portfolios_enabled').on('click', '.pagination-area .next', function(e) {
			e.preventDefault();
			if ($(this).data('requestRunning')) {
				return;
			}
			$(this).data('requestRunning', true);
			var $ser_post_list = $('.portfolio_container'),
				$paginationser = $(this).parents('.pagination-area'),
				$parent = $(this).parent();
			
			// Add the loader
			$ser_post_list.append('<div class="loader"><span class="loader-inner"></span></div>');
			$parent.addClass('loader');
			
			$.get($(this).attr('href'), function(response) {
				var $contentser = $(response).find('.portfolio_container').children('.portfolio-wrapper'),
					ser_pagination = $(response).find('.pagination-area').html();
				$paginationser.html(ser_pagination);
				
				// Add a fade-in transition to the new posts
				$contentser.css('opacity', 0);
				$ser_post_list.append($contentser);
				
				$contentser.imagesLoaded(function() {
					$contentser.animate({ opacity: 1 }, 500);
					$paginationser.find('.next').data('requestRunning', false);
					$parent.removeClass('loader');
					$('.loader').remove();
				});
			});
		});
	}
	
	// ----- AJAX SERVICE LOADING -----
	function coreit_service_ajax() {
		if (!elementExists('.ajax_services_enabled')) return;
		
		$('.ajax_services_enabled').on('click', '.pagination-area .next', function(e) {
			e.preventDefault();
			if ($(this).data('requestRunning')) {
				return;
			}
			$(this).data('requestRunning', true);
			var $ser_post_list = $('.service_container'),
				$paginationser = $(this).parents('.pagination-area'),
				$parent = $(this).parent();
			
			// Add the loader
			$ser_post_list.append('<div class="loader"><span class="loader-inner"></span></div>');
			$parent.addClass('loader');
			
			$.get($(this).attr('href'), function(response) {
				var $contentser = $(response).find('.service_container').children('.service-wrapper'),
					ser_pagination = $(response).find('.pagination-area').html();
				$paginationser.html(ser_pagination);
				
				// Add a fade-in transition to the new posts
				$contentser.css('opacity', 0);
				$ser_post_list.append($contentser);
				
				$contentser.imagesLoaded(function() {
					$contentser.animate({ opacity: 1 }, 500);
					$paginationser.find('.next').data('requestRunning', false);
					$parent.removeClass('loader');
					$('.loader').remove();
				});
			});
		});
	}
	
	// ----- AJAX TEAM LOADING -----
	function coreit_team_ajax() {
		if (!elementExists('.ajax_teams_enabled')) return;
		
		$('.ajax_teams_enabled').on('click', '.pagination-area .next', function(e) {
			e.preventDefault();
			if ($(this).data('requestRunning')) {
				return;
			}
			$(this).data('requestRunning', true);
			var $ser_post_list = $('.team_container'),
				$paginationser = $(this).parents('.pagination-area'),
				$parent = $(this).parent();
			
			// Add the loader
			$ser_post_list.append('<div class="loader"><span class="loader-inner"></span></div>');
			$parent.addClass('loader');
			
			$.get($(this).attr('href'), function(response) {
				var $contentser = $(response).find('.team_container').children('.team-wrapper'),
					ser_pagination = $(response).find('.pagination-area').html();
				$paginationser.html(ser_pagination);
				
				// Add a fade-in transition to the new posts
				$contentser.css('opacity', 0);
				$ser_post_list.append($contentser);
				
				$contentser.imagesLoaded(function() {
					$contentser.animate({ opacity: 1 }, 500);
					$paginationser.find('.next').data('requestRunning', false);
					$parent.removeClass('loader');
					$('.loader').remove();
				});
			});
		});
	}
	
	// ----- STICKY HEADER -----
	function initStickyHeader() {
		var header = $('.sticky_header_area');
		if (!header.length) return;
		
		var win = $(window);
		var lastScrollTop = 0;
		
		// Debounced scroll handler
		var handleScroll = debounce(function() {
			var scroll = win.scrollTop();
			
			// Apply or remove fixed header class
			if (scroll < 200) {
				header.removeClass('fixed-header');
			} else {
				header.addClass('fixed-header');
			}
			
			lastScrollTop = scroll;
		}, 10);
		
		// Add transition effect
		header.css({
			'transition': 'all 0.43s ease-in-out'
		});
		
		win.on('scroll', handleScroll);
	}
	
	// ----- MODALS -----
	function initializecoreitModals() {
		if (!elementExists(".modal")) return;
		
		var $modal = $(".modal");
		var $triggers = $(".trigger");
		var $closeButton = $(".close-button");
		
		function openModal() {
			$modal.addClass("show-modal");
		}
		
		function closeModal() {
			$modal.removeClass("show-modal");
		}
		
		function windowOnClick(event) {
			if ($(event.target).is($modal)) {
				closeModal();
			}
		}
		
		$triggers.off("click").on("click", openModal);
		$closeButton.off("click").on("click", closeModal);
		$(window).off("click.modal").on("click.modal", windowOnClick);
	}
	
	// ----- MAGNIFIC POPUP -----
	function initMagnificPopup() {
		if (typeof $.fn.magnificPopup === 'undefined') {
			return;
		}
		
		// YouTube video popup
		$('.video_box_youtube').magnificPopup({
			type: 'iframe',
			midClick: true,
			removalDelay: 300,
			mainClass: 'mfp-fade',
			closeOnBgClick: true,
			showCloseBtn: true
		});
		
		// Self-hosted video popup
		$('.video_box').on('click', function() {
			$.magnificPopup.open({
				items: {
					src: '#only-video-popup-' + $(this).closest('.elementor-element').data('id')
				},
				preloader: true,
				type: 'inline',
				midClick: true,
				removalDelay: 300,
				mainClass: 'mfp-fade',
				closeOnBgClick: false,
				showCloseBtn: false,
				callbacks: {
					open: function() {
						var $popupContent = this.content;
						$popupContent.find('.popup-close-btn').on('click', function() {
							$.magnificPopup.close();
						});
					}
				}
			});
		});
	}
	
	// ----- BEFORE-AFTER GALLERY POPUP -----
	function coreit_before_after_gallery_popup() {
		if (!elementExists('.before-after-popup-btn')) return;
		
		$('.before-after-popup-btn').on('click', function(e) {
			e.preventDefault();
			var $galleryPopup = $(this).siblings('.before_after_gallery_box').find('.before-after-popup');
			
			if ($galleryPopup.length && typeof $.fn.magnificPopup !== 'undefined') {
				$galleryPopup.magnificPopup({
					delegate: 'a',
					type: 'image',
					gallery: {
						enabled: true
					},
					mainClass: 'mfp-fade'
				}).magnificPopup('open');
			}
		});
	}
	
	// ----- PORTFOLIO FILTER -----
	function coreit_grid_filter_layout() {
		// Initialize isotope for project container if available
		if (elementExists('.project_container') && typeof $.fn.isotope !== 'undefined') {
			$('.project_container').isotope({
				layoutMode: 'masonry',
				itemSelector: '.project-wrapper',
				transitionDuration: '1s'
			});
		}
		
		// Setup project filters
		if (elementExists('.project_filter')) {
			$('.project_filter').each(function() {
				var $filter = $(this);
				var $container = $filter.closest('.portfolio_post_section').find('.project_container');
				
				// Filter items on button click
				$filter.on('click', 'li', function() {
					var filterValue = $(this).attr('data-filter');
					$container.isotope({ filter: filterValue });
					$filter.find('li').removeClass('current');
					$(this).addClass('current');
				});
				
				// Set first filter button as active by default, or use the one with 'current' class
				var $currentFilter = $filter.find('li.current');
				if ($currentFilter.length === 0) {
					$currentFilter = $filter.find('li:first-child');
				}
				$currentFilter.addClass('current');
				var currentFilterValue = $currentFilter.attr('data-filter');
				$container.isotope({ filter: currentFilterValue });
			});
		}
	}
	
	// ----- PROGRESS BAR -----
	function coreit_progressbar() {
		if (!elementExists(".progressbar")) return;
		
		// In editor mode, delay the initialization
		const initDelay = isElementorEditor() ? 50 : 0;
		
		setTimeout(function() {
			$(".progressbar").each(function() {
				try {
					const $bar = $(this);
					const $circle = $bar.find(".progress_did");
					const $text = $bar.find(".progress-text");
					
					// Verify all required elements exist
					if (!$circle.length || !$text.length) return;
					
					const percentage = $bar.data("percentage") || 0;
					const radius = 45; // Circle radius
					const circumference = 2 * Math.PI * radius;
			
					// Calculate stroke offset
					const offset = circumference - (circumference * percentage) / 100;
			
					// Apply stroke offset
					$circle.css("stroke-dashoffset", offset);
			
					// Calculate the position of the text
					const angle = (360 * percentage) / 100 - 90; // -90 to start from top
					const radians = (angle * Math.PI) / 180;
			
					// Calculate position with fine-tuned offsets
					const x = radius * Math.cos(radians) + 50; // Centered at 50, 50
					const y = radius * Math.sin(radians) + 50;
					
					// Fine-tune offsets for alignment
					const xOffset = -5; // Slightly more left
					const yOffset = -3; // Slightly more up
			
					// Update text position
					$text.css({
						left: `calc(${x}% + ${xOffset}px)`,
						top: `calc(${y}% + ${yOffset}px)`
					});
			
					// Adjust margin-left for progress-text if percentage is above 95%
					if (percentage > 95) {
						$text.css({
							"margin-left": "-20px",
							"padding-top": "10px"
						});
					}
				} catch (error) {
					console.error('Error initializing progress bar:', error);
				}
			});
		}, initDelay);
		
		// In editor mode, reinitialize on element resize
		if (isElementorEditor()) {
			const observer = new MutationObserver(function(mutations) {
				mutations.forEach(function(mutation) {
					if (mutation.type === 'attributes' && (mutation.attributeName === 'class' || mutation.attributeName === 'style')) {
						coreit_progressbar();
					}
				});
			});
			
			document.querySelectorAll('.progressbar').forEach(function(el) {
				observer.observe(el, { attributes: true, subtree: false });
			});
		}
	}
	
 
// ----- PROGRESS CASE STUDY -----
function initializeProgress() {
	const containers = document.querySelectorAll('.case-progress');
	if (!containers.length) return;
	
	containers.forEach(container => {
		const percentage = container.dataset.percentage;
		const circle = container.querySelector('.progress-circle');
		const text = container.querySelector('.progress-text');
		
		if (!circle || !text) return;
		
		// Update text
		text.textContent = percentage + '%';
		
		// Calculate stroke-dashoffset
		const circumference = 2 * Math.PI * 18;  // Adjusted radius
		const offset = circumference - (percentage / 100) * circumference;
		circle.style.strokeDashoffset = offset;
	});
}

// ----- TESTIMONIAL SWIPER SLIDER -----
// ----- TESTIMONIAL SWIPER SLIDER -----
function coreit_textimonial_swiper_slider($scope) {
    // Use scope if provided (for Elementor), otherwise use document
    const container = $scope ? $scope.find('.text-swiper-container') : $('.text-swiper-container');
    
    // If container doesn't exist, exit early
    if (!container.length) return;
    
    // Add a longer delay in Elementor editor
    const delay = isElementorEditor() ? 300 : 100;
    
    setTimeout(function() {
        try {
            // Check if Swiper is loaded
            if (typeof Swiper === 'undefined') {
                console.log('Swiper not loaded yet, skipping testimonial slider');
                return;
            }
            
            container.each(function() {
                const $this = $(this);
                
                // Destroy existing swiper instance if exists
                if ($this[0].swiper) {
                    $this[0].swiper.destroy(true, true);
                }
                
                // Initialize the swiper
                try {
                    const swiper = new Swiper($this[0], {
                        effect: 'fade',
                        loop: true,
                        autoplay: {
                            delay: 3000,
                            disableOnInteraction: false
                        },
                        navigation: {
                            nextEl: '.testidiff-button-next',
                            prevEl: '.testidiff-button-prev',
                        },
                        on: {
                            init: function() {
                                this.update();
                            }
                        }
                    });
                    
                    // Force an update after initialization
                    setTimeout(() => {
                        if (swiper && typeof swiper.update === 'function') {
                            swiper.update();
                        }
                    }, 100);
                } catch (error) {
                    console.error('Error initializing testimonial swiper:', error);
                }
            });
        } catch (error) {
            console.error('Error in testimonial slider initialization:', error);
        }
    }, delay);
}


// ----- HOVER LIST -----
function coreit_hover_list() {
	if (!elementExists('.l_box')) return;
	
	$('.l_box').on('mouseenter', function() {
		$('.l_box').removeClass('active');
		$(this).addClass('active');
	});
}

// ----- ANIMATED IMAGE -----
function animatedwidget() {
	if (!elementExists('.animated-image-widget')) return;
	
	$('.animated-image-widget').each(function() {
		const animationType = $(this).data('animation-type');
		const animationSpeed = $(this).data('animation-speed');
		const animationIteration = $(this).data('animation-iteration');
		
		$(this).find('img').addClass(animationType)
			.css({
				'animation-duration': animationSpeed + 'ms',
				'--animation-iteration': animationIteration
			});
	});
}

// ----- PROGRESS BAR V2 -----
function progressbartwo() {
	if (!elementExists('.progress-v2')) return;
	
	$('.progress-v2').each(function() {
		var progressBar = $(this);
		var percentage = parseInt(progressBar.data('percentage'), 10);
		var percentageDisplay = progressBar.closest('.progress-bar-widget').find('.progress-percentage');

		// Animate the progress bar
		setTimeout(function() {
			progressBar.css('width', percentage + '%');
			var start = 0;
			var interval = setInterval(function() {
				if (start >= percentage) {
					clearInterval(interval);
				} else {
					start++;
					percentageDisplay.text(start + '%');
				}
			}, 15);
		}, 500);
	});
}

// ----- HOVER SLIDER -----
function initHoverSlider($scope) {
    // Use the provided scope or fallback to document
    const container = $scope || $(document);
    
    // Check if elements exist
    if (!container.find('.hoverslidercstudy-name').length) return;
    
    // Remove existing events and add them again
    container.find('.hoverslidercstudy-name').off('mouseenter').on('mouseenter', function() {
        var index = $(this).index();
        var $container = $(this).closest('.elementor-widget-container');
        
        $container.find('.hoverslidercstudy-name.active').removeClass('active');
        $container.find('.hoverslidercstudy-images li.show').removeClass("show");
        $container.find('.hoverslidercstudy-images li:eq(' + index + ')').addClass("show");
        $(this).addClass('active');
    });

    // Set initial state
    container.find('.hoverslidercstudy-name:first-child').addClass('active');
    container.find('.hoverslidercstudy-images li:first-child').addClass('show');
}
// ----- SIDEBAR TOGGLE -----
function coreit_sidebar() {
	if (!elementExists('body.showing-sidebar')) return;
	
	// Check localStorage for sidebar state
	var isSidebarHidden = localStorage.getItem('sidebarHidden');
	
	// Apply stored state
	if (isSidebarHidden === 'true') {
		$("body.showing-sidebar").addClass("sidebar-hidden");
	}
	
	// Toggle sidebar on button click
	$(".coreit_filter_btn").click(function() {
		$("body.showing-sidebar").toggleClass("sidebar-hidden");
		localStorage.setItem('sidebarHidden', $("body").hasClass("sidebar-hidden"));
	});
}

// ----- PROGRESS BAR -----
function coreit_progress_bar() {
	if (!elementExists('.sold-done')) return;
	
	$('.sold-done').each(function() {
		var percent = parseFloat($(this).attr('data-done'));
		$(this).css({
			'width': percent + '%',
			'opacity': 1
		});
	});
}

// ----- MEGA MENU ADJUSTMENT -----
function coreit_adjustMegaMenu() {
	// Only run for desktop viewports
	if (window.innerWidth < 1200) {
		// Reset styles for small screens
		document.querySelectorAll('.navbar_nav .sub-menu').forEach(subMenu => {
			subMenu.style.left = '';
			subMenu.style.width = '';
			subMenu.style.maxWidth = '';
			subMenu.classList.remove('submenu-visible');
		});
		return;
	}

	const navbarNav = document.querySelector('.navbar_nav');
	if (!navbarNav) return;

	const megaMenuItems = document.querySelectorAll('.navbar_nav > li.mega_menu, .navbar_nav > li.flex_menu_activate.menu_fullwidth');
	
	megaMenuItems.forEach(item => {
		const subMenu = item.querySelector('.sub-menu');
		if (subMenu) {
			const itemRect = item.getBoundingClientRect();
			// Set the sub-menu position and width
			subMenu.style.left = `-${itemRect.left}px`;
			subMenu.style.width = `${window.innerWidth}px`;
			subMenu.style.maxWidth = `${window.innerWidth}px`;
			
			// Add class for visibility
			subMenu.classList.add('submenu-visible');
		}
	});
}

// ----- MENU ACTIVE CLASS HANDLER -----
 
function initMenuActiveClass() {
    // Get current page URL path and hash
    const currentPath = window.location.pathname;
    const currentHash = window.location.hash;
    
    // Process each navigation menu separately
    document.querySelectorAll('.navbar_nav').forEach(function(nav) {
        // Get all menu items in this specific navigation
        const menuItems = nav.querySelectorAll('li');
        
        // First clear any existing active classes in this navigation
        menuItems.forEach(function(item) {
            if (!item.classList.contains('current-menu-item') && !item.classList.contains('current_page_item')) {
                item.classList.remove('active');
                const itemLink = item.querySelector('a');
                if (itemLink) {
                    itemLink.classList.remove('active');
                }
            }
        });
        
        // Check if this is a one-page navigation (has hash links)
        const hasHashLinks = nav.querySelector('li > a[href^="#"]') !== null;
        
        if (hasHashLinks && currentHash) {
            // Handle hash links - find the matching link
            const activeLink = nav.querySelector(`li > a[href="${currentHash}"]`);
            if (activeLink) {
                activeLink.classList.add('active');
                activeLink.closest('li').classList.add('active');
            }
            
            // Add scroll handler only once
            if (!window.scrollHandlerAdded) {
                window.scrollHandlerAdded = true;
                window.addEventListener('scroll', handleScroll);
                // Initial call
                handleScroll();
            }
        } else {
            // Handle regular page links
            menuItems.forEach(function(item) {
                const link = item.querySelector('a');
                if (!link) return;
                
                const href = link.getAttribute('href');
                if (!href) return;
                
                // Check for exact match or if current path starts with the href
                const isMatch = href === currentPath || 
                               (href !== '/' && href !== '#' && currentPath.startsWith(href));
                
                if (isMatch) {
                    item.classList.add('active');
                    link.classList.add('active');
                }
                
                // Also handle submenu items
                const subMenuLinks = item.querySelectorAll('ul.sub-menu a');
                let hasActiveChild = false;
                
                subMenuLinks.forEach(function(subLink) {
                    const subHref = subLink.getAttribute('href');
                    if (!subHref) return;
                    
                    const isSubMatch = subHref === currentPath || 
                                      (subHref !== '/' && subHref !== '#' && currentPath.startsWith(subHref));
                    
                    if (isSubMatch) {
                        subLink.closest('li').classList.add('active');
                        hasActiveChild = true;
                    }
                });
                
                if (hasActiveChild) {
                    item.classList.add('active');
                    if (link) link.classList.add('active');
                }
            });
        }
    });
}

// Handle scrolling for one-page navigation
function handleScroll() {
    // Get all sections that might be targets of hash links
    const sections = [];
    document.querySelectorAll('.navbar_nav a[href^="#"]').forEach(function(link) {
        const hash = link.getAttribute('href');
        if (hash === '#') return;
        
        const section = document.querySelector(hash);
        if (section) {
            sections.push({
                section: section,
                link: link
            });
        }
    });
    
    if (sections.length === 0) return;
    
    // Find visible section
    const scrollPos = window.scrollY + 150; // Add offset to detect section earlier
    
    // Find the section that's currently visible
    let activeSection = null;
    
    // If at the top of the page, select first section
    if (scrollPos < 300) {
        activeSection = sections[0];
    } else {
        // Check each section
        for (let i = 0; i < sections.length; i++) {
            const current = sections[i];
            const sectionTop = current.section.offsetTop;
            const sectionHeight = current.section.offsetHeight;
            
            if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
                activeSection = current;
                break;
            }
            
            // Special case for last section
            if (i === sections.length - 1 && scrollPos >= sectionTop) {
                activeSection = current;
            }
        }
    }
    
    // Update active classes
    if (activeSection) {
        // Get the navbar this link belongs to
        const navbar = activeSection.link.closest('.navbar_nav');
        
        // Remove active class from all items in this navbar
        navbar.querySelectorAll('li').forEach(function(item) {
            item.classList.remove('active');
            const itemLink = item.querySelector('a');
            if (itemLink) itemLink.classList.remove('active');
        });
        
        // Add active class to current section's menu item
        activeSection.link.classList.add('active');
        activeSection.link.closest('li').classList.add('active');
    }
}

// Initialization
document.addEventListener('DOMContentLoaded', function() {
    initMenuActiveClass();
    
    // Re-initialize when clicking hash links
    document.querySelectorAll('a[href^="#"]').forEach(function(link) {
        link.addEventListener('click', function() {
            // Small delay to allow hash to change
            setTimeout(initMenuActiveClass, 100);
        });
    });
});

// Re-initialize on browser navigation
window.addEventListener('popstate', initMenuActiveClass);

// Re-initialize after AJAX loads (if applicable)
if (typeof jQuery !== 'undefined') {
    jQuery(document).ajaxComplete(function() {
        initMenuActiveClass();
    });
}
 
// ----- REGISTER ELEMENTOR HOOKS -----
function registerElementorHooks() {
	if (!window.elementorFrontend || !elementorFrontend.hooks) return;

	// Group related widgets by functionality
	const carouselWidgets = [
		'trimprim-slider-builder.default',
		'trimprim-before-after-widget.default',
		'trimprim-before-after-widget-v2.default',
		'trimprim-slider-1.default',
		'trimprim-client-carousel-widget.default',
		'trimprim-tab-with-content-v1.default',
		'trimprim-image-carousel-widget.default',
		'trimprim-service-carousel-v1.default',
		'coreit-service-carousel-v2.default',
		'trimprim-blog-carousel-v1.default',
		'steelthemes-blog-carousel-v2.default',
		'trimprim-portfolio-carousel-v1.default',
		'trimprim-team-carousel-v1.default',
		'trimprim-testimonial-carousel-v1.default',
		'trimprim-testimonial-carousel-v2.default',
		'trimprim-testimonial-carousel-v3.default',
		'trimprim-deals-v1.default',
		'trimprim-frequently-bought-together.default',
		'trimprim-product-deals-v1.default',
		'trimprim-product-carousel-v1.default',
		'steelthemes-case-studies-v2.default',
		'coreit-timeline-v1.default'
	];

	// Tab widgets
	const tabWidgets = [
		'trimprim-portfolio-tab-v2.default',
		'trimprim-Form-v1.default',
		'trimprim-price-tab-v2.default',
		'trimprim-price-tab-v3.default'
	];

	// Progress bar widgets
	const progressWidgets = [
		'trimprim-progress-bar-v1.default',
		'Progress_bar_v2.default'
	];

	// Register widget hooks with proper error handling
	function safeAddAction(widget, callback) {
		try {
			elementorFrontend.hooks.addAction('frontend/element_ready/' + widget, function($scope) {
				try {
					callback($scope);
				} catch (error) {
					console.error(`Error in widget handler for ${widget}:`, error);
				}
			});
		} catch (error) {
			console.error(`Error adding hook for ${widget}:`, error);
		}
	}

	// Register carousel hooks
	carouselWidgets.forEach(widget => {
		safeAddAction(widget, coreit_theme_swiper_carousel);
	});

	// Register tab hooks
	tabWidgets.forEach(widget => {
		safeAddAction(widget, coreit_tab);
	});

	// Register progress bar hooks
	progressWidgets.forEach(widget => {
		safeAddAction(widget, coreit_progressbar);
	});

	// Register other hooks
	safeAddAction('trimprim-before-after-widget.default', coreit_before_after_gallery_popup);
	safeAddAction('trimprim-contact-form-v1.default', coreit_tab);
	safeAddAction('trimprim-fun-facts-box.default', coreit_funfact);
	safeAddAction('trimprim-service-grid-v1.default', coreit_service_ajax);
	safeAddAction('steelthemes-service-grid-v2.default', coreit_service_ajax);
	safeAddAction('trimprim-blog-grid-v1.default', coreit_post_ajax);
	safeAddAction('trimprim-portfolio-grid-v1.default', coreit_portfolio_ajax);
	safeAddAction('trimprim-team-grid-v1.default', coreit_team_ajax);
	safeAddAction('trimprim-faqs-v1.default', coreit_faqsall);
	safeAddAction('trimprim-contact-form-v1.default', initializecoreitModals);
	safeAddAction('trimprim-price-tab-v2.default', coreit_price_tab);
	safeAddAction('trimprim-price-tab-v3.default', coreit_price_tab);
	safeAddAction('trimprim-portfolio-post-v1.default', coreit_grid_filter_layout);
	safeAddAction('steelthemes-case-studies.default', initializeProgress);
	safeAddAction('steelthemes-testimonial-carousel-v2.default', coreit_textimonial_swiper_slider);
	safeAddAction('steelthemes-list-v1.default', coreit_hover_list);
	safeAddAction('animated_image.default', animatedwidget);
	safeAddAction('hoversliders_study.default',  initHoverSlider);
}

// ----- INITIALIZE ON DOCUMENT READY -----
function initOnReady() {
	// Setup event handling for Elementor editor
	if (isElementorEditor()) {
		// Register for Elementor's editor events
		if (window.elementor) {
			// When a section or widget is added or removed, reinitialize components
			window.elementor.channels.editor.on('section:activated widget:activated', function() {
				setTimeout(function() {
					coreit_theme_swiper_carousel(); 
					coreit_textimonial_swiper_slider();
					coreit_progressbar();
					coreit_tab();
					coreit_grid_filter_layout();
				}, 50);
			});
		}
	}
	
	// Core functionality
	initPreloader();
	initCardService();
	initHeaderDropdown();
	initProgressIndicator();
	initMobileMenu();
	initSearchSidebar();
	initCartHandling();
	initSkeletonLoading();
	coreit_year_update();
	initStickyHeader();
	initializecoreitModals();
	initMagnificPopup();  
	initMenuActiveClass(); // <-- Add this line here to refresh active classes on resize 
	// Content functionality
	coreit_tab();
	coreit_price_tab();
	coreit_progress_bar();
	coreit_faqsall();
	coreit_before_after_gallery_popup();
	coreit_sidebar();
	coreit_grid_filter_layout();
	coreit_progressbar();
	coreit_adjustMegaMenu();
	
	// AJAX functionality
	coreit_post_ajax();
	coreit_portfolio_ajax();
	coreit_service_ajax();
	coreit_team_ajax();
	
	// Advanced features
	coreit_theme_swiper_carousel();
	coreit_funfact();
	initializeProgress();
	coreit_textimonial_swiper_slider();
	coreit_hover_list();
	animatedwidget();
	progressbartwo();
	initHoverSlider();
	
	// WooCommerce cart refresh
	if (typeof $(document.body).trigger === 'function') {
		$(document.body).trigger('wc_fragment_refresh');
	}
}

// Register Elementor hooks if available
if (window.elementorFrontend) {
	if (window.elementorFrontend.isEditMode()) {
		// In editor, wait for frontend init
		$(window).on('elementor/frontend/init', function() {
			registerElementorHooks();
			// Additional initialization for editor mode
			setTimeout(function() {
				coreit_progressbar();
				coreit_theme_swiper_carousel(); 
				coreit_textimonial_swiper_slider();
				initHoverSlider();
			}, 50);
		});
	} else {
		// On frontend, register when ready
		registerElementorHooks();
	}
}

// Initialize on document ready
$(document).ready(initOnReady);
 
// Handle window resize events
$(window).on('resize', debounce(function() {
	coreit_adjustMegaMenu();
	 
	initMenuActiveClass(); // <-- Add this line here to refresh active classes on resize
	// Also update swipers and progress bars on resize
	if (isElementorEditor()) {
		coreit_theme_swiper_carousel();
		coreit_progressbar();
		initHoverSlider();
	}
}, 50));

})(jQuery);