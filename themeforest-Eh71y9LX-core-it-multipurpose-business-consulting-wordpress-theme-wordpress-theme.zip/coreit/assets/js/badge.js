jQuery(document).ready(function($) {
    function updateBadges() {
        var selectedVariationId = $('form.variations_form').find('input[name="variation_id"]').val();
        
        // Hide all badges
        $('.variation-badge').hide();

        // Show the badge for the selected variation
        if (selectedVariationId) {
            $('.variation-badge[data-variation-id="' + selectedVariationId + '"]').show();
        }
    }

    // Initial badge update
    updateBadges();

    // Update badge on variation change
    $('form.variations_form').on('show_variation', function() {
        updateBadges();
    });

    // Also update badge on page load
    $(window).on('load', function() {
        updateBadges();
    });
});
jQuery(document).ready(function($) {
    function updateProgressBar() {
        var $form = $('form.cart');
        if ($form.hasClass('variations_form')) {
            // Variable product
            var selectedVariationId = $form.find('input[name="variation_id"]').val();
            $('.sold_progress_bar').hide(); // Hide all progress bars
            
            if (selectedVariationId) {
                var progressBar = $('.sold_progress_bar[data-variation-id="' + selectedVariationId + '"]');
                var variationDataVal = $('#variation_data').val();
                
                if (variationDataVal) {
                    var variationData = JSON.parse(variationDataVal);
                    var data = variationData[selectedVariationId];
                    
                    if (data) {
                        progressBar.find('.sold-done').css({
                            'width': data.percentage + '%',
                            'opacity': 1
                        });
                        progressBar.find('.available-quantity').text(data.original_stock);
                        progressBar.find('.sold-quantity').text(data.sold);
                        progressBar.show(); // Show the progress bar for the selected variation
                    }
                }
            }
        } else {
            // Simple product
            var progressBar = $('.sold_progress_bar[data-product-id]');
            var simpleProductDataVal = $('#simple_product_data').val();
            
            if (simpleProductDataVal) {
                try {
                    var simpleProductData = JSON.parse(simpleProductDataVal);
                    progressBar.find('.sold-done').css({
                        'width': simpleProductData.percentage + '%',
                        'opacity': 1
                    });
                    progressBar.find('.available-quantity').text(simpleProductData.original_stock);
                    progressBar.find('.sold-quantity').text(simpleProductData.sold);
                    progressBar.show();
                } catch (e) {
                    console.error("Invalid JSON in simple_product_data:", e);
                }
            }
        }
    }
    
    // Initial progress bar update
    updateProgressBar();
    
    // Update progress bar on variation change
    $('form.variations_form').on('show_variation', function() {
        updateProgressBar();
    });
    
    // Also update progress bar on page load
    $(window).on('load', function() {
        updateProgressBar();
    });
});


