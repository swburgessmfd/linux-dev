<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package coreit
*/
get_header(); 
$coreitblocksget = coreit_get_option('fornotfor_mode_blocks');
echo do_shortcode('[coreit-blocks id="' . $coreitblocksget . '"]'); 
 get_footer();?> 