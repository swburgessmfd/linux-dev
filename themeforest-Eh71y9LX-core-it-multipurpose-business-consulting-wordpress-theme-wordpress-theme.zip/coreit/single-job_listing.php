<?php
/*
 *=================================
 * The Template for displaying all single job Posts.
 * @package Coreit WordPress Theme
 *==================================
*/
get_header(); ?> 
<div id="primary" class="content-area job <?php coreit_column_for_job(); ?>">
	<main id="main" class="site-main" role="main">
		<div class="row">
			<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'template-parts/content/content','job' ); ?>  
			<?php endwhile; // end of the loop. ?>
		</div>
	</main><!-- #main -->
</div><!-- #primary --> 
<?php get_sidebar(); ?>
<?php get_footer(); ?>
