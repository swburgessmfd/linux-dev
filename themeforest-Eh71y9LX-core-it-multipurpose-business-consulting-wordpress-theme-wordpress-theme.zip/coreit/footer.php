<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package coreit
 */
?>                                              </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php 
                                    $recently_viewd_poducts = coreit_get_option('recently_viewd_poducts' , true);
                                    if($recently_viewd_poducts == true): 
                                        if (is_tax('product_cat')  || is_post_type_archive('product') || is_singular('product')) {?>
                                    <?php do_action('coreit_get_recent_pro'); ?> 
                                    <?php } endif; ?>
                                <?php // cookies ?>
                                    <?php do_action('coreit_cookies_get'); ?>  
                                <?php // cookies ?>
                                <?php // mobile nav ?>
                                    <?php do_action('coreit_get_mobile_menu');  ?>
                                <?php // mobile nav ?>   
                                <?php // Back To Top ?>
                                    <?php do_action('coreit_get_back_to_top'); ?>
                                <?php // Back To Top ?>
                            </div> 
                        <?php // top content ?> 
                    <?php do_action('coreit_get_footer'); ?> 
                </div> 
            <!--page_wapper--> 
            <?php if(class_exists('coreit_Addons')): ?>
                                    <div class="cart-overlay"></div>
                                    <div id="mini-cart-sidebar" class="mini-cart-sidebar trans">
                                        <div class="mini-cart-content">
                                            <span class="close-cart">&times;</span>
                                            <div class="box_cart">
                                            <div class="widget_shopping_cart_content">
                                                <p class="woocommerce-mini-cart__empty-message">Loading...</p>
                                            </div>
                                            </div>
                                        </div>
                                    </div>  
                                    <?php endif; ?>
        <?php wp_footer(); ?>
    </body>
</html>